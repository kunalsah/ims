<?php 
include("connection.php");
    $query ="SELECT department_name FROM department_list";
    $result = $conn->query($query);
    if($result->num_rows> 0){
      $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>