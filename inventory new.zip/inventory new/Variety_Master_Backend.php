<?php include("connection.php"); ?>
<?php


////////show one data
if(isset($_POST["id"]) && isset($_POST["id"])!=""){
    $id=$_POST["id"];
    $query="SELECT * FROM variety_master WHERE `var_id`='$id'";  

    if(!$result=mysqli_query($conn,$query)){
        exit();
    }
    $response=array();

    if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_assoc($result)){
            $response = $row;
        }
    }else{
        $response['message']="Data Not found";
    }

echo json_encode($response);

}

////delete the data
if(isset($_POST["deletedid"])){
    $id=$_POST["deletedid"];
    $sql= $sql1 = "UPDATE variety_master SET `status`='0' WHERE var_id = '$id'";

    $result = mysqli_query($conn, $sql);
    if ($result) {
      // echo $sql;
      echo $msg="Deleted Successfully!!";
    } else {
      echo $msg="Deleted Unsuccessful!!";
    }

    echo json_encode($msg);

}


/// insert the data
if(isset($_POST['name'])){
    $item = $_POST["name"];
    date_default_timezone_set("Asia/Kolkata");
    $creatername = "Admin";
    $current_date=date("Y-m-d H:i:s");
    $status='1';

    $sql1 = "INSERT INTO variety_master (var_name,created_by,created_on,status) SELECT * FROM (SELECT '$item', '$creatername', '$current_date','$status') AS tmp WHERE NOT EXISTS (SELECT var_name FROM variety_master WHERE var_name = '$item' AND status='1') LIMIT 1;";
    $result = mysqli_query($conn, $sql1);
    if (mysqli_affected_rows($conn) == 0) {
      // echo $sql;
      echo $return="already Found";
    } else {
      echo $return="New Unit added!";
}
}


///display the data
if(isset($_REQUEST['display'])){
    $item = $_REQUEST["display"];
$query="SELECT * FROM variety_master WHERE `status`='1'";
$result=mysqli_query($conn,$query);
$result_array=array();

while($row=mysqli_fetch_array($result)){
    $result_array[] = $row;
}
echo json_encode($result_array);
}


///update data
if(isset($_POST["id1"])){
  date_default_timezone_set("Asia/Kolkata");
  $current_date=date("Y-m-d H:i:s");
  $creatername = "Admin";
    $id=$_POST["id1"];
    $name=$_POST["name1"];
    $sql= $sql1 = "UPDATE variety_master SET `var_name`='$name',`updated_by`='$creatername',`updated_on`='$current_date' WHERE var_id = '$id'";

    $result = mysqli_query($conn, $sql);
    if ($result) {
      // echo $sql;
      echo $msg="Updated Successfully!!";
    } else {
      echo $msg="Updated Unsuccessful!!";
    }

    echo json_encode($msg);

}

?>