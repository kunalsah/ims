<?php include("top_header.php");
require("connection.php");
include("sidebar_upper.php");
?>
<div class="container card mt-2" style="box-shadow:0 0 5px #a8a8a8;">
<table class="table table-bordered table-hover">
    <h3 class="text-center">Requests History</h3>

    <tr>
        <th class="text-center">S.NO.</th>
        <th class="text-center">Name</th>
        <th class="text-center">Product</th>
        <th class="text-center">Quantity</th>
        <th class="text-center">Unit</th>
        <th class="text-center">Request Status</th>
        <th class="text-center">Allotment Date</th>
        <th class="text-center">Recieving Date</th>
    </tr>
    <!-- fetching History of user -->
    <?php
        $sql="SELECT * FROM `request_tbl` INNER JOIN member_list on request_tbl.request_user=member_list.m_id INNER JOIN request_item on request_tbl.request_id=request_item.r_id inner join product_list on product_list.p_id=request_item.rp_id where r_accept_status='Accepted' or r_accept_status='Rejected' order by r_accept_on desc";
        $i=0;
        $result = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_array($result)) {
            $i++;
            $request_name = $row['m_name'];
            $request_product_name = $row['p_name'];
            $request_product_quantity = $row['r_qty'];
            $request_product_unit = $row['p_unit'];
            $request_status = $row['r_accept_status'];
            $requested_date = $row['r_accept_on'];
            $request_received_date = $row['r_received_on'];
            $id=$row['m_id'];

            if($request_status=='Accepted'){
                $style = 'style="color:green"';
            }
            else{
                $style = 'style="color:red"';

            }

            echo'
            <tr>
            <td class="text-center">'.$i.'</td>
            <td class="text-center">'.$request_name.'</td>
            <td class="text-center">'.$request_product_name.'</td>
            <td class="text-center">'.$request_product_quantity.'</td>
            <td class="text-center">'.$request_product_unit.'</td>
            <td class="text-center" '.$style.'>'.$request_status.'</td>
            <td class="text-center">'.$requested_date.'</td>
            <td class="text-center">'.$request_received_date.'</td>
            
        </tr>
            ';
        }
        ?>

</table>
</div>
<?php
include("sidebar_lower.php");
?>