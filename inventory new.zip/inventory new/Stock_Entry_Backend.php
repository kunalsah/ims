<?php
include('connection.php');

// get item name and id
if(isset($_POST['loadvalue1'])){
    $sql="SELECT product_master.product_name,item_master.item_name,product_master.product_id FROM `product_master` INNER JOIN item_master ON item_master.item_id=product_master.product_name;";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        $result_array=array();
        while($row=mysqli_fetch_array($result)){
            $result_array[]=$row;
        }
        echo json_encode($result_array);
    }
}

// get vendor name
if(isset($_POST['loadvalue2'])){
    $sql="SELECT distinct vendor_name from stock_entry_table ";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        $result_array=array();
        while($row=mysqli_fetch_array($result)){
            $result_array[]=$row;
        }
        echo json_encode($result_array);
    }
}
// get vendor contact
if(isset($_POST['loadvalue3'])){
    $sql="SELECT distinct vendor_contact from stock_entry_table ";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        $result_array=array();
        while($row=mysqli_fetch_array($result)){
            $result_array[]=$row;
        }
        echo json_encode($result_array);
    }
}
// get vendor state
if(isset($_POST['loadvalue4'])){
    $sql="SELECT distinct vendor_state from stock_entry_table ";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        $result_array=array();
        while($row=mysqli_fetch_array($result)){
            $result_array[]=$row;
        }
        echo json_encode($result_array);
    }
}
// get vendor contact
if(isset($_POST['loadvalue5'])){
    $sql="SELECT distinct vendor_district from stock_entry_table ";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        $result_array=array();
        while($row=mysqli_fetch_array($result)){
            $result_array[]=$row;
        }
        echo json_encode($result_array);
    }
}

// add stock request

if(isset($_POST['add_stock_request'])){
$item_name=$_POST['item_name'];
$total_quantity=$_POST['total_quantity'];
$purchased_date=$_POST['purchased_date'];
$rate_per_unit=$_POST['rate_per_unit'];
$total_price=$_POST['total_price'];
$vendor_name=$_POST['vendor_name'];
$vendor_contact=$_POST['vendor_contact'];
$vendor_address=$_POST['vendor_address'];
$vendor_state=$_POST['vendor_state'];
$vendor_district=$_POST['vendor_district'];
$remarks=$_POST['remarks'];
$status=1;
date_default_timezone_set("Asia/Kolkata");
$current_date = date("Y-m-d H:i:s");
$created_by='admin';

// checking if product exist in stock master of not
$sql0="SELECT stock_product_name FROM stock_master WHERE stock_product_name = '$item_name'";
$result0=mysqli_query($conn,$sql0);
if(mysqli_num_rows($result0)==0){
    $sql = "INSERT INTO stock_master (Stock_Product_Name,Total_Product,Issued_Product,Balance_Product,created_on,created_by,status) values ('$item_name','0','0','0','$current_date','$created_by','1')";
    mysqli_query($conn,$sql);
}

$sql= "insert into stock_entry_table (stock_name,stock_qty,stock_purchased_date,rate_per_unit,total_rate,vendor_name,vendor_contact,vendor_address,vendor_state,vendor_district,stock_remarks,status,created_date,created_by) values('$item_name','$total_quantity','$purchased_date','$rate_per_unit','$total_price','$vendor_name','$vendor_contact','$vendor_address','$vendor_state','$vendor_district','$remarks','$status','$current_date','$created_by')";
$result=mysqli_query($conn,$sql);
if(mysqli_affected_rows($conn)==1){
    // echo 1;
    $sql="select Total_Product from stock_master where Stock_Product_Name = '$item_name'";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        $result_array=array();
        while($row=mysqli_fetch_array($result)){
            $result_array[]=$row;
        }

        $new=intval($result_array[0][0]);

        $total_qty=intval($total_quantity);
        $new_value=$new + $total_qty;
        
        $sql="update stock_master set Total_Product='$new_value' where Stock_Product_Name='$item_name'";
        $result=mysqli_query($conn,$sql);
        if(mysqli_affected_rows($conn)==1){
            echo 1;

        }
    }
    // $updated_quantity=$total_quantity;

}else{
    echo 0;
}

}

// display data
if(isset($_POST['displaydata'])){
    $sql="SELECT *,item_master.item_name FROM `stock_entry_table` 
    INNER JOIN product_master ON stock_entry_table.stock_name=product_master.product_id
    INNER JOIN item_master ON product_master.product_name=item_master.item_id order by stock_entry_table.stock_id desc;";
    $result=mysqli_query($conn,$sql);
    
    if(mysqli_num_rows($result)>0){
        $result_array=array();
        while($row=mysqli_fetch_array($result)){
            $result_array[]=$row;
        }
        echo json_encode($result_array);
    }
}

// getting details of vendor to set in the modal via vendor name
if(isset($_POST['get_vendor_name_to_set_its_detail'])){
    $value=$_POST['value'];
$sql="select distinct vendor_contact,vendor_address,vendor_state,vendor_district from stock_entry_table where vendor_name='$value'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0){
    $result_array=array();
    while($row=mysqli_fetch_array($result)){
        $result_array[]=$row;
    }
    echo json_encode($result_array);
}else{
    echo 0;
}
}
?>