<?php
include('top_header.php');
include('sidebar_upper.php');
require('connection.php');
?>

<div class="card container mt-4 mb-4 p-2 shadow">
    <h4 class="card-title" style="text-align: center;">Distribution</h4>
    <table class="table table-bordered table-hover" style="text-align: center;">
        <tr>
            <th>S.NO.</th>
            <th>Name</th>
            <th>Product</th>
            <th>Quantity</th>
            <th>Unit</th>
            <th>Accepted On</th>
            <th>Priority</th>

            <th>Operation</th>
        </tr>
        <?php
        $i = 0;
        $sql = "SELECT * FROM request_item Inner join product_list on request_item.rp_id=product_list.p_id inner join member_list on request_item.req_mem_id=member_list.m_id Where r_received_status='NO' and r_accept_status='Accepted'";
        $result = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
            $i++;
            $name = $row['m_name'];
            $product_name = $row['p_name'];
            $product_quantity = $row['r_qty'];
            $unit = $row['p_unit'];
            $r_accept_date = $row['r_accept_on'];
            $request_serial = $row['request_serial'];
            $priority = $row['priority'];

            if ($priority == 'Normal') {
                $style = 'style="color:green"';
            } else {
                ?>
                <script>
                    swal({
                        title: "Urgent",
                        text: "Urgent request received",
                        icon: "warning",
                        button: "Seen",
                        timer:2000,
                    });
                </script>
                <?php
                $style = 'style="color:red"';

            }

            echo '
                <tr>
                <td> ' . $i . '</td>
                <td> ' . $name . '</td>
                    <td>' . $product_name . '</td>
                    <td>' . $product_quantity . '</td>
                    <td>' . $unit . '</td>
                    <td>' . $r_accept_date . '</td>
                    <td ' . $style . '>' . $priority . '</td>

                    <td>
                    <a data-placement="top" data-toggle="tooltip" title="Distribute" class="btn name_modal m-1 btn-primary " data-nid="' . $request_serial . '"  href="#"><i class="bi bi-arrow-right-circle" style="font-size: 16px;"></i></a>
                    </td>
                </tr>
                ';
        }



        ?>

        <!-- reject Modal -->
        <div class="modal fade" id="name_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Receivers Name</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center">
                        <form action="provided.php" method="post">
                            <label for="Receivers_name">Receivers Name</label><br>
                            <input type="text" name="receivers_name" id="receivers_name" ><br>
                            <input type="hidden" name="id" id="name_serno">
                            <button type="submit" class="btn btn-primary mt-1"><i class="bi bi-check-all" style="font-size: 20px; "></i></button>
                        </form>
                    </div>

                </div>
            </div>
        </div>
        <!-- reject Modal -->



        <script type="text/javascript">
            $(document).ready(function () {
                $(".name_modal").on("click", function () {
                    // alert("hello");
                    var myid = $(this).data('nid');
                    $("#name_serno").val(myid);
                    $('#name_modal').modal('show');

                });
            });
        </script>

        <!-- tooltip -->
<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    });
</script>

        <?php include("sidebar_lower.php"); ?>