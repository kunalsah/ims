<?php
include('top_header.php');
include('sidebar_upper.php');

require 'config.php';
?>

<div id="page-wrapper">
    <div class="main-page">

        <div class="card" style="box-shadow:0 0 5px #a8a8a8;">
            <div class="text" style="color:blue;font-size:18px">
                Add New Product Category From Here!!!
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary float-end " data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Add
                </button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel" style="color:red">Order Product!</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <div class="col-md-12 my-1">
                                    <label for="inputEmail4" class="form-label">Category Name :</label>
                                    <input type="text" name="n_item" class="form-control" id="inputEmail4" placeholder="Enter Category Name" required>
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" name="submit" class="btn btn-success" onclick="additem()">Add Category</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="tables">
            <h2 class="title1">Category Master</h2>

            <div class="table-responsive">
                <table class="table" border=3>
                    <tr>
                        <td><b>S. No.</b></td>
                        <td><b>Category Name<b></td>
                        <td><b>Created By<b></td>
                        <td><b>Created On<b></td>
                        <td><b>Updated By<b></td>
                        <td><b>Updated On<b></td>
                        <td><b>Operations</b></td>
                    </tr>
                    <tbody id="table_body" class="Data">

                    </tbody>



                </table>

                <!-- update Modal -->
                <div class="modal fade" id="update_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Update Category</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body text-center">

                            <label for="inputEmail4" class="form-label">Category Name :</label>
                                <input type="text" id="value1" name="value" required style="width: 50%;">
                                <input type="hidden" name="id" id="serno"></br></br>
                                <button type="submit" onclick="updateitem()" class="btn btn-primary">Update</button>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- update Modal -->


                <!-- reject Modal -->
                <div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Reason for Delete Category</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body text-center">
                                <form action="delete_cat.php" method="post">
                                    <input class="m-1" type="text" id="value" name="value" required style="width: 100%;">
                                    <input type="hidden" name="id" id="r_serno">
                                    <button type="submit" class="btn btn-primary">submit</button>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- reject Modal -->

            </div>
        </div>
    </div>
    <div class="clearfix"> </div>
</div>



<?php
include("sidebar_lower.php");
?>
<!-- show Data -->
<script>
    $(document).ready(function() {
        displayData();
    });

    function displayData() {
        var display='display';
        $.ajax({
            url: 'Category_Master_Backend.php',
            type: 'GET',
            data:{display:display},
            dataType: "json",
            success: function(response) {
                if (response.length > 0) {
                    var Q = 0;
                    var s_body = "";
                    for (var a = 0; a < response.length; a++) {
                        Q++;
                        var g = response[a].ca_id;
                        var b = response[a].category_name;
                        var c = response[a].created_by;
                        var d = response[a].created_date;
                        var e = response[a].updated_by;
                        var f = response[a].updated_date;



                        s_body = s_body + '<tr>' +
                            '<td>' + Q + '</td>\
                    <td>' + b + '</td>\
                    <td>' + c + '</td>\
                    <td>' + d + '</td>\
                    <td>' + e + '</td>\
                    <td>' + f + '</td>\
                    <td>\
                    <a class="btn btn-success"  onclick="showitem(' + g + ')">Edit</a>\
                    <a href="" class="btn btn-danger" onclick="deleteitem(' + g + ')">Delete</a>\
                    </td>\
                </tr>';
                    }
                    $('#table_body').html(s_body);
                }

            }


        });
    }
// add item through model
    function additem() {
        var name = $('#inputEmail4').val();
        if ($('#inputEmail4').val() == '') {
            // alert('Enter your name!');
            swal("Enter something!");

        }
        $.ajax({
            url: 'Category_Master_Backend.php',
            type: 'POST',
            data: {
                name: name
            },
            success: function(response) {
                displayData();
                $('input').each(function(){
                    $(this).val('');
                });
                $('#exampleModal').modal('hide');
                if(response=='already Found'){
                        swal('Product Already Found');
                    }else{
                        swal('Product added successfully!');
                    }
            }

        });
    }
// showing item into update input field
    function showitem(id){
        $('#serno').val(id);
        $.post("Category_Master_Backend.php",{
            id:id
        },function(data){
            var user=JSON.parse(data);
            $('#value1').val(user.category_name);
        });

        $('#update_modal').modal("show");

    }
// delete item
    function deleteitem(deletedid) {
        var conf = confirm("Are you sure");
        if (conf == true) {
            $.ajax({
                url: 'Category_Master_Backend.php',
                type: 'POST',
                data: {
                    deletedid: deletedid
                },
                success: function(msg) {
                    alert(msg);
                    displayData();
                    
                }

            });
        }

    }
// update item
    function updateitem(){
        var id1=$('#serno').val();
    
        var name1=$('#value1').val();

        $.post("Category_Master_Backend.php",{
            id1:id1,name1:name1
        },function(data){
            $('#update_modal').modal("hide");
            displayData();
            $('input').each(function(){
                    $(this).val('');
                });
        });       
    }

</script>

<!-- reject modal -->
<script type="text/javascript">
    $(document).ready(function() {
        $(".rejmodal").on("click", function() {
            // alert("hello");
            var myid = $(this).data('uid');
            // alert(myid);
            $("#r_serno").val(myid);
            $('#rejectModal').modal('show');

        });
    });
</script>
<!-- reject modal -->

<!-- tooltip -->
<script>
    $(function() {
        $('[data-toggle="tooltip"]').tooltip()
    });
</script>