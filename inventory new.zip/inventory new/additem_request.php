<?php
include('top_header.php');
include('sidebar_upper.php');
require('connection.php');
?>

<div class="container-fluid mt-5">

<div class="col-md-12">
            <div class="card" style="box-shadow:0 0 5px #a8a8a8;">
                <h2 class="text-center shadow-sm pb-1" style="font-family: 'Montserrat', sans-serif; font-weight:300;">
                    Add Items Requests</h2>
                <div class="content" style="overflow: hidden; overflow-y: scroll; height:70vh;">
                    <!-- content of the request history table starts here -->
                    <table class="table table-bordered table-hover" style="text-align: center;">
                        <tr style="position: sticky; top: 0; background-color:white;">
                            
                            <th>S. No.</th>
                            <th>Product Name</th>
                            <th>Qty</th>
                            <th>Product Desc</th>
                            <th>Requested By</th>
                            <th>Requested On</th>
                            <th>Operations</th>
                        </tr>
                        <?php
                         $i=0;
                        // $sql = "SELECT * FROM member_list where m_id=$id";
                        $sql = "SELECT * FROM `employee_item_order` INNER JOIN member_list on employee_item_order.user_id=member_list.m_id  where (status='unseen') order by req_date";
                        $result = mysqli_query($conn, $sql);
                        while ($row = mysqli_fetch_assoc($result)) {
                            $i++;
                            $request_serial=$row['ser_no'];
                            $product_name = $row['product_name'];
                            $product_quantity = $row['Qty'];
                            $desc = $row['product_desc'];
                            $requested_by = $row['m_name'];
                            $reqdate = $row['req_date'];
                            
                            

                          
                            echo '
                        <tr>
                            <td>'.$i.'</td>
                            <td>' . $product_name . '</td>
                            <td>' . $product_quantity . '</td>
                            <td>' . $desc . '</td>
                            <td>' . $requested_by . '</td>
                            <td> ' . $reqdate . '</td>
                            <td>
                            <a data-toggle="tooltip" data-placement="top" title="Accept Request" class="mymodal btn m-1 btn-primary" data-id="' . $request_serial . '"  href="#"><i class="bi bi-check-circle-fill" ></i></a>
                            <a data-toggle="tooltip" data-placement="top" title="Reject Request" class="btn rejmodal m-1 btn-danger" data-uid="' . $request_serial . '"  href="#"><i class="bi bi-x-circle-fill"></i></a>
                            </td>
                           

                        </tr>
                        ';
                        }

                        ?>
                    </table>

                     <!-- update Modal -->
                     <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Insert Product Details</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <form action="update.php" method="post">
                                            <input type="text" id="value" name="value" required style="width: 20%;">
                                            <input type="hidden" name="id" id="serno">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- update Modal -->

                     <!-- reject Modal -->
                     <div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Reason for Reject</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <form action="prod_req_rej.php" method="post">
                                            <input class="m-1" type="text" id="value" name="value" required style="width: 100%;">
                                            <input type="hidden" name="id" id="r_serno">
                                            <button type="submit" class="btn btn-primary">submit</button>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- reject Modal -->

                    </div>
                    </div>

</div>
<!-- reject modal -->
<script type="text/javascript">
    $(document).ready(function() {
        $(".rejmodal").on("click", function() {
            // alert("hello");
            var myid = $(this).data('uid');
            $("#r_serno").val(myid);
            $('#rejectModal').modal('show');

        });
    });
</script>
<!-- reject modal -->

<!-- update modal -->
<script type="text/javascript">
    $(document).ready(function() {
        $(".mymodal").on("click", function() {
            // alert("hello");
            var myid = $(this).data('id');
            $("#serno").val(myid);
            $('#exampleModal').modal('show');

        });
    });
</script>
<!-- update modal -->

<!-- tooltip -->
<script>
    $(function() {
        $('[data-toggle="tooltip"]').tooltip()
    });
</script>

<?php
include("sidebar_lower.php");
?>