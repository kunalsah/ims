<?php include("top_header.php"); ?>
<?php require("connection.php"); ?>
<?php
$id = $_POST['id'];
$value = $_POST['value'];

$sql="UPDATE request_item SET r_accept_status='Rejected', reason_a_r='$value' where `request_serial`=$id";
