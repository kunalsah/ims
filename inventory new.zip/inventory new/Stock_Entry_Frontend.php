<?php
include('top_header.php');
include('sidebar_upper.php');

?>

<style>
    /* CSS for additem button*/
    .submit_btn {
        margin: 10px;
        padding: 10px 30px;
        width: 100%;
        text-align: center;
        text-transform: uppercase;
        transition: 0.5s;
        background-size: 200% auto;
        color: white;
        border-radius: 10px;
        display: block;
        border: 0px;
        font-weight: 400;
        box-shadow: 0px 0px 14px -7px #f09819;
        background-image: linear-gradient(45deg, #FF512F 0%, #F09819 51%, #FF512F 100%);
        cursor: pointer;
        user-select: none;
        -webkit-user-select: none;
        touch-action: manipulation;
    }

    .submit_btn:hover {
        background-position: right center;
        /* change the direction of the change here */
        color: #fff;
        text-decoration: none;
    }

    .submit_btn:active {
        transform: scale(0.95);
    }
</style>

<div class="card" style="box-shadow:0 0 5px #a8a8a8;">
    <div class="text" style="color:#f39b2c;font-size:22px;">
        Add New Stock From Here!!!
        <!-- Button trigger modal -->
        <button type="button" class="submit_btn float-end " data-bs-toggle="modal" data-bs-target="#exampleModal" style="padding: 5px;margin:2px;width: 10% !important;">
            Add
        </button>
    </div>
</div>
<div class="tables">
    <h2 class="title1">Stock Entry Table</h2>

    <div class="table-responsive">
        <table class="table" border=3 id="myTable">
            <thead>
                <tr>
                    <th>S No.</th>
                    <th>Stock Name</th>
                    <th>Quantity</th>
                    <th>Date</th>
                    <th>Rate</th>
                    <th>Total Price</th>
                    <th>Vendor</th>
                    <th>Remarks</th>
                    <!-- <th>Operations</th> -->
                </tr>
            </thead>
            <tbody id="table_body" class="Data">

            </tbody>

        </table>

    </div>
</div>


<!-- add new modal -->

<div class="modal fade" id="addnewModal" data-bs-backdrop="static" tabindex="-1" aria-labelledby="addnewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="addnewModalLabel" style="color:red">Add New Item!</h1>

                <button type="button" class="btn-close" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#exampleModal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3 my-1">


                    <div class="col-md-6 my-1">
                        <label for="inputEmail4" class="form-label"><b>ItemName :</b></label>
                        <input type="text" name="item_name" class="form-control" id="new_item_name" placeholder="Enter Item Name" require>
                    </div>

                    <div class="col-md-6 my-1">
                        <label for="inputPassword4" class="form-label"><b>Category :</b></label>
                        <select name="new_p_category" class="form-select select3" id="new_p_category">

                        </select>
                    </div>



                    <div class="col-md-6 my-1">
                        <label for="inputEmail4" class="form-label"><b>Variety :</b></label>
                        <select name="new_p_variety" class="form-select select3" id="new_p_variety">


                        </select>
                    </div>


                    <div class="col-md-6 my-1">
                        <label for="inputPassword4" class="form-label"><b>Quantity :</b></label>
                        <input type="number" name="new_p_qtytotal" class="form-control" id="new_p_qtytotal" placeholder="enter Quantity" require>
                    </div>

                    <div class="col-md-6 my-1">
                        <label for="inputEmail4" class="form-label"><b>Type :</b></label>
                        <select name="new_p_type" class="form-select select3" id="new_p_type">

                        </select>
                    </div>
                    <div class="col-md-6 my-1">
                        <label for="inputEmail4" class="form-label"><b>Unit :</b></label>
                        <select name="new_p_unit" class="form-select select3" id="new_p_unit">

                        </select>
                    </div>


                </div>
                <div class="modal-footer">
                    <button type="submit" name="submit" onclick="addnewitem()" class="btn btn-danger">Add New</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- add new modal ends -->
<!-- modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">

                <h1 class="modal-title fs-5" id="exampleModalLabel" style="color:#f39b2c">Add New Stock!</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3 my-1">


                    <div class="col-md-5 my-1">
                        <label for="inputEmail4" class="form-label"><b>Item Name :</b></label>
                        <select name="item_name" class="form-select" id="item_name" placeholder="Enter Item Name">

                        </select>
                    </div>
                    <div class="col-md-1 pt-3" style="padding-right: 3% !important;">
                        
                        <a class="float-end" data-bs-toggle="modal" data-bs-target="#addnewModal" onclick="clear_value_newmodal();"><i class="bi bi-bag-plus-fill" style="font-size: 26px; color: #171A1D !important;" data-toggle="tooltip" title="Add New Item"></i></a>
                    </div>

                    <div class="col-md-6 my-1">
                        <label for="inputPassword4" class="form-label"><b>Quantity :</b></label>
                        <input type="number" name="total_quantity" class="form-control" id="total_quantity" placeholder="Enter Quantity" require>
                    </div>
                    <div class="col-md-6 my-1">
                        <label for="inputPassword4" class="form-label"><b>Purchase Date</b></label>
                        <input type="date" name="purchased_date" class="form-control" id="purchased_date" placeholder="Select Date">
                    </div>



                    <div class="col-md-6 my-1">
                        <label for="inputEmail4" class="form-label"><b>Rate Per Unit :</b></label>
                        <input type="number" name="rate_per_unit" class="form-control" id="rate_per_unit" placeholder="Enter Price">
                    </div>



                    <div class="col-md-6 my-1">
                        <label for="inputEmail4" class="form-label"><b>Total Price :</b></label>
                        <input type="text" name="total_price" class="form-control" id="total_price" placeholder="Total Price">
                    </div>
                    <div class="col-md-6 my-1">
                        <label for="inputEmail4" class="form-label"><b>Vendor Name:</b></label>
                        <select name="vendor_name" class="form-select select2" id="vendor_name" placeholder="Enter Vendor Name">

                        </select>
                    </div>
                    <div class="col-md-6 my-1">
                        <label for="inputAddress" class="form-label"><b>Vendor Contact :</b></label>
                        <!-- <input type="number" name="vendor_contact" class="form-control" id="vendor_contact" placeholder="Enter Contact"> -->
                        <select name="vendor_contact" class="form-select select2" id="vendor_contact" placeholder="Enter Vendor Contact">

                        </select>
                    </div>
                    <div class="col-md-6 my-1">
                        <label for="inputAddress" class="form-label"><b>Vendor Address :</b></label>
                        <input type="text" name="vendor_address" class="form-control" id="vendor_address" placeholder="Enter Vendor Address">
                    </div>
                    <div class="col-md-6 my-1">
                        <label for="inputAddress" class="form-label"><b>Vendor State :</b></label>
                        <select name="vendor_state" class="form-select select2" id="vendor_state" placeholder="Enter State">

                        </select>
                    </div>
                    <div class="col-md-6 my-1">
                        <label for="inputAddress" class="form-label"><b>District :</b></label>
                        <select name="vendor_district" class="form-select select2" id="vendor_district" placeholder="Enter District">

                        </select>
                    </div>
                    <div class="col-12 my-1">
                        <label for="inputAddress" class="form-label"><b>Remarks :</b></label>
                        <textarea name="remarks" class="form-control" id="remarks" placeholder="Enter Your Remarks About This Product Here..."></textarea>
                    </div>

                </div>
                <div class="modal-footer col-12 my-1">
                    <button type="submit" name="submit" onclick="additem()" class="submit_btn">Add New</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- modal close -->

<?php
include('sidebar_lower.php');
?>
<!-- select2 initilizing -->
<script>
    $(document).ready(function() {
        $('.select2').select2({
            dropdownParent: $("#exampleModal"),
            // dropdownParent: $("#addnewModal"),

            tags: true
        });

        $('.select3').select2({
            // dropdownParent: $("#exampleModal"),
            dropdownParent: $("#addnewModal"),

            tags: true
        });

        $('#addnewModal').modal({
            backdrop: 'static',
            keyboard: false
        });

        load_item_name_value();
        load_vendor_name_value();
        load_vendor_contact_value();
        load_vendor_state_value();
        load_vendor_district_value();
        showitem();



    });
</script>
<script>
    // load item name
    function load_item_name_value() {
        var loadvalue1 = "loadvalue1";
        $.ajax({
            url: "Stock_Entry_Backend.php",
            type: "post",
            dataType: "JSON",
            data: {
                loadvalue1: loadvalue1
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = "<option disabled selected>--Select Item--</option>";
                    for (var a = 0; a < response.length; a++) {
                        var value = response[a].product_id;
                        var text = response[a].item_name;

                        optn_body = optn_body + '<option value="' + value + '">' + text + '</option>';
                    }
                    document.getElementById('item_name').innerHTML = optn_body;

                }
            }
        });
    }

    function clear_value_newmodal() {
        $('#new_item_name').val('');
        $('#new_p_qtytotal').val('');
        load_new_values5();
        load_new_values4();
        load_new_values3();
        load_new_values();
    }
    // load vendor name
    function load_vendor_name_value() {
        var loadvalue2 = "loadvalue2";
        $.ajax({
            url: "Stock_Entry_Backend.php",
            type: "post",
            dataType: "JSON",
            data: {
                loadvalue2: loadvalue2
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = "<option disabled selected>--Select Name--</option>";
                    for (var a = 0; a < response.length; a++) {
                        // var value= response[a].product_name;
                        var text = response[a].vendor_name;

                        optn_body = optn_body + '<option value="' + text + '">' + text + '</option>';
                    }
                    document.getElementById('vendor_name').innerHTML = optn_body;

                }
            }
        });
    }
    // load vendor contact
    function load_vendor_contact_value() {
        var loadvalue3 = "loadvalue3";
        $.ajax({
            url: "Stock_Entry_Backend.php",
            type: "post",
            dataType: "JSON",
            data: {
                loadvalue3: loadvalue3
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = "<option disabled selected>--Select Contact--</option>";
                    for (var a = 0; a < response.length; a++) {
                        // var value= response[a].product_name;
                        var text = response[a].vendor_contact;

                        optn_body = optn_body + '<option value="' + text + '">' + text + '</option>';
                    }
                    document.getElementById('vendor_contact').innerHTML = optn_body;

                }
            }
        });
    }
    // load vendor state
    function load_vendor_state_value() {
        var loadvalue4 = "loadvalue4";
        $.ajax({
            url: "Stock_Entry_Backend.php",
            type: "post",
            dataType: "JSON",
            data: {
                loadvalue4: loadvalue4
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = "<option disabled selected>--Select State--</option>";
                    for (var a = 0; a < response.length; a++) {
                        // var value= response[a].product_name;
                        var text = response[a].vendor_state;

                        optn_body = optn_body + '<option value="' + text + '">' + text + '</option>';
                    }
                    document.getElementById('vendor_state').innerHTML = optn_body;

                }
            }
        });
    }
    // load vendor district
    function load_vendor_district_value() {
        var loadvalue5 = "loadvalue5";
        $.ajax({
            url: "Stock_Entry_Backend.php",
            type: "post",
            dataType: "JSON",
            data: {
                loadvalue5: loadvalue5
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = "<option disabled selected>--Select District--</option>";
                    for (var a = 0; a < response.length; a++) {
                        // var value= response[a].product_name;
                        var text = response[a].vendor_district;

                        optn_body = optn_body + '<option value="' + text + '">' + text + '</option>';
                    }
                    document.getElementById('vendor_district').innerHTML = optn_body;

                }
            }
        });
    }
    // calculation of total price
    $("#total_quantity,#rate_per_unit").keyup(function() {
        // alert(1);
        var total = 0;
        var quantity = $("#total_quantity").val();
        var unit_price = $("#rate_per_unit").val();
        var total = quantity * unit_price;
        $("#total_price").val(total);

    });

    // add item
    function additem() {
        if (($('#item_name').val() == 0) || ($('#item_name option:selected').text() == "--Select Item--") || ($('#total_quantity').val() == '') || ($('#purchased_date').val() == '') || ($('#rate_per_unit').val() == '') || ($('#total_price').val() == '') || ($('#vendor_name').val() == 0) || ($('#vendor_name option:selected').text() == "--Select Name--") || ($('#vendor_contact').val() == 0) || ($('#vendor_contact option:selected').text() == "--Select Contact--") || ($('#vendor_address').val() == '') || ($('#vendor_state').val() == 0) || ($('#vendor_state option:selected').text() == "--Select State--") || ($('#vendor_district').val() == 0) || ($('#vendor_district option:selected').text() == "--Select District--")) {
            Swal.fire("No Empty Field!!");
            // $('#exampleModal').modal('hide');
        } else {

            let add_stock_request = 'add_stock_request';
            let item_name = $("#item_name").val();
            let total_quantity = $("#total_quantity").val();
            let purchased_date = $("#purchased_date").val();
            let rate_per_unit = $("#rate_per_unit").val();
            // let total_rate = total_quantity * total_price ;
            let total_price = $("#total_price").val();
            let vendor_name = $("#vendor_name").val();
            let vendor_contact = $("#vendor_contact").val();
            let vendor_address = $("#vendor_address").val();
            let vendor_state = $("#vendor_state").val();
            let vendor_district = $("#vendor_district").val();
            let remarks = $("#remarks").val();

            $.ajax({
                url: 'Stock_Entry_Backend.php',
                type: 'post',
                data: {
                    add_stock_request: add_stock_request,
                    item_name: item_name,
                    total_quantity: total_quantity,
                    purchased_date: purchased_date,
                    rate_per_unit: rate_per_unit,
                    total_price: total_price,
                    vendor_name: vendor_name,
                    vendor_contact: vendor_contact,
                    vendor_address: vendor_address,
                    vendor_state: vendor_state,
                    vendor_district: vendor_district,
                    remarks: remarks,
                },
                success: function(response) {
                    if (response == 1) {
                        Swal.fire("Item Added!!");
                        $('#exampleModal').modal('hide');
                        showitem();

                        load_item_name_value();
                        load_vendor_name_value();
                        load_vendor_contact_value();
                        load_vendor_state_value();
                        load_vendor_district_value();
                        $("#total_quantity").val('');
                        $("#purchased_date").val('');
                        $("#rate_per_unit").val('');
                        $("#total_price").val('');
                        $("#vendor_address").val('');
                        $("#remarks").val('');


                    }
                }
            });
        }
    }

    // show item
    function showitem() {
        var displaydata = "displaydata";
        $.ajax({
            url: "Stock_Entry_Backend.php",
            type: "post",
            dataType: "json",
            data: {
                displaydata: displaydata
            },
            success: function(response) {
                if (response.length > 0) {
                    var data = '';
                    var S_No = 0;
                    for (var a = 0; a < response.length; a++) {
                        S_No++;
                        var stock_name = response[a].item_name;
                        var stock_qty = response[a].stock_qty;
                        var stock_purchased_date = response[a].stock_purchased_date;
                        var stock_price = response[a].rate_per_unit;
                        var stock_total_price = response[a].total_rate;
                        var vendor_name = response[a].vendor_name;
                        var stock_remarks = response[a].stock_remarks;
                        data = data + '<tr><td>' + S_No + '</td><td>' + stock_name + '</td><td>' + stock_qty + '</td><td>' + stock_purchased_date + '</td><td>' + stock_price + '</td><td>' + stock_total_price + '</td><td>' + vendor_name + '</td><td>' + stock_remarks + '</td></tr>';
                        // <td><a class="btn btn-primary m-1">Edit</a><a class="btn btn-danger m-1">Delete</a></td></tr>';
                    }
                    $("#table_body").html(data);
                }
            }
        });
    }


    // add a new product
    function addnewitem() {
        // alert("hello");
        if (($('#new_item_name').val() == '') || ($('#new_p_qtytotal').val() == 0) || ($('#new_p_category option:selected').text() == "--select category--") || ($('#new_p_category').val() == 0) || ($('#new_p_variety').val() == 0) || ($('#new_p_variety option:selected').text() == "--select variety--") || ($('#new_p_type').val() == 0) || ($('#new_p_type option:selected').text() == "--select type--") || ($('#new_p_unit').val() == 0) || ($('#new_p_unit option:selected').text() == "--select unit--")) {
            Swal.fire("No Empty Field!!");
            $('#exampleModal').modal('hide');
        } else {

            var name = "name";
            var name_text = $('#new_item_name').val();
            // var name_text = $('#new_item_name option:selected').text();

            var qtytotal = $('#new_p_qtytotal').val();


            var category = $('#new_p_category').val();
            var category_text = $('#new_p_category option:selected').text();

            var variety = $('#new_p_variety').val();
            var variety_text = $('#new_p_variety option:selected').text();
            // alert(variety_text);
            var type = $('#new_p_type').val();
            var type_text = $('#new_p_type option:selected').text();

            var unit = $('#new_p_unit').val();
            var unit_text = $('#new_p_unit option:selected').text();
            var image = '';

            $.ajax({
                url: 'Product_Master_Backend.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    name: name,
                    qtytotal: qtytotal,
                    category: category,
                    variety: variety,
                    type: type,
                    unit: unit,
                    image: image,

                    name_text: name_text,
                    category_text: category_text,
                    variety_text: variety_text,
                    type_text: type_text,
                    unit_text: unit_text
                },
                success: function(response) {
                    if (response == 1) {

                        showitem();
                        $('#addnewModal').modal('hide');
                        $('#exampleModal').modal('show');

                        Swal.fire('Product added successfully!');

                    } else if (response == 0) {
                        $('#addnewModal').modal('hide');
                        Swal.fire('duplicate data found');

                    }
                    $('#p_qtytotal').val('');

                    showitem();

                    load_item_name_value();
                    load_vendor_name_value();
                    load_vendor_contact_value();
                    load_vendor_state_value();
                    load_vendor_district_value();



                }

            });
        }
    }
    // loading category for new item 

    function load_new_values() {
        var display1 = 'display1';
        $.ajax({
            url: 'Product_Master_Backend.php',
            type: 'POST',
            dataType: 'JSON',
            data: {
                display1: display1
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = '<option disabled selected>--select category--</option>';
                    for (var a = 0; a < response.length; a++) {
                        var value = response[a].category_name;
                        var category_id = response[a].ca_id;

                        // alert(value);
                        optn_body = optn_body + '<option value="' + category_id + '">' + value + '</option>';
                    }
                    // $("#select").html(optn_body);
                    document.getElementById('new_p_category').innerHTML = optn_body;

                }
            }
        });
    }
    // loading variety for new item 

    function load_new_values3() {
        var display3 = 'display3';
        $.ajax({
            url: 'Product_Master_Backend.php',
            type: 'POST',
            dataType: 'JSON',
            data: {
                display3: display3
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = '<option disabled selected>--select variety--</option>';
                    for (var a = 0; a < response.length; a++) {
                        var value = response[a].var_name;
                        var variety_id = response[a].var_id;

                        // alert(value);
                        optn_body = optn_body + '<option value="' + variety_id + '">' + value + '</option>';
                    }
                    // $("#select").html(optn_body);
                    document.getElementById('new_p_variety').innerHTML = optn_body;
                }
            }
        });
    }

    // loading type for new item 

    function load_new_values4() {
        var display4 = 'display4';
        $.ajax({
            url: 'Product_Master_Backend.php',
            type: 'POST',
            dataType: 'JSON',
            data: {
                display4: display4
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = '<option disabled selected>--select type--</option>';
                    for (var a = 0; a < response.length; a++) {
                        var value = response[a].product_type_name;
                        var product_type_id = response[a].t_id;

                        // alert(value);
                        optn_body = optn_body + '<option value="' + product_type_id + '">' + value + '</option>';
                    }
                    // $("#select").html(optn_body);
                    document.getElementById('new_p_type').innerHTML = optn_body;
                }
            }
        });
    }

    // loading unit for new item 
    function load_new_values5() {
        var display5 = 'display5';
        $.ajax({
            url: 'Product_Master_Backend.php',
            type: 'POST',
            dataType: 'JSON',
            data: {
                display5: display5
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = '<option disabled selected>--select unit--</option>';
                    for (var a = 0; a < response.length; a++) {
                        var value = response[a].unit_type;
                        var product_unit_id = response[a].unit_id;

                        // alert(value);
                        optn_body = optn_body + '<option value="' + product_unit_id + '">' + value + '</option>';
                    }
                    // $("#select").html(optn_body);
                    document.getElementById('new_p_unit').innerHTML = optn_body;
                }
            }
        });
    }


    // loading details of vendor
    $("#vendor_name").on('change', function() {
            var value = $(this).val();
            var get_vendor_name_to_set_its_detail = "get_vendor_name_to_set_its_detail";
            $.ajax({
                url:"Stock_Entry_Backend.php",
                type:'post',
                dataType:'json',
                data:{
                    get_vendor_name_to_set_its_detail:get_vendor_name_to_set_its_detail,
                    value:value
                },
                success:function(response){
                    if(response.length>0){
                        $("#vendor_contact").val(response[0].vendor_contact).trigger('change');
                        $("#vendor_address").val(response[0].vendor_address).trigger('change');
                        $("#vendor_state").val(response[0].vendor_state).trigger('change');
                        $("#vendor_district").val(response[0].vendor_district).trigger('change');

                    }
                }
            });
        });
</script>