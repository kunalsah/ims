<?php include("top_header.php"); ?>
<?php require("connection.php"); ?>


<?php
$user_type="by admin";
$id = $_POST['id'];
$value = $_POST['value'];
$sql = "UPDATE request_item SET priority='$value' WHERE request_serial=$id";
$result = mysqli_query($conn,$sql);
// echo $id;
// echo $value;
if($result){
    header("Location: ".$_SERVER['HTTP_REFERER']);
    
}else{
    die(mysqli_error($conn)); 
}

?>