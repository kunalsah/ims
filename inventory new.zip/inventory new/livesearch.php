<?php
include("connection.php");
if(isset($_POST['input'])){
    $input=$_POST['input'];
    // $query="select * from tb_data where name LIKE '{$input}%' OR rollnumber LIKE '{$input}%' OR branch LIKE '{$input}%' OR semester LIKE '{$input}%' OR city LIKE '{$input}%' OR id LIKE '{$input}%'";

    $sql="SELECT * FROM `request_tbl` INNER JOIN member_list on request_tbl.request_user=member_list.m_id INNER JOIN request_item on request_tbl.request_id=request_item.r_id INNER  JOIN product_list on request_item.rp_id=product_list.p_id where  r_accept_status='NO' AND (`m_name` like '%$input%' OR `priority` like '%$input%' OR `p_name` like '%$input%')";

    $result = mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)>0){
        ?>

<table class="table table-bordered table-hover">

    <tr>
            <th class="text-center">Name</th>
            <th class="text-center">Product Name</th>
            <th class="text-center">Request Date</th>
            <th class="text-center">Priority</th>
            <th class="text-center">Operations</th>
        </tr>
    
        <?php
        while($row = mysqli_fetch_assoc($result)){
            $request_id = $row['m_name'];
            $request_date = $row['request_date'];
            $request_product_name = $row['p_name'];
            $id=$row['m_id'];
            $priority=$row['priority'];
            
            if ($priority == 'Normal') {
                $style = 'style="color:green"';
            } else {
                $style = 'style="color:red"';

            }

            echo '
            <tr>
            <td class="text-center">' . $request_id . '</td>
            <td class="text-center">' . $request_product_name . '</td>
            <td class="text-center">' . $request_date . '</td>
            <td class="text-center" ' . $style . '>' . $priority . '</td>
            <td class="text-center"><button type="View" class="btn btn-primary"><a href="view_request.php?m_id='.$id.'" style="text-decoration: none;color:white;">View</a></button></td>
            </tr>
        ';
            
        }
        ?>
    
    </table>
<?php
    }else{
            echo"<h6>No data found</h6>";
        }
    }

?>