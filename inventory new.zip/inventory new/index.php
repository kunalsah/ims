<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Inventry Login</title>
</head>
<body>
    <div class="container">
    <div class="loginBody">
        <form action="">
            <div class="loginheader">
                <p>INVENTRY MANAGMENT SYSTEM</p>
            </div>
            <div class="image">
                <img src="img/logo1.png" alt="">
            </div>
            <div class="head">
                <P>User Login</P>
            </div>
        <div class="contain">
            <input class="login_txt" type="text" placeholder="Enter Your Username">
        </div>
        <div class="contain">
            <input class="login_txt" type="password" placeholder="Enter Your Password">
        </div >
        <div class="btn">
            <a href="userdash.php"><h3>Log-in</h3></a>
        </div>
        <div class="link">
            <a href="">Forget password?</a>
        </div>
        
    </div>
    
</form>
</div>
</body>
</html>