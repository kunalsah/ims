<?php require('../connection.php'); ?>
<label for="College">College :</label>
<select name="" id="" placeholder="select">

    <?php $sql = "SELECT DISTINCT(m_clg) FROM member_list;";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        while ($row = mysqli_fetch_column($result)) {
            echo '
    <option value="'.$row.'">'.$row.'</option>
    ';
        }
    }
    ?>

</select> 