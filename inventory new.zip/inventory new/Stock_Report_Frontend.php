<?php include("top_header.php");
include("sidebar_upper.php");
require("connection.php"); ?>

<style>
    input{
        width: 50%;
        height: 40px;
       border-radius: 5px;
       border-width: 3px;
       margin-right: 50px;
    }

    
    /* .icons{
        margin-top: 10px;
    } */
</style>



<div class="container card mt-2 search_result" style="box-shadow:0 0 5px #a8a8a8;">
    <h3 class="text-center mt-2">Stock Report Entry Table</h3>
    <!-- <input type="search" class="m-4 " placeholder="Search" id="live_search" > -->
    <div class="input-group ">

                   
                    <!-- <i class="icons bi bi-search"></i> -->
        
                
                <input class="form-control border-end-4 border rounded-pill m-4 col-4" type="search" placeholder="search product........" id="live_search">
                
                <label for="" class="mt-4">Total Quantity:</label>
                <span class="m-4" id="sum"></span>
            </div>
    <!-- loader img -->
   
    
</div>
<div id="loader" style="display: none;" >
        <img src="img/load.gif" style="height:20%;width:20%;display:block;margin-left:auto;margin-right:auto;" alt="">
    </div>

<!-- <div id="search_result"></div> -->
<table class="table mt-5 border">
                    <tr class="primary" style="background-color: blue;">
                        <th><b>S. No.</b></th>
                        <th><b>Stock Name<b></th>
                        <th><b>Stock Quantity<b></th>
                        <th><b>Purchase Date<b></th>
                        <th><b>Per Unit rate<b></th>
                        <th><b>Total rate<b></th>
                        <th><b>Vendor Name<b></th>
                    </tr>
                    <tbody id="search_result" class="Data">

                    </tbody>



                </table>
                <p class="m-4 text-center"></p>
        

<?php include("sidebar_lower.php"); ?>

<!-- search box -->
<script type="text/javascript">
    $(document).ready(function () {

        $('#live_search').keyup(function () {
            var input = $(this).val();
            var search='search';
            
            // alert(input); 
            
            
            if(input ==""){
                $('#search_result').html('');
                $('#sum').html('');
                $('p').html('');
               
        }else{
            $.ajax({
                url: "Stock_Report_Backend.php",
                method: "POST",
                dataType:'json',
                data: { input: input ,search:search},

                beforeSend: function(){
                    $('#loader').show();

                },

                success: function (response) {
                    // alert(response.length);
                    if (response.length > 0) {
                    var Q = 0;
                    var s_body = "";
                    for (var a = 0; a < response.length; a++) {
                        Q++;
                        var g = response[a].stock_id;
                        var b = response[a].item_name;
                        var c = response[a].stock_qty;
                        var d = response[a].stock_purchased_date;
                        var e = response[a].rate_per_unit;
                        var f = response[a].total_rate;
                        var h = response[a].vendor_name;
                        // alert(h);



                        s_body = s_body + '<tr>' +
                            '<td>' + Q + '</td>\
                            <td>' + b + '</td>\
                            <td class="total">' + c + '</td>\
                            <td>' + d + '</td>\
                            <td>' + e + '</td>\
                            <td>' + f + '</td>\
                            <td>' + h + '</td>\
                            </tr>';
                    }
                    $('#search_result').html(s_body);
                    var sum = 0;
                $(".total").each(function(){
                  sum += parseFloat($(this).text());
                });
                $('#sum').text(sum);
                    // $('#search_result').css("display", "block");
                }
                else{
                    $('p').html('<h1>NO DATA FOUND!</h1>');
                }
                    // $('#search_result').html(response);
                },
                complete:function(response){
                    $('#loader').hide();
                }
            });
        }
        

        });
    });        
</script>