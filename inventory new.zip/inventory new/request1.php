<?php
include('top_header.php');
include('sidebar_upper.php');
include("department_fetch.php");
require('connection.php');
include('employee_additem.php');
?>

<style>
   

  .dropdown {
    display: inline-block;
    position: relative;

  }

  .dropdown-content {
    display: none;
    position: absolute;
    z-index:5;
    width: 100%;
    overflow: auto;
    box-shadow: 0px 10px 10px 0px rgba(0, 0, 0, 0.4);
    background: white;
    cursor: pointer;
    border-radius: 0 0 5px 5px;
  }

  .dropdown:hover .dropdown-content {
    display: block;
  }

  .dropdown-content a {
    position: relative;
    display: block;
    color: #000000;
    padding: 5px;
    text-decoration: none;
    
  }

  .dropdown-content a:hover {
    color: #FFFFFF;
    background-color: #00A4BD;
  }
  li:hover{
    background-color: #DAF5FF;
  }
</style>


<head>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>

  <script type="text/javascript">
    $(document).ready(function () {
      var x = 1;
      var prevalue="";
    var str ="";
    var did1="";

      //alert(formatDate());
      var datetoday = formatDate();

      var max = 5;
      var prevalue="";
    var str ="";

      $(document).on('keyup', '.namee', function () {
        
        // var x=1;
        var did = $(this).data('name');
       // alert(did);
        var splitid = did.split('_');
       // alert(splitid);
        var index = splitid[1];
        // alert(index);
        var ProdName = $(this).val();
////////////////////////////////////////////////////////////////
        if (ProdName != "") {
          $.ajax({
            url: 'checkduplicate.php',
            type: 'POST',
           // dataType: 'json',
            data: { value: ProdName,variable2:str},
            success: function (data) {
              //alert(data[0].p_name);
              $("#result-box" + index).fadeIn();
              $("#result-box" + index).html(data);
              //$("#result-box" + index).css("display", "block");
            }
          });
        }
        else {

          $("#result-box" + index).css("display", "none");
        }
//////////////////////////////////////////////////////////////////
        $("#result-box" + index).on('click','li',function () {
          var span_Text = $(this).text();

          $("#abc" + index).val(span_Text);
          did1 = $(this).data('man');
          prevalue += did1+",";
         
          str =  prevalue.substring(0,prevalue.length - 1);
           // alert(prevalue);

          $("#result-box" + index).css("display", "none");
          removeElement();
        
        });
        
      });

//////////////////////////////////////////////


      //////////////////////////////////////
      $('#add').click(function () {
        if (x <= max) {
          var html = '<tr><td><div class="dropdown"><input autocomplete="off" class="form-control namee" data-name="id_' + x + '" id="abc' + x + '" type="text" name="txtName[]" required=""><div class="dropdown-content resultt" id="result-box' + x + '"></div></div></td><td><input class="form-control" type="number" name="txtQty[]" required=""></td><td><select name="ReqDep[]" class="form-select form-control" required=""><option disabled selected>Select Department</option><?php foreach ($options as $option) {?><option><?php echo $option['department_name']; ?> </option><?php }?></select></td><td><select class="form-select" name="Priority[]" aria-label="Default select example" required=""><option value="Normal">Normal</option><option value="Urgent">Urgent</option></select></td><td><input class="form-control" type="text" name="txtReason[]" required=""></td><td><input class="btn btn-danger" type="button" name="remove" id="remove" value="remove"></td></tr>';
          $('#table_field').append(html);
          x++;
        }
      });

      $('#table_field').on('click', '#remove', function () {
        $(this).closest('tr').remove();
        x--;
      });



    });
</script>
</head>
<div id="page-wrapper">
  <div class="main-page">

    <form class="insert-form" id="insert_form" method="post" action="">
      <hr>
      <h3 class="text-center">Request Item</h3>
      
      <hr>
      <div class="input-field">
        <table class="table table-bordered" id="table_field">
          <tr>
            <th>Product Name</th>
            <th>Product Qty</th>
            <th>Department</th>
            <th>Priority</th> 
            <th>Reason</th>
            <th>Add Or Remove</th>
          </tr>
          <?php
          $conn = mysqli_connect("localhost", "root", "", "inventory_db");
          $email = 'mantasha@gmail.com';

          $q1 = "SELECT m_id FROM member_list WHERE m_email='$email'";
          $r1 = mysqli_query($conn, $q1);

          while ($rows = $r1->fetch_assoc()) {
            $m_id = $rows['m_id'];
          }
          $current_date = date("Y-m-d H:i:s");
          
          //echo $m_id;  
          
          if (isset($_POST['save'])) {

            $prodtype = 'Consumable';
            $txtName = $_POST['txtName'];
            // $txtDepartment =$_POST['department'];
            $txtReason = $_POST['txtReason'];
            $txtQty = $_POST['txtQty'];
            //$txtDate = $_POST['txtDate'];
            $txtPriority=$_POST['Priority'];
            $ReqDep=$_POST['ReqDep'];
            $Send_to=$_POST['Send_to'];
            $currentDate = date('Y-m-d');

            //query for inserting in request table
            $request1 = "INSERT INTO request_tbl(request_id,request_date, request_user, request_status, deliever_status,received_status, `status`) VALUES ('','$current_date','$m_id','request','request','request','1')";
            $q1 = mysqli_query($conn, $request1);
            if ($q1) {
              // echo "Successfully Requested";
            }

            $q2 = "SELECT MAX(request_id) FROM request_tbl";
            $q1 = mysqli_query($conn, $q2);

            while ($rows = $q1->fetch_assoc()) {
              $t_id = $rows['MAX(request_id)'];
            }
            // query for inserting in request items 
            foreach ($txtName as $key => $value) {

              $save = "SELECT p_id FROM product_list WHERE p_name='$value'";

              $query2 = mysqli_query($conn, $save);
              while ($row = $query2->fetch_assoc()) {
                $txtId = $row['p_id'];
              }

              $request2 = "INSERT INTO `request_item`(`rp_id`,`req_mem_id`, `r_id`, `r_qty`,`updated_by`,`priority`,`req_dep`, `reason`,
              `r_fd`, `r_td`, `r_days`, `request_to`,`r_accept_status`, `r_accept_by`, `r_accept_on`, 
              `r_received_status`, `r_received_by`, `r_received_on`, `r_return_status`, 
              `r_return_by`, `r_return_on`) VALUES ('$txtId','$m_id','$t_id','" . $txtQty[$key] . "','NIL','" . $txtPriority[$key] . "','".$ReqDep[$key]."',
              '" . $txtReason[$key] . "','" .$currentDate. "','','','$Send_to','NO',
              '','','NO','','','NO','','')";

              $q2 = mysqli_query($conn, $request2);
              if ($q2) {
                // echo "Successfully Requested";
              }
            }

            if($request1 & $request2){
              ?>
              <script>swal.fire({
                title: "SUCCESS!",
                text: "Your Order is placed successfully",
                icon: "success",
              });</script>
              <?php
            }else{
              ?>
              <script>swal.fire({
                title: "FAILURE!",
                text: "Something Happend!!!",
                icon: "error",
              });</script>
              <?php
            }
          }

          ?>

          <tr>

            <td>
              <div class="dropdown"><input autocomplete="off" class="form-control namee" data-name="id_0" id="abc0" type="text" name="txtName[]" data-tt="0"
                  required="">

                <span class="dropdown-content resultt" id="result-box0"></span>
                <div>
            </td>
            <td><input class="form-control" type="number" name="txtQty[]" required=""></td>

            <td>
              
            <select name="ReqDep[]" class="form-select form-control" required="">
           <option disabled selected>Select Department</option>
  <?php 
  foreach ($options as $option) {
  ?>
    <option><?php echo $option['department_name']; ?> </option>
    <?php 
    }
   ?>
</select>
</td>

            <td>
            <select class="form-select form-control" name="Priority[]" aria-label="Default select example" required="">
              <option value="Normal">Normal</option>
              <option value="Urgent">Urgent</option>
            </select>
        </td>
            <td><input class="form-control" type="text" name="txtReason[]" required=""></td>
            <td><input class="btn btn-warning" type="button" name="adda" id="add" value="Add"></td>
          </tr>
        </table>

        <center>

        <div class="row">
          <div class="col-md-4"></div>
          <div class="col-md-4">
          <label for="send">Send Request To </label>
        <select class="form-select form-control" id="send" name="Send_to" aria-label="Default select example" required="">
        <option disabled selected>Requested To</option>
              <option value="Principal">Principal</option>
              <option value="Assistant Director">Assistant Director</option>
              <option value="Chairman">Chairman</option>
              <option value="Director">Director</option>
             
            </select>
            </div>
            <div class="col-md-4"></div>

        </div>
  </br>

        </center>

        <center>
          <input class="btn btn-success" type="submit" name="save" id="save" value="Request">
        </center>
      </div>

    </form>



  </div>
</div>

<!-- history table  -->
<div class="col-md-12 my-3">
            <div class="card" style="box-shadow:0 0 5px #a8a8a8;">
                <h3 class="text-center shadow-sm pb-1" style="font-family: 'Montserrat', sans-serif; font-weight:300;">
                    Requests History</h3>
                <div class="content" style="overflow: hidden; overflow-y: scroll; height:70vh;">
                    <!-- content of the request history table starts here -->
                    <table class="table table-bordered table-hover" style="text-align: center;">
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Unit</th>
                            <th>Request Date</th>
                            <th>Request Status</th>
                            <th>Reject Reason</th>
                            <th>Recieve Date</th>
                        </tr>
                        <?php
                        // if (isset($_GET['m_id'])) {
                        //     $m_id = $_GET['m_id'];
                        // }
                        // $sql = "SELECT * FROM member_list where m_id=$id";
                        $sql = "SELECT * FROM `request_tbl` INNER JOIN request_item on request_tbl.request_id=request_item.r_id INNER JOIN product_list on product_list.p_id=request_item.rp_id where (r_accept_status='Accepted' or r_accept_status='Rejected') AND request_user='$m_id' order by request_date desc";
                        $result = mysqli_query($conn, $sql);
                        while ($row = mysqli_fetch_assoc($result)) {
                            $product_name = $row['p_name'];
                            $product_quantity = $row['r_qty'];
                            $unit = $row['p_unit'];
                            $request_date = $row['request_date'];
                            $recieve_date=$row['r_received_on'];
                            $request_serial=$row['request_serial'];
                            $request_status=$row['r_accept_status'];
                            $reject_reason=$row['reason_a_r'];

                            if($request_status=='Accepted'){
                              $style = 'style="color:green"';
                          }
                          else{
                              $style = 'style="color:red"';

                          }

                            echo '
                        <tr>
                            <td>' . $product_name . '</td>
                            <td>' . $product_quantity . '</td>
                            <td>' . $unit . '</td>
                            <td>' . $request_date . '</td>
                            <td '.$style.'>' . $request_status . '</td>
                            <td>' . $reject_reason . '</td>
                            <td>' . $recieve_date . '</td>

                        </tr>
                        ';
                        }

                        ?>
                    </table>
                    <!-- content of the request history table ends here -->
                </div>
            </div>
        </div>
<!-- history table  -->


<script>
  const dateInput = document.getElementById('date');


  dateInput.value = formatDate();
  const date = formatDate();

  console.log(formatDate());

  function padTo2Digits(num) {
    return num.toString().padStart(2, '0');
  }

  function formatDate(date = new Date()) {
    return [
      date.getFullYear(),
      padTo2Digits(date.getMonth() + 1),
      padTo2Digits(date.getDate()),
    ].join('-');
  }
</script>



<?php
include("sidebar_lower.php");
?>