<?php
include('connection.php');

// display product name
if (isset($_POST['display_issue_report'])) {
    $sql = "SELECT
    it.issued_product_id,
    GROUP_CONCAT(
        im.item_name
    ORDER BY
        FIND_IN_SET(
            pm.product_id,
            it.issued_product_id
        )
    ) AS concatenated_item_names,
    member_list.m_name,
    it.issued_by_id,
    it.order_taken_by,
    it.date,
    it.issued_product_id,
    it.issued_product_quantity,
    department_list.department_name,
    it.issued_product_approved_by,
    it.type_of_order
FROM
    issue_table it
INNER JOIN member_list ON member_list.m_id = it.issue_member_id
INNER JOIN department_list ON department_list.department_id = it.issue_for_department

INNER JOIN product_master pm ON FIND_IN_SET(pm.product_id, it.issued_product_id)
INNER JOIN item_master im ON im.item_id = pm.product_name
GROUP BY
    it.issued_product_id;";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $result_array = array();
        while ($row = mysqli_fetch_array($result)) {
            $result_array[] = $row;
            // print_r($result_array);
        }
        // print_r($result_array);
        echo json_encode($result_array);
    }
}

if (isset($_POST['live_search'])) {
    $input = $_POST['input'];
    $sql = "SELECT
    it.issued_product_id,
    GROUP_CONCAT(
        im.item_name
    ORDER BY
        FIND_IN_SET(
            pm.product_id,
            it.issued_product_id
        )
    ) AS concatenated_item_names,
    GROUP_CONCAT(
        pm.product_id
    ORDER BY
        FIND_IN_SET(
            pm.product_id,
            it.issued_product_id
        )
    ) AS concatenated_product_id,
    member_list.m_name,
    it.issued_by_id,
    it.order_taken_by,
    it.date,
    it.issued_product_id,
    it.issued_product_quantity,
    department_list.department_name,
    it.issued_product_approved_by,
    it.type_of_order
FROM
    issue_table it
INNER JOIN member_list ON member_list.m_id = it.issue_member_id
INNER JOIN department_list ON department_list.department_id = it.issue_for_department
INNER JOIN product_master pm ON
    FIND_IN_SET(
        pm.product_id,
        it.issued_product_id
    )
INNER JOIN item_master im ON
    im.item_id = pm.product_name
WHERE
    (
        `m_name` LIKE '%$input%' OR `department_name` LIKE '%$input%' OR `issued_product_approved_by` LIKE '%$input%' OR `date` LIKE '%$input%' OR `item_name` LIKE '%$input%'
    )
GROUP BY
    it.issued_product_id;";
// print_r($sql);
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $result_array = array();
        while ($row = mysqli_fetch_array($result)) {
            $result_array[] = $row;
            // print_r($result_array);
        }
        // print_r($result_array);
        echo json_encode($result_array);
    }else{
        echo 0;
    }
}


///display stock data 
if (isset($_POST['item_id'])) {
    $item=$_POST['item_id'];
   // echo $item;
    $sql="Select * from stock_master where Stock_Product_Name='$item'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $result_array = array();
        while ($row = mysqli_fetch_array($result)) {
            $result_array[] = $row;
            // print_r($result_array);
        }
        // print_r($result_array);
        echo json_encode($result_array);
    }else{
        echo 0;
    }
}
