<?php
include('top_header.php');
include('sidebar_upper.php');

?>

<div class="tables mt-3">
    <h2 class="title1">Stock Entry Report Table</h2>

    <div class="table-responsive">
        <div class="card m-4 col-6 p-2" style="box-shadow:0 0 5px #a8a8a8;">
    <table border="0" cellspacing="5" cellpadding="5">
        <tbody><tr>
            <td>From Date:</td>
            <td><input  class="form-control col-10" type="text" id="min" name="min" placeholder="MM/DD/YYYY"></td>
        
            <td>To Date:</td>
            <td><input  class="form-control col-10" type="text" id="max" name="max" placeholder="MM/DD/YYYY"></td>
        </tr>
    </tbody></table>
    </div>
        <table class="table" style="box-shadow:0 0 5px #a8a8a8;" border=3 id="mydata">
            <thead>
                <tr>
                    <th>S No.</th>
                    <th>Stock Name</th>
                    <th>Quantity</th>
                    <th>Date</th>
                    <th>Rate</th>
                    <th>Total Price</th>
                    <th>Vendor</th>
                   
                    <!-- <th>Operations</th> -->
                </tr>
            </thead>
            <tbody id="table_body" class="Data">

            </tbody>

        </table>

    </div>
</div>

<?php
include("sidebar_lower.php");
?>



    <script>
          $(document).ready(function(){
               showitem();
          });
    
    
         function showitem() {
            var displaydata = "displaydata";
            $.ajax({
                url: "Stock_Report_Backend.php",
                type: "post",
                dataType: "json",
                data: {
                    displaydata: displaydata
                },
                success: function(response) {
                    if (response.length > 0) {
                        var data = '';
                        var S_No = 0;
                        for (var a = 0; a < response.length; a++) {
                            S_No++;
                            var stock_name = response[a].item_name;
                            var stock_qty = response[a].stock_qty;
                            var stock_purchased_date = response[a].stock_purchased_date;
                            var stock_price = response[a].rate_per_unit;
                            var stock_total_price = response[a].total_rate;
                            var vendor_name = response[a].vendor_name;
                            
                            data = data + '<tr><td>' + S_No + '</td><td>' + stock_name + '</td><td>' + stock_qty + '</td><td>' + stock_purchased_date + '</td><td>' + stock_price + '</td><td>' + stock_total_price + '</td><td>' + vendor_name + '</td></tr>';
                            // <td><a class="btn btn-primary m-1">Edit</a><a class="btn btn-danger m-1">Delete</a></td></tr>';
                        }
                        $("#table_body").html(data);

                        let minDate, maxDate;
 
// Custom filtering function which will search data in column four between two values
DataTable.ext.search.push(function (settings, data, dataIndex) {
    let min = minDate.val();
    let max = maxDate.val();
    let date = new Date(data[3]);
 
    if (
        (min === null && max === null) ||
        (min === null && date <= max) ||
        (min <= date && max === null) ||
        (min <= date && date <= max)
    ) {
        return true;
    }
    return false;
});
 
// Create date inputs
minDate = new DateTime('#min', {
    format: 'MMMM Do YYYY'
});
maxDate = new DateTime('#max', {
    format: 'MMMM Do YYYY'
});
 
// DataTables initialisation
let table = new DataTable('#mydata',{
    responsive: true, "order": [], dom: 'lBfrtip', buttons: [ 'excel', 'pdf', 'print' ],
});
 
// Refilter the table
document.querySelectorAll('#min, #max').forEach((el) => {
    el.addEventListener('change', () => table.draw());
});

                        
                    }
                }
            });
        }

    </script>

    