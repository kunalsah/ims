<?php

    $output='';
    $i=0;
include("connection.php");

    $search = $_POST["value"];
    //$search='1';
    
    
    $SQL = "SELECT * FROM update_history WHERE  request_id='$search'";
    $result=mysqli_query($conn,$SQL);


$output.='
<div class="table-responsive">
    <table class="table table-bordered">
    <tr>
    <th width="30%">S. No.</th>
    <th width="30%">Initial Qty</th>
    <th width="30%">Updated Qty</th>
    <th width="30%">Updated By</th>
    <th width="30%">Updated On</th>
    </tr>';
    if(mysqli_num_rows($result)>0){
        while($row=mysqli_fetch_assoc($result)){
            $i++;
            $output.='
        <tr>
        <td width="70%">'.$i.'</td>
        <td width="70%">'.$row["initial_qty"].'</td>
        <td width="70%">'.$row["updated_qty"].'</td>
        <td width="70%">'.$row["updated_by"] .'</td>
        <td width="70%">'.$row["updated_on"] .'</td>
      </tr>';
        }
    }else{
        $output="no results";
    }

    $output.="</table></div>";
    echo $output;
?>