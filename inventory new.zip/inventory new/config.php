<?php 
$conn=mysqli_connect("localhost","root","","inventory_db");
if($conn){
    // echo "connected";
}
else{
    echo("failed");
}
?>