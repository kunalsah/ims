<?php include("top_header.php");
include("sidebar_upper.php");
require("connection.php");
if (isset($_GET['m_id'])) {
    $id = $_GET['m_id'];
}
$sql = "SELECT * FROM member_list where m_id='$id'";
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($result)) {
    $name = $row['m_name'];
    $email = $row['m_email'];
    $designation = $row['m_designation'];
    $clg = $row['m_clg'];
    $department = $row['m_department'];
    $contact = $row['m_contact'];
    $gender = $row['m_gender'];
    $image = $row['m_image'];
}

if(isset($_GET[''])){

}
?>

<div class="container card mt-1" style="box-shadow:0 0 5px #a8a8a8;">
    <div class="row">
        <div class="col-md-2" style="text-align: center;">
            <img src="img/member/<?php echo $image ?>" alt="" class="img_profile" style="width: 150px; height: 150px; border: 3px solid whitesmoke; border-radius: 50%;">
        </div>
        <div class="col-md-5">
            <div class="">
                <div class="name m-1 fs-5 ">
                    <label class="fw-bold" for="name">Name :</label>
                    <span id="name">
                        <?php echo $name ?>
                    </span>
                </div>

                <div class="post m-1 fs-5">
                    <label class="fw-bold" for="post">Post :</label>
                    <span id="post">
                        <?php echo $designation ?>
                    </span>
                </div>
                <div class="block m-1 fs-5">
                    <label class="fw-bold" for="block">Block :</label>
                    <span id="block">
                        <?php echo $clg ?>
                    </span>
                </div>
                <div class="department m-1 fs-5">
                    <label class="fw-bold" for="department">Department :</label>
                    <span id="department">
                        <?php echo $department ?>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="Contact m-1 fs-5">
                <label class="fw-bold" for="Contact">Contact :</label>
                <span id="Contact">
                    <?php echo $contact ?>
                </span>
            </div>
            <div class="mail m-1 fs-5">
                <label class="fw-bold" for="mail">Mail Id :</label>
                <span id="mail">
                    <?php echo $email ?>
                </span>
            </div>
            <!-- <div class="address m-1 fs-5">
                <label class="fw-bold" for="address">Address :</label>
                <span id="address"></span>
            </div> -->
            <div class="gender m-1 fs-5">
                <label class="fw-bold" for="gender">Gender :</label>
                <span id="gender">
                    <?php echo $gender ?>
                </span>
            </div>


        </div>
    </div>
</div>
<div class="container-fluid mt-2">
    <div class="row">
        <div class="col-md-6">
            <div class="card " style="box-shadow:0 0 5px #a8a8a8;">
                <h3 class="text-center shadow-sm pb-1" style="font-family: 'Montserrat', sans-serif; font-weight:300;">
                    Pending Requests</h3>
                <div class="content" style="overflow: hidden; overflow-y: scroll; height:70vh;">

                    <!-- content of the pending request 
                     starts here -->

                    <table class="table table-bordered table-hover" style="text-align: center;">
                        <tr style="position: sticky; top: 0; background-color:white;">
                            <th>Prdt</th>
                            <th>qty</th>
                            <th>Unit</th>
                            <th>RqstDte</th>
                            <th>Prty</th>
                            <th>Resn</th>
                            <th>Qtyupdt</th>
                            <th>Opt</th>
                        </tr>
                        <?php
                        if (isset($_GET['m_id'])) {
                            $id = $_GET['m_id'];
                        }
                        // $sql = "SELECT * FROM member_list where m_id=$id";
                        $sql = "SELECT * FROM `request_tbl` INNER JOIN request_item on request_tbl.request_id=request_item.r_id INNER JOIN product_list on product_list.p_id=request_item.rp_id where r_accept_status='NO' AND request_user=$id";
                        $result = mysqli_query($conn, $sql);
                        while ($row = mysqli_fetch_assoc($result)) {
                            $product_name = $row['p_name'];
                            $product_quantity = $row['r_qty'];
                            $unit = $row['p_unit'];
                            $request_date = $row['request_date'];
                            $updated_by = $row['updated_by'];
                            $request_serial = $row['request_serial'];
                            $priority = $row['priority'];
                            $reason = $row['reason'];
                            $style1 = 'style="color:blue; text-decoration: none;"';

                            if ($priority == 'Normal') {
                                $style = 'style="color:green; text-decoration: none;"';
                            } else {
                                $style = 'style="color:red; text-decoration: none;"';
                            }

                            echo '
                        <tr>
                            <td>' . $product_name . '</td>
                            <td><a ' . $style1 . 'data-toggle="tooltip" data-placement="top"  data-qty="'.$request_serial.'"  title="Updated History" class="pri_modal1" data-pid="' . $request_serial . '"  href="#">' . $product_quantity . '</a></td>
                            <td>' . $unit . '</td>
                            <td>' . $request_date . '</td>
                            <td ><a ' . $style . ' data-toggle="tooltip" data-placement="top" title="Update Priority" class="pri_modal" data-pid="' . $request_serial . '"  href="#">' . $priority . '</a></td>
                            <td>' . $reason . '</td>
                            <td>' . $updated_by . '</td>
                            <td style="display: grid;">
                            <a data-toggle="tooltip" data-placement="top" title="Update Quantity" class="mymodal btn m-1 btn-primary" data-id="' . $request_serial . '"  href="#"><i class="bi bi-pencil-square " ></i></a>  
                            <button data-toggle="tooltip" data-placement="top" title="Accept Request" class="btn m-1 btn-success" type="allot" name="allot" id="button" "><a style="text-decoration: none; color: white;" href="allot.php?allotid=' . $request_serial . '"><i class="bi bi-check-circle-fill"></i></a> </button>
                            <a data-toggle="tooltip" data-placement="top" title="Reject Request" class="btn rejmodal m-1 btn-danger" data-uid="' . $request_serial . '"  href="#"><i class="bi bi-x-circle-fill"></i></a>
                            </td>
                        </tr>
                        ';
                        }

                        ?>
                        <!-- update Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Update Quantity</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <form action="update.php" method="post">
                                            <input type="text" id="value" name="value" required style="width: 20%;">
                                            <input type="hidden" name="id" id="serno">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- update Modal -->
                        <!-- reject Modal -->
                        <div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Reason for Reject</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <form action="delete.php" method="post">
                                            <input class="m-1" type="text" id="value" name="value" required style="width: 100%;">
                                            <input type="hidden" name="id" id="r_serno">
                                            <button type="submit" class="btn btn-primary">submit</button>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- reject Modal -->

                       

                        <!-- priority Modal -->
                        <div class="modal fade" id="priorityModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Update Priority</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <form action="priority_update.php" method="post">
                                            <select class="m-1" id="value" name="value" required style="width: 100%;">
                                                <option value="Urgent">Urgent</option>
                                                <option value="Normal" selected>Normal</option>
                                            </select>
                                            <input type="hidden" name="id" id="p_serno"></select>
                                            <button type="submit" class="btn btn-primary">submit</button>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- priority Modal -->
                    </table>
                </div>
            </div>
        </div>
        <!-- request history box -->
        <div class="col-md-6">
            <div class="card" style="box-shadow:0 0 5px #a8a8a8;">
                <h3 class="text-center shadow-sm pb-1" style="font-family: 'Montserrat', sans-serif; font-weight:300;">
                    Requests History</h3>
                <div class="content" style="overflow: hidden; overflow-y: scroll; height:70vh;">
                    <!-- content of the request history table starts here -->
                    <table class="table table-bordered table-hover" style="text-align: center;">
                        <tr style="position: sticky; top: 0; background-color:white;">
                            <!-- <th>serial</th>
                                <th>id</th>
                                <th>name</th>
                                <th>post</th>
                                <th>block</th> -->
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Unit</th>
                            <th>Qty Updated</th>
                            <th>Status</th>
                            <th>Recieve Date</th>
                        </tr>
                        <?php
                        if (isset($_GET['m_id'])) {
                            $id = $_GET['m_id'];
                        }
                        // $sql = "SELECT * FROM member_list where m_id=$id";
                        $sql = "SELECT * FROM `request_tbl` INNER JOIN request_item on request_tbl.request_id=request_item.r_id INNER JOIN product_list on product_list.p_id=request_item.rp_id where (r_accept_status='Accepted' or r_accept_status='Rejected') AND request_user=$id order by r_received_on";
                        $result = mysqli_query($conn, $sql);
                        while ($row = mysqli_fetch_assoc($result)) {
                            $product_name = $row['p_name'];
                            $product_quantity = $row['r_qty'];
                            $unit = $row['p_unit'];
                            $updated_by = $row['updated_by'];
                            $recieve_date = $row['r_received_on'];
                            $request_serial = $row['request_serial'];
                            $request_status = $row['r_accept_status'];

                            if ($request_status == 'Accepted') {
                                $style = 'style="color:green"';
                            } else {
                                $style = 'style="color:red"';
                            }
                            echo '
                        <tr>
                            <td>' . $product_name . '</td>
                            <td>' . $product_quantity . '</td>
                            <td>' . $unit . '</td>
                            <td>' . $updated_by . '</td>
                            <td ' . $style . '> ' . $request_status . '</td>
                            <td >' . $recieve_date . '</td>

                        </tr>
                        ';
                        }

                        ?>
                    </table>
                    <!-- content of the request history table ends here -->

                     <!-- update Quantity History -->
 <div class="modal fade" id="historyModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Update Quantity History</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        
                                    </div>

                                    <div class="modal-body req">


                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- update Quantity History -->

                </div>
            </div>
        </div>
    </div>
</div>

<?php
include("sidebar_lower.php");
?>

<!-- update modal -->
<script type="text/javascript">
    $(document).ready(function() {
        $(".mymodal").on("click", function() {
            // alert("hello");
            var myid = $(this).data('id');
            $("#serno").val(myid);
            $('#exampleModal').modal('show');

        });
    });
</script>
<!-- update modal -->
<!-- reject modal -->
<script type="text/javascript">
    $(document).ready(function() {
        $(".rejmodal").on("click", function() {
            // alert("hello");
            var myid = $(this).data('uid');
            $("#r_serno").val(myid);
            $('#rejectModal').modal('show');

        });
    });
</script>
<!-- reject modal -->
<!-- priority modal -->
<script type="text/javascript">
    $(document).ready(function() {
        $(".pri_modal").on("click", function() {
            // alert("hello");
            var myid = $(this).data('pid');
            $("#p_serno").val(myid);
            $('#priorityModal').modal('show');

        });
    });
</script>
<!-- priority modal -->
<!-- update Quantity History -->
<script type="text/javascript">
    $(document).ready(function() {

        $(".pri_modal1").on("click", function() {
            var myid1 = $(this).data('qty');
            
            $.ajax({
            url: 'update_history.php',
            type: 'POST',
            data: {value: myid1},
            success: function(data){

                $('.req').html(data);
              // 
                //alert(data[0].updated_by);
            }
            
          });
          $('#historyModal').modal('show');
          removeElement();
           
        });
    });
</script>
<!-- update Quantity History -->

<!-- tooltip -->
<script>
    $(function() {
        $('[data-toggle="tooltip"]').tooltip()
    });
</script>