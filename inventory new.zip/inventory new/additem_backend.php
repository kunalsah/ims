<?php
///// select category 
///display the data
if(isset($_REQUEST['display'])){
    $item = $_REQUEST["display"];
    
$query="SELECT * FROM category_master ORDER BY category_name";
$result=mysqli_query($conn,$query);
$result_array=array();

while($row=mysqli_fetch_array($result)){
    $result_array[] = $row;
}
echo json_encode($result_array);
}
?>