<?php
function cleartext($text){
    $text=trim($text);
    $text=addslashes($text);
    $text=htmlspecialchars($text);
    return($text);
}

//////

$sql="SELECT * FROM issue_table";
while($sql){
    $items=$sql[$column_name];
    foreach($itemss as $item){
       $sql2="query for select"; 
    }
}

?>