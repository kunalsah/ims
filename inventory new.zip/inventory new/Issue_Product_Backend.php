<?php
include 'connection.php';

/// show employee name

if (isset($_REQUEST['employee'])) {
  $item = $_REQUEST["employee"];
  $query = "SELECT * from member_list WHERE m_status='1'";
  $result = mysqli_query($conn, $query);
  $result_array = array();
  while ($row = mysqli_fetch_array($result)) {
    $result_array[] = $row;
  }
  echo json_encode($result_array);
}

/// show department name

if (isset($_REQUEST['department'])) {
  $item = $_REQUEST["department"];
  $query = "SELECT * from department_list WHERE status='1'";
  $result = mysqli_query($conn, $query);
  $result_array = array();
  while ($row = mysqli_fetch_array($result)) {
    $result_array[] = $row;
  }
  echo json_encode($result_array);
}

///show product name
if (isset($_REQUEST['name'])) {
  $item = $_REQUEST["name"];
  // $str = $_POST["str"];
  // echo $duplicate;
  $query = "SELECT product_master.product_id,item_master.item_name,stock_master.Stock_Product_Name FROM product_master INNER JOIN item_master ON product_master.product_name=item_master.item_id INNER JOIN stock_master ON product_master.product_id=stock_master.Stock_Product_Name";

 // if ($str != 0) {
  //  $query .= " AND product_master.product_id NOT IN(" . $str . ") ";
 // }

  $query .= " WHERE product_master.status=1;";

  $result = mysqli_query($conn, $query);
  //echo $query;
  $result_array = array();

  while ($row = mysqli_fetch_array($result)) {
    $result_array[] = $row;
  }
  echo json_encode($result_array);
}

//insert data into database

if (isset($_REQUEST['productName'])) {
  $p1=($_REQUEST['productName']);
  $productName =implode(",",$p1);
  $q1=($_REQUEST['Qty']);
  $Qty = implode(",",$q1);
  $mem_name = $_REQUEST['mem_name'];
  $issue_date = $_REQUEST['issue_date'];
  $issue_for_department = $_REQUEST['issue_for_department'];
  $item_received_by = $_REQUEST['item_received_by'];
  $order_approved_by = $_REQUEST['order_approved_by'];
  $type = "emergency";
  $email = 'mantasha@gmail.com';

  $q1 = "SELECT m_id FROM member_list WHERE m_email='$email'";
  $r1 = mysqli_query($conn, $q1);

  while ($rows = $r1->fetch_assoc()) {
    $m_id = $rows['m_id'];
  }

  $sql = "INSERT INTO `issue_table`(`issue_member_id`, `issued_by_id`, `order_taken_by`, `date`, `issued_product_id`, `issued_product_quantity`, `issue_for_department`,`issued_product_approved_by`, `type_of_order`) VALUES ('$mem_name','$m_id','$item_received_by','$issue_date','$productName','$Qty','$issue_for_department','$order_approved_by','$type')";

  $result = mysqli_query($conn, $sql);
  if ($result) {
    // echo $sql;
    echo 1;


    $stock_name = $_REQUEST['productName'];
    $stock_quantity = $_REQUEST['Qty'];
    // print_r($stock_name);
    // print_r($stock_quantity);
    $length = count($stock_name);
    if ($length > 0) {
      for ($a = 0; $a < $length; $a++) {
        $product_name_array = $stock_name[$a];
        $stock_quantity_array = $stock_quantity[$a];

        // print_r($product_name_array.'--');
        // print_r($stock_quantity_array);

        $sql = "select Issued_Product from stock_master where Stock_Product_Name='$product_name_array'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
          $result_array = array();
          while ($row = mysqli_fetch_array($result)) {
            $result_array[] = $row;
          }

          $new = intval($result_array[0][0]); //3
          // print_r($new);
          $new_issued_qty = $stock_quantity_array + $new;
          // print_r(gettype($new_issued_qty));
          $sql1 = "update stock_master set Issued_Product='$new_issued_qty' where Stock_Product_Name='$product_name_array'";
          $result = mysqli_query($conn, $sql1);
        }
      }
    }
  } else {
    echo 0;
  }
}

//show product quantity
if(isset($_REQUEST['prod_id'])){
  $prod_id=$_REQUEST['prod_id'];

  $sql="SELECT * FROM `stock_master` WHERE Stock_Product_Name='$prod_id'";
  $result=mysqli_query($conn,$sql);
  $result_array=array();

while($row=mysqli_fetch_array($result)){
    $result_array[] = $row;
}
echo json_encode($result_array);

}