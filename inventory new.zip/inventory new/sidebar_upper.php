<style>
    .dropdown-container {
        display: none;
        padding-left: 10%;
    }

    .activate {
        /* color: white; */
        background-color: #0056b3;
    }
</style>

<body bgcolor="#ECF2FF">
    <div class="sidebar">
        <div class="logo-content">
            <div class="logo">
                <div class="logo-name">Inventory</div>
            </div>
            <i class='bx bx-menu' id="btn"></i>
        </div>
        <div class="scrollbar">
            <ul class="nav-list">


                <li class="dropdown-btn" style="cursor: pointer;">
                    <a href="#">
                        <i class="bi bi-file-earmark-plus-fill" style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="Master Tables"></i>
                        <span class="links-name">Master Tables</span>
                        <i class="bi bi-caret-down-fill "></i>
                    </a>
                </li>
                <div class="dropdown-container">
                    <li>
                        <a href="Item_Master_Frontend.php">
                            <i class="bi bi-file-earmark-plus-fill" style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="M Add Product"></i>

                            <span class="links-name">M Add Product</span>
                        </a>
                        <!-- <span class="tooltip">M Add Product</span> -->
                    </li>
                    <li>
                        <a href="Variety_Master_Frontend.php">
                            <i class="bi bi-bookmarks-fill" style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="M Product Variety"></i>

                            <span class="links-name">M Product Variety</span>
                        </a>
                        <!-- <span class="tooltip">M Product Category</span> -->
                    </li>
                    <li>
                        <a href="Unit_Master_Frontend.php">
                            <i class="bi bi-speedometer2" style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="M Product Unit"></i>

                            <span class="links-name">M Product Unit</span>
                        </a>
                        <!-- <span class="tooltip">M Product Unit</span> -->
                    </li>
                    <li>
                        <a href="Category_Master_Frontend.php">
                            <i class="bi bi-collection" style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="M Product Category"></i>

                            <span class="links-name">M Product Category</span>
                        </a>
                        <!-- <span class="tooltip">M Product Category</span> -->
                    </li>
                </div>




                <li>
                    <a href="Product_Master_Frontend.php">
                        <i class="bi bi-bag-plus-fill sidehover5" style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="Add Items"></i>

                        <span class="links-name">Add Items</span>
                    </a>
                    <!-- <span class="tooltip">Add Items</span> -->
                </li>

                <li>
                    <a href="request1.php">
                        <i class="bi bi-person-circle sidehover6" style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="Request"></i>

                        <span class="links-name">Request</span>
                    </a>
                    <!-- <span class="tooltip">Request</span> -->
                </li>
                <li>
                    <a href="pending_request.php">
                        <i class="bi bi-calendar2-check-fill sidehover7" style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="Verify Requests"></i>
                        <span class="links-name">Verify Requests</span>
                    </a>
                    <!-- <span class="tooltip">Verify_Requests</span> -->
                </li>
                <li>
                    <a href="history.php">
                        <i class="bi bi-clock-history sidehover8" style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="History"></i>

                        <span class="links-name">History</span>
                    </a>
                    <!-- <span class="tooltip">History</span> -->
                </li>
                <li>
                    <a href="distribution.php">
                        <i class="bi bi-arrow-bar-right sidehover9" style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="Distribution"></i>

                        <span class="links-name">Distribution</span>
                    </a>
                    <!-- <span class="tooltip">Distribution</span> -->
                </li>
                <li>
                    <a href="additem_request.php">
                        <i class='bx bx-menu sidehover10' style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="Add Item Request"></i>
                        <span class="links-name">Add Items Requests</span>
                    </a>
                    <!-- <span class="tooltip">Add Items Requests</span> -->
                </li>
                <li>
                    <a href="stock_master_frontend.php">
                        <i class='bi bi-box sidehover11' style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="Stock Master"></i>
                        <span class="links-name">Add Stocks</span>
                    </a>
                    <!-- <span class="tooltip">Add Items Requests</span> -->
                </li>
                <li>
                    <a href="stock_entry_frontend.php">
                        <i class='bi bi-diagram-3 sidehover12' style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="Add Stocks Entry"></i>
                        <span class="links-name">Add Stocks Entry</span>
                    </a>
                    <!-- <span class="tooltip">Add Items Requests</span> -->
                </li>
                <li>
                    <a href="issue_product_frontend.php">
                        <i class='bi bi-diagram-3 sidehover13' style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="Issue Product"></i>
                        <span class="links-name">Issue Product</span>
                    </a>

                </li>

                <li class="dropdown-btn" style="cursor: pointer;">
                    <a href="#">
                        <i class="bi bi-file-earmark-plus-fill" style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="Master Tables"></i>
                        <span class="links-name">Reports </span>
                        <i class="bi bi-caret-down-fill "></i>
                    </a>
                </li>
                <div class="dropdown-container">
                <li>
                    <a href="issue_report_frontend.php">
                        <i class='bi bi-diagram-3 sidehover13' style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="Issue Product"></i>
                        <span class="links-name">Issue Report</span>
                    </a>

                </li>
                <li>
                    <a href="Stock_Report_Frontend.php">
                        <i class='bi bi-diagram-3 sidehover13' style="font-size:20px;" data-toggle="tooltip" data-placement="right" title="Issue Product"></i>
                        <span class="links-name">Stock Report</span>
                    </a>

                </li>
                </div>

            </ul>
        </div>
        <div class="profile-content">
            <div class="profile">
                <div class="profile-details">
                    <img src="img/default.png" alt="">
                    <div class="name-job">
                        <div class="name">Mantasha</div>
                        <div class="job">Designer</div>
                    </div>
                </div>
                <a href="logout.php"><i class='bx bx-log-out' id="log-out"></i></a>
            </div>
        </div>
    </div>
    <div class="home-content">
        <div class="text">