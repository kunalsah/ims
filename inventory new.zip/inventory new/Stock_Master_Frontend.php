<?php
include('top_header.php');
include('sidebar_upper.php');

require 'config.php';
?>

<div id="page-wrapper">
    <div class="main-page">

        <div class="card" style="box-shadow:0 0 5px #a8a8a8;">
            <div class="text" style="color:blue;font-size:18px">
                Add Stock From Here!!!
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary float-end " data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Add
                </button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel" style="color:red">Add Stock!</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <div class="col-md-12 my-1">
                                    <label for="inputEmail4" class="form-label"><b>ItemName :</b></label>
                                    <select name="p_name" class="form-select select2" id="p_name"></select>
                                </div>
                                <div class="col-md-12 my-1">
                                    <label for="inputEmail4" class="form-label"><b>Total Quantity:</b></label>
                                    <input type="number" name="n_item" class="form-control" id="p_total_quantity" placeholder="Enter Total Quantity" required>
                                </div>
                                <div class="col-md-12 my-1">
                                    <label for="inputEmail4" class="form-label"><b>Issued Quantity:</b></label>
                                    <input type="number" name="n_item" class="form-control" id="p_issued_quantity" placeholder="Enter Issued Quantity" required>
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" name="submit" class="btn btn-success" onclick="additem()">Add Category</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="tables">
            <h2 class="title1">Stock Master</h2>

            <div class="table-responsive">
                <table class="table" border=3>
                    <tr>
                        <td><b>S. No.</b></td>
                        <td><b>Stock Product Name<b></td>
                        <td><b>Total Stock<b></td>
                        <td><b>Issed Stock<b></td>
                        <td><b>Balance Stock<b></td>
                        <td><b>Created By<b></td>
                        <td><b>Created On<b></td>
                        <td><b>Updated By<b></td>
                        <td><b>Updated On<b></td>
                        <td><b>Operations</b></td>
                    </tr>
                    <tbody id="table_body" class="Data">

                    </tbody>



                </table>

                <!-- update Modal -->
                <div class="modal fade" id="update_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Update Category</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body text-center">

                            <label for="inputEmail4" class="form-label">Product Name :</label>
                                <input disabled type="text" id="value1" name="value1" required style="width: 50%;">
                                <label for="inputEmail4" class="form-label">Total Product  :</label>
                                <input type="text" id="value2" name="value2" required style="width: 50%;">
                                <label for="inputEmail4" class="form-label">Issued Product :</label>
                                <input type="text" id="value3" name="value3" required style="width: 50%;">
                                <input type="hidden" name="id" id="serno"></br></br>
                                <button type="submit" onclick="updateitem()" class="btn btn-primary">Update</button>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- update Modal -->

            </div>
        </div>
    </div>
    <div class="clearfix"> </div>
</div>



<?php
include("sidebar_lower.php");
?>
<!-- show Data -->
<script>
    $(document).ready(function() {
        displayData();
        loadData();
    });

    function displayData() {
        var display='display';
        $.ajax({
            url: 'Stock_Master_Backend.php',
            type: 'GET',
            data:{display:display},
            dataType: "json",
            success: function(response) {
                if (response.length > 0) {
                    var Q = 0;
                    var s_body = "";
                    for (var a = 0; a < response.length; a++) {
                        Q++;
                        var stock_id = response[a].Stock_id;
                        var item_name = response[a].item_name;
                        var total_product = response[a].Total_Product;
                        var issued_product = response[a].Issued_Product;
                        // var balance_product = response[a].Balance_Product;
                        var balance_product= total_product - issued_product;
                        var created_by = response[a].created_by;
                        var created_on = response[a].created_on;
                        var updated_by = response[a].updated_by;
                        var updated_on = response[a].updated_on;



                        s_body = s_body + '<tr>' +
                            '<td>' + Q + '</td>\
                    <td>' + item_name + '</td>\
                    <td>' + total_product + '</td>\
                    <td>' + issued_product + '</td>\
                    <td>' + balance_product + '</td>\
                    <td>' + created_by + '</td>\
                    <td>' + created_on + '</td>\
                    <td>' + updated_by + '</td>\
                    <td>' + updated_on + '</td>\
                    <td>\
                    <a class="btn btn-success"  onclick="showitem(' + stock_id + ')">Edit</a>\
                    <a href="" class="btn btn-danger" onclick="deleteitem(' + stock_id + ')">Delete</a>\
                    </td>\
                </tr>';
                    }
                    $('#table_body').html(s_body);
                }

            }


        });
    }


     ////show product item 

     function loadData(){
        var u_name="u_name";
        $.ajax({
            url:'Stock_Master_Backend.php',
            type:'post',
            data: {u_name: u_name},
            dataType: "json",
            success: function(response){
                if (response.length > 0) {
                    var s1_body = "<option selected>--select product name--</option>";
                    for (var a = 0; a < response.length; a++) {
                        var c=response[a].product_id;
                        var b=response[a].item_name;

                        s1_body += '<option value='+c+'>'+b+'</option>';
                    }      
                    $('#p_name').html(s1_body);
                    displayData();
                }
            } 
        });

    }

// add item through model
    function additem() {
        var name = $('#p_name').val();
        var total_quantity = $('#p_total_quantity').val();
        var issued_quantity =$('#p_issued_quantity').val();
        var balance_quantity = total_quantity-issued_quantity;

       if (($('#p_name').val() == '--select product name--') || ($('#p_total_quantity').val()==" ") || ($('#p_issued_quantity').val()==" ")){
            // alert('Enter your name!');
            swal.fire("No Empty Field!");

        }
        $.ajax({
            url: 'Stock_Master_Backend.php',
            type: 'POST',
            data: {
                name: name,
                total_quantity:total_quantity,
                issued_quantity:issued_quantity,
                balance_quantity:balance_quantity,

            },
            success: function(response) {
                displayData();
                loadData();
                $('input').each(function(){
                    $(this).val('');
                });
                $('#exampleModal').modal('hide');
                if(response=='already Found'){
                        swal.fire('Product Already Found');
                    }else{
                        swal.fire('Product added successfully!');
                    }
            }

        });
        
    }
// showing item into update input field
    function showitem(id){
        $('#serno').val(id);
        $.post("Stock_Master_Backend.php",{
            id:id
        },function(data){
            var user=JSON.parse(data);
            $('#value1').val(user.item_name);
            $('#value2').val(user.Total_Product);
            $('#value3').val(user.Issued_Product);
        });

        $('#update_modal').modal("show");

    }
// delete item
    function deleteitem(deletedid) {
        var conf = confirm("Are you sure");
        if (conf == true) {
            $.ajax({
                url: 'Stock_Master_Backend.php',
                type: 'POST',
                data: {
                    deletedid: deletedid
                },
                success: function(msg) {
                    alert(msg);
                    displayData();
                    
                }

            });
        }

    }
// update item
    function updateitem(){
        var id1=$('#serno').val();
        var name1=$('#value1').val();
        var Total_Product=$('#value2').val();
        var Issued_Product=$('#value3').val();
        var Balance_Product=Total_Product-Issued_Product;

        $.post("Stock_Master_Backend.php",{
            id1:id1,name1:name1,Total_Product:Total_Product,Issued_Product:Issued_Product,Balance_Product:Balance_Product
        },function(data){
            $('#update_modal').modal("hide");
            displayData();
            $('input').each(function(){
                    $(this).val('');
                });
        });       
    }

</script>

<!-- reject modal -->
<script type="text/javascript">
    $(document).ready(function() {
        $(".rejmodal").on("click", function() {
            // alert("hello");
            var myid = $(this).data('uid');
            // alert(myid);
            $("#r_serno").val(myid);
            $('#rejectModal').modal('show');

        });
    });
</script>
<!-- reject modal -->

<!-- tooltip -->
<script>
    $(function() {
        $('[data-toggle="tooltip"]').tooltip()
    });
</script>