<?php
$conn = mysqli_connect('localhost', 'root', '', 'inventory_db');
//$userData = array();
$output = '';  
//if (!empty($_POST["term"])) {
    $search = $_POST["value"];

   
   

    $sql = "SELECT product_master.product_id,item_master.item_name FROM product_master INNER JOIN item_master ON product_master.product_name=item_master.item_id WHERE product_master.status=1;";
   
    if(!empty($notin)){
        $sql .=" and item_id NOT IN(".$search.") ";
    }
    $result = mysqli_query($conn, $sql); 
    $result_array=array();
  
    while($row=mysqli_fetch_array($result)){
      $result_array[] = $row;
    }
    echo json_encode($result_array);
    

   
?>