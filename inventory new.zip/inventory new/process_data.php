<?php
$conn = mysqli_connect("localhost","root","", "inventory_db");
    //... mysql connection etc.
   // $response = Array();

   // $response['status'] = false;
    $output = '';  
    $query = mysqli_query($conn,"SELECT p_name FROM product_list WHERE p_name LIKE '%".$_POST['value']."%'"); //Or you can use = instead of LIKE if you need a more strickt search
    $output = '<ul class="list-unstyled" style="margin-left:5px">';

    if(mysqli_num_rows($query)>0) {
        //$userData = mysqli_fetch_assoc($query);
        while($row = mysqli_fetch_array($query))  
        {  
             $output .= '<li>'.$row["p_name"].'</li>';  
        }  
       // $response[] = $userData;
      //  $response['status'] = true;            
    }
    else  
    {  
         $output .= '<li>Product Not Found</li>';  
    }  
    $output .= '</ul>';  
    echo $output;  

    //echo json_encode($response);
    ?>