<?php
include('top_header.php');
include('sidebar_upper.php');
include("department_fetch.php");
require('connection.php');
?>
<style>
  .card-registration .select-input.form-control[readonly]:not([disabled]) {
    font-size: 1rem;
    line-height: 2.15;
    padding-left: .75em;
    padding-right: .75em;
  }

  .card-registration .select-arrow {
    top: 13px;
  }
</style>


<head>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>

  <script type="text/javascript">
    $(document).ready(function() {
      var x = 1;
      var n = 1;
      var m = 0;
      var prevalue = [];
    //  var str = "";
      var did1 = "";
      var max = 4;
      var Total=0;
        var Issue=0;
        var Available=0;
        var number=[];
      //getSelectValue(x);



      ////duplicate data in dropdown
      $(document).on('change', '.namee', function() {

        var did = $(this).data('name');
        // alert(did);
        did1 = did + 1;
        var ProdName = $(this).val();
        prevalue.push(parseInt(ProdName));
        //str = prevalue.substring(0, prevalue.length - 1);
      // alert(prevalue);

      });

      ///validation in qty
      $(document).on('keyup', '.qtyy', function() {
        var name = x-1;
        var prod_id=$('#result-box'+name).val();
        var Quantity=$('#qty'+name).val();
        //alert(n);
        $.ajax({
          url: 'Issue_Product_Backend.php',
            type: 'post',
            data: {
              prod_id: prod_id,
            },
             dataType: "json",
            success: function(response) {
               Total=response[0].Total_Product;
               Issue=response[0].Issued_Product;
               Available=Total-Issue;
              //alert(Available);
              if(Available <= 0){
                swal.fire("No Quantity is left Select Another item");
                document.getElementById("add").disabled = true;
                var button=document.getElementById('submit');
                button.disabled=true;
              }else
              if(Available < Quantity){
                swal.fire("Only " +Available+ " item is left");
                document.getElementById("add").disabled = true;
                var button=document.getElementById('submit');
                button.disabled=true;
              }else{
                document.getElementById("add").disabled = false;
              var button=document.getElementById('submit');
                button.disabled=false;
              }
            }
        });    
      });


      ////submit the data into database

      $(document).on('click', '#submit', function() {
        var productName = [];
        var Qty = [];
        var length = m;
        if (($('#employee_name').val() == '--select employee name--') || ($('#department_name').val() == "--select department name--") || ($('#received_by').val() == '') || ($('#approved_by').val() == '--select Approved By--')) {
          swal.fire("No Empty Field!!");
          return false;
        } else {
          var mem_name = $('#employee_name').val();
          var issue_date = $('#todays-date').val();
          var issue_for_department = $('#department_name').val();
          var item_received_by = $('#received_by').val();
          var order_approved_by = $('#approved_by').val();

          //////multiple data in array for product name and product quantity

          for (var i = 0; i <= length; i++) {
            if ($("#result-box" + i).val() != null && $("#result-box" + i).val() != "undefined" && $("#qty" + i).val() != "" && $("#qty" + i).val() != "undefined") {
              productName.push($("#result-box" + i).val());
              Qty.push($("#qty" + i).val());
            }
          }
          // alert(productName);
          // console.log(Qty);
          $.ajax({
            url: 'Issue_Product_Backend.php',
            type: 'post',
            data: {
              productName: productName,
              Qty: Qty,
              mem_name: mem_name,
              issue_date: issue_date,
              issue_for_department: issue_for_department,
              item_received_by: item_received_by,
              order_approved_by: order_approved_by
            },
            // dataType: "json",
            success: function(response) {
              if (response == 1) {
                // swal('Issued Product Successfully');
                Swal.fire({

                  text: "Issued Product Successfully",

                  // showCancelButton: true,
                  confirmButtonColor: '#3085d6',

                  // confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                  if (result.isConfirmed) {

                    location.reload();
                  }
                })
              } else {
                swal.fire('Error Occured!');
              }
            }
          });
        }

      });

      //////////////////////////////////////////////



      //////////////////////////////////////
      $('#add').click(function() {
        // alert(prevalue);
        // alert(m);
        

        if (($("#result-box" + m).val() == null) || ($("#qty" + m).val() == '')) {
          if (number.includes(m)) {
           // m++;
            //exit();
          } else {
            // alert(number);
            // alert(m);
              swal.fire("Empty field");
              return false;
          }
        } else
        if (n <= max) {
          var html = '<tr><td><select name="product_name" class="form-select namee" data-name="' + x + '" id="result-box' + x + '" type="text" name="txtName[]" data-tt="0"><option value="0" disabled selected>--select product name--</option></select></td><td><input class="form-control qtyy" id="qty' + x + '" type="number" name="txtQty[]" required=""></td><td><input class="btn btn-danger" type="button" name="remove" id="remove" value="remove'+x+'"><input type="hidden" id="fetch_data' + x + '" value="' + x + '"></td></tr>';
          $('#table_field').append(html);
          name(x);
          //  fetch_value(x);

          x++;
          n++;
          m++;


        }

      });
      $('#table_field').on('click', '#remove', function() {
        var product_id = $(this).val();
        var did = product_id[6];
        $(this).closest('tr').remove();
        var did2=parseInt(did);
         number.push(parseInt(did));
          
        //  $("#qty" + parseInt(did)).val() != "";
        // prevalue.splice(indexToRemove, did2);
        
       // alert ($("#result-box" + did2).val());
       
        n--;
       // m--;

      });
    });
    

    /////product name
    function name(x, str) {
      var id = x;
      var str = str;
      var name = 'name';
      // alert(str);
      $.ajax({
        url: 'Issue_Product_Backend.php',
        type: 'post',
        data: {
          name: name,
          // str: str
        },
        dataType: "json",
        success: function(response) {
          if (response.length > 0) {
            var s1_body = '<option value="0" disabled selected>--select product name--</option>';
            var prevalue = "";
            for (var a = 0; a < response.length; a++) {
              var c = response[a].product_id;
              var b = response[a].item_name;
              s1_body += '<option value=' + c + '>' + b + '</option>';
            }
            $("#result-box" + id).html(s1_body);
          }
        }
      });

    }
    ///////////////////
  </script>
</head>
<div id="page-wrapper">
  <div class="main-page">

    <div class="insert-form" id="insert_form" method="post" action="">

      <section style="background-color: #eee;">
        <div class="container h-100">
          <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-lg-12 col-xl-11">
              <div class="card text-black" style="border-radius: 25px;">
                <div class="card-body p-md-7">
                  <div class="row justify-content-center">
                    <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Issue Product</p>
                    <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">

                      <div class="mx-1 mx-md-4">

                        <div class="d-flex flex-row align-items-center mb-4">
                          <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                          <div class="form-outline flex-fill mb-0">
                            <label class="form-label" for="form3Example1c">Item Requested By</label>
                            <select name="employee_name" class="form-select" id="employee_name">
                              <option value="0" disabled selected>--select employee name--</option>
                            </select>
                          </div>
                        </div>

                        <div class="d-flex flex-row align-items-center mb-4">
                          <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                          <div class="form-outline flex-fill mb-0">
                            <label class="form-label" for="form3Example3c">Issue Date</label>
                            <input type="date" id="todays-date" value="" disabled class="form-control" />
                          </div>
                        </div> 

                        <div class="d-flex flex-row align-items-center mb-4">
                          <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                          <div class="form-outline flex-fill mb-0">
                            <label class="form-label" for="form3Example3c">Issue to Department</label>
                            <select name="department_name" class="form-select" id="department_name">
                              <option value="0" disabled selected>--select department name--</option>
                            </select>
                          </div>
                        </div>

                        <div class="d-flex flex-row align-items-center mb-4">
                          <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                          <div class="form-outline flex-fill mb-0">
                            <label class="form-label" for="form3Example4c">Item Recived By</label>
                            <input type="text" id="received_by" class="form-control" />
                          </div>
                        </div>

                        <div class="d-flex flex-row align-items-center mb-4">
                          <i class="fas fa-key fa-lg me-3 fa-fw"></i>
                          <div class="form-outline flex-fill mb-0">
                            <label class="form-label" for="form3Example4cd">Order Approved By</label>
                            <select name="approved_by" class="form-select" id="approved_by">
                              <option value="0" disabled selected>--select Approved By--</option>
                              <option value="Principal">Principal</option>
                              <option value="Director">Director</option>
                              <option value="Assistant Director">Assistant Director</option>
                              <option value="Chairman">Chairman</option>
                            </select>
                          </div>
                        </div>
                      </div>

                    </div>
                    <div class="col-md-10 col-lg-6 col-xl-5 d-flex align-items-center order-1 order-lg-2">

                      <img src="https://www.freeiconspng.com/uploads/warehouse-inventory-icon-6.png" class="img-fluid" alt="Sample image">

                    </div>
                  </div>
                  <br>


                  <div style="margin-left:120px;margin-right:100px;" class="insert-form" id="insert_form" method="post" action="">
                    <div class="input-field">
                      <table class="table table-bordered" id="table_field">
                        <tr>
                          <th>Product Name</th>
                          <th>Product Qty</th>
                          <th>Add Or Remove</th>
                        <tr>

                          <td>
                            <select name="product_name" class="form-select namee" data-name="0" id="result-box0" type="text" name="txtName[]" data-tt="0">
                              <option value="0" disabled selected>--select product name--</option>
                            </select>
                          </td>
                          <td><input class="form-control qtyy"  id="qty0" type="number" name="txtQty[]" required=""></td>
                          <td><input class="btn btn-warning" type="button" name="adda" id="add" value="Add"></td>

                        </tr>
                      </table>

                      <center>


                    </div>
                    </br>

                    </center>
                  </div>

                </div>
                <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                  <button type="button" id="submit" class="btn btn-primary btn-lg">Issue</button>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
    </section>


  </div>



</div>
</div>


<script>
  $(document).ready(function() {
    employee();
    department();
    name(0);

  });
  ////show employee name
  function employee() {
    var employee = 'employee';
    $.ajax({
      url: 'Issue_Product_Backend.php',
      type: 'post',
      data: {
        employee: employee
      },
      dataType: "json",
      success: function(response) {
        if (response.length > 0) {
          var s1_body = '<option value="0" disabled selected>--select employee name--</option>';
          for (var a = 0; a < response.length; a++) {
            var c = response[a].m_id;
            var b = response[a].m_name;

            s1_body += '<option value=' + c + '>' + b + '</option>';
          }
          $('#employee_name').html(s1_body);
        }
      }
    });
  }

  ///show department name

  function department() {
    var department = 'department';
    $.ajax({
      url: 'Issue_Product_Backend.php',
      type: 'post',
      data: {
        department: department
      },
      dataType: "json",
      success: function(response) {
        if (response.length > 0) {
          var s1_body = '<option value="0" disabled selected>--select department name--</option>';
          for (var a = 0; a < response.length; a++) {
            var c = response[a].department_id;
            var b = response[a].department_name;

            s1_body += '<option value=' + c + '>' + b + '</option>';
          }
          $('#department_name').html(s1_body);
        }
      }
    });

  }
</script>



<script>
  var today = new Date();
  var dd = ("0" + (today.getDate())).slice(-2);
  var mm = ("0" + (today.getMonth() + 1)).slice(-2);
  var yyyy = today.getFullYear();
  today = yyyy + '-' + mm + '-' + dd;
  $("#todays-date").attr("value", today);
</script>




<?php
include("sidebar_lower.php");
?>