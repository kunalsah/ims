<?php
include 'connection.php';

///display the data
if(isset($_REQUEST['display'])){
    $item = $_REQUEST["display"];
$query="SELECT product_master.product_id,item_master.item_name,variety_master.var_name,category_master.category_name, unit_master.unit_type, product_master.product_qty, type_tbl.product_type_name,type_tbl.t_id as type_ids,item_master.item_id as products_ids,category_master.ca_id as categories_ids,variety_master.var_id as varietys_ids,unit_master.unit_id as units_ids,product_master.added_by,product_master.added_on,product_master.updated_by,product_master.updated_on
FROM item_master
INNER JOIN product_master ON item_master.item_id=product_master.product_name
INNER JOIN category_master ON category_master.ca_id=product_master.product_category
INNER JOIN variety_master ON variety_master.var_id=product_master.product_variety
INNER JOIN unit_master ON unit_master.unit_id = product_master.product_unit
INNER JOIN type_tbl ON type_tbl.t_id = product_master.product_type WHERE product_master.status='1'";
$result=mysqli_query($conn,$query);
$result_array=array();

while($row=mysqli_fetch_array($result)){
    $result_array[] = $row;
}
echo json_encode($result_array);
}

/// insert the data
if (isset($_POST['name'])) {
  $name = $_POST["name"];
  $name_text = $_POST["name_text"];
  // echo ($name_text);
  $qtytotal = $_POST["qtytotal"];

  $category = $_POST["category"];
  $category_text = $_POST["category_text"];

  $variety = $_POST["variety"];
  $variety_text = $_POST["variety_text"];

  $type = $_POST["type"];
  $type_text = $_POST["type_text"];

  $unit = $_POST["unit"];
  $unit_text = $_POST["unit_text"];

  $image = $_POST["image"];
  $status = '1';
  date_default_timezone_set("Asia/Kolkata");
  $creatername = "Admin";
  $current_date = date("Y-m-d H:i:s");


  // item master
  $check_item_master = "select item_name from item_master where item_name='$name_text'";
  $check_item_master_result = mysqli_query($conn, $check_item_master);
  if (mysqli_num_rows($check_item_master_result) == 1) {
    $check_status = "select item_name from item_master where item_name='$name_text' and status='1'";
    $check_status_result = mysqli_query($conn, $check_status);
    if (mysqli_num_rows($check_status_result) == 0) {
      $change_status = "update item_master set status='1' where item_name='$name_text'";
    }
  } else {
    $sql1 = "INSERT INTO item_master (item_name,created_by,created_date,status) values ( '$name_text', '$creatername', '$current_date','$status')";
    $result = mysqli_query($conn, $sql1);
    if ($result) {
      // $sql="select item_id from item_master where item_name='$name_text'";
      // $name=mysqli_query($conn,$sql);
      $name = mysqli_insert_id($conn);
    }
  }
  // category master
  $check_item_master = "select category_name from category_master where category_name='$category_text'";
  $check_item_master_result = mysqli_query($conn, $check_item_master);
  if (mysqli_num_rows($check_item_master_result) == 1) {
    $check_status = "select category_name from category_master where category_name='$category_text' and status='1'";
    $check_status_result = mysqli_query($conn, $check_status);
    if (mysqli_num_rows($check_status_result) == 0) {
      $change_status = "update category_master set status='1' where category_name='$category_text'";
    }
  } else {
    $sql1 = "INSERT INTO category_master (category_name,created_by,created_date,status) values ( '$category_text', '$creatername', '$current_date','$status')";
    $result = mysqli_query($conn, $sql1);
    if ($result) {
      $category = mysqli_insert_id($conn);
    }
  }

  // variety master
  $check_item_master = "select var_name from variety_master where var_name='$variety_text'";
  $check_item_master_result = mysqli_query($conn, $check_item_master);
  if (mysqli_num_rows($check_item_master_result) == 1) {
    $check_status = "select var_name from variety_master where var_name='$variety_text' and status='1'";
    $check_status_result = mysqli_query($conn, $check_status);
    if (mysqli_num_rows($check_status_result) == 0) {
      $change_status = "update variety_master set status='1' where var_name='$variety_text'";
    }
  } else {
    $sql1 = "INSERT INTO variety_master (var_name,created_by,created_on,status) values ( '$variety_text', '$creatername', '$current_date','$status')";
    $result = mysqli_query($conn, $sql1);
    if ($result) {
      $variety = mysqli_insert_id($conn);
    }
  }

  // type master
  $check_item_master = "select product_type_name from type_tbl where product_type_name='$type_text'";
  $check_item_master_result = mysqli_query($conn, $check_item_master);
  if (mysqli_num_rows($check_item_master_result) == 1) {
    $check_status = "select product_type_name from type_tbl where product_type_name='$type_text' and status='1'";
    $check_status_result = mysqli_query($conn, $check_status);
    if (mysqli_num_rows($check_status_result) == 0) {
      $change_status = "update type_tbl set status='1' where product_type_name='$type_text'";
    }
  } else {
    $sql1 = "INSERT INTO type_tbl (product_type_name,created_by,created_date,status) values ( '$type_text', '$creatername', '$current_date','$status')";
    $result = mysqli_query($conn, $sql1);
    if ($result) {
      $type = mysqli_insert_id($conn);
    }
  }

  // unit master
  $check_item_master = "select unit_type from unit_master where unit_type='$unit_text'";
  $check_item_master_result = mysqli_query($conn, $check_item_master);
  if (mysqli_num_rows($check_item_master_result) == 1) {
    $check_status = "select unit_type from unit_master where unit_type='$unit_text' and status='1'";
    $check_status_result = mysqli_query($conn, $check_status);
    if (mysqli_num_rows($check_status_result) == 0) {
      $change_status = "update unit_master set status='1' where unit_type='$unit_text'";
    }
  } else {
    $sql1 = "INSERT INTO unit_master (unit_type,created_by,created_date,status) values ( '$unit_text', '$creatername', '$current_date','$status')";
    $result = mysqli_query($conn, $sql1);
    if ($result) {
      $unit = mysqli_insert_id($conn);
    }
  }


  $query_text="SELECT product_master.product_id,item_master.item_name,variety_master.var_name,category_master.category_name, unit_master.unit_type, product_master.product_qty, type_tbl.product_type_name,type_tbl.t_id as type_ids,product_master.added_by,product_master.added_on,product_master.updated_by,product_master.updated_on
  FROM item_master
  INNER JOIN product_master ON item_master.item_id=product_master.product_name
  INNER JOIN category_master ON category_master.ca_id=product_master.product_category
  INNER JOIN variety_master ON variety_master.var_id=product_master.product_variety
  INNER JOIN unit_master ON unit_master.unit_id = product_master.product_unit
  INNER JOIN type_tbl ON type_tbl.t_id = product_master.product_type WHERE product_master.status='1' and product_name='$name' and product_category='$category' and product_variety='$variety' and product_unit='$unit' and product_type='$type'";
  $checking_result=mysqli_query($conn,$query_text);
  if(mysqli_num_rows($checking_result)==0){

    $sql1 = "INSERT INTO `product_master`(`product_name`, `product_category`, `product_variety`, `product_unit`, `product_type`, `product_qty`, `product_img`, `status`, `added_by`, `added_on`) VALUES ('$name','$category','$variety','$unit','$type','$qtytotal','$image','$status','$creatername','$current_date')";
  
          $result = mysqli_query($conn, $sql1);
          if ($result) {
            echo 1;
          } else {
            echo 0;
      }
  }else{
    echo 0;
  }
}

///delete the data
if(isset($_POST["deletedid"])){
    $id=$_POST["deletedid"];
    $sql= $sql1 = "UPDATE product_master SET `status`='0' WHERE product_id = '$id'";

    $result = mysqli_query($conn, $sql);
    if ($result) {
      // echo $sql;
      echo $msg="Deleted Successfully!!";
    } else {
      echo $msg="Deleted Unsuccessful!!";
    }

    echo json_encode($msg);

}

///update data
if(isset($_POST["id1"])){
  date_default_timezone_set("Asia/Kolkata");
  $current_date=date("Y-m-d H:i:s");
  $creatername = "Admin";
    $id=$_POST["id1"];
    $name=$_POST["name1"];
    $category=$_POST["category"];
    $variety=$_POST["variety"];
    $unit=$_POST["unit"];
    $type=$_POST["type"];
    $qty=$_POST["qty"];
    $image=$_POST["image"];
    $sql= $sql1 = "UPDATE `product_master` SET `product_name`='$name',`product_category`='$category',`product_variety`='$variety',`product_unit`='$unit',`product_type`='$type',`product_qty`='$qty',`product_img`='$_image',`updated_by`='$creatername',`updated_on`='$current_date' WHERE `product_id`='$id'";

    $result = mysqli_query($conn, $sql);
    if ($result) {
      // echo $sql;
      echo $msg="Updated Successfully!!";
    } else {
      echo $msg="Updated Unsuccessful!!";
    }

    echo json_encode($msg);

}

///show product name
if(isset($_REQUEST['u_name'])){
  $item = $_REQUEST["u_name"];
$query="SELECT * from item_master WHERE status='1'";
$result=mysqli_query($conn,$query);
$result_array=array();

while($row=mysqli_fetch_array($result)){
  $result_array[] = $row;
}
echo json_encode($result_array);
}

/// show category name

if(isset($_REQUEST['u_category'])){
  $item = $_REQUEST["u_category"];
$query="SELECT * from category_master WHERE status='1'";
$result=mysqli_query($conn,$query);
$result_array=array();

while($row=mysqli_fetch_array($result)){
  $result_array[] = $row;
}
echo json_encode($result_array);
}

///show variety name

if(isset($_REQUEST['u_variety'])){
  $item = $_REQUEST["u_variety"];
$query="SELECT * from variety_master WHERE status='1'";
$result=mysqli_query($conn,$query);
$result_array=array();

while($row=mysqli_fetch_array($result)){
  $result_array[] = $row;
}
echo json_encode($result_array);
}

///show product type

if(isset($_REQUEST['u_type'])){
  $item = $_REQUEST["u_type"];
$query="SELECT * from type_tbl WHERE status='1'";
$result=mysqli_query($conn,$query);
$result_array=array();

while($row=mysqli_fetch_array($result)){
  $result_array[] = $row;
}
echo json_encode($result_array);
}

///show product unit

if(isset($_REQUEST['u_unit'])){
  $item = $_REQUEST["u_unit"];
$query="SELECT * from unit_master WHERE status='1'";
$result=mysqli_query($conn,$query);
$result_array=array();

while($row=mysqli_fetch_array($result)){
  $result_array[] = $row;
}
echo json_encode($result_array);
}

// getting name for editing 
if(isset($_POST['edit_id'])){
  $id=$_POST['edit_id'];
  $table=$_POST['table'];
  $column1=$_POST['column1'];
  $column2=$_POST['column2'];
  $sql="select $column2 from $table where $column1='$id'";
  // print_r($sql);
  $result=mysqli_query($conn,$sql);

  $result_arr=array();
  while($row=mysqli_fetch_array($result)){
      $result_arr[]=$row;
  }
  echo json_encode($result_arr);
  // print_r($result_arr);
}


// updating the value
if(isset($_POST['update_edited_id'])){
  $id = $_POST['update_edited_id'];
  $name = $_POST['name1'];
  $table=$_POST['update_table'];
$column1=$_POST['update_column1'];
$column2=$_POST['update_column2'];
  // echo $name;
  // echo $id;
  $sql= "UPDATE $table set $column2='$name' where $column1 = '$id'";
  $result = mysqli_query($conn,$sql);
  print_r($result);
  if(mysqli_affected_rows($conn)){
      // echo 1;
  }else{
      // echo 0;
  }
}

// add product form ....................................................................................................




if (isset($_POST['display1'])) {


  $sql = "SELECT * FROM category_master WHERE status='1' ORDER BY category_name";
  $result = mysqli_query($conn, $sql);
  $result_arr = array();
  while ($row = mysqli_fetch_array($result)) {
    $result_arr[] = $row;
  }
  echo json_encode($result_arr);
}



if (isset($_POST['display2'])) {
  $sql = "SELECT * FROM item_master WHERE status='1' ORDER BY item_name ";
  $result = mysqli_query($conn, $sql);
  $result_arr = array();
  while ($row = mysqli_fetch_array($result)) {
    $result_arr[] = $row;
  }
  echo json_encode($result_arr);
}

if (isset($_POST['display3'])) {
  $sql = "SELECT * FROM variety_master WHERE status='1' ORDER BY var_name";
  $result = mysqli_query($conn, $sql);
  $result_arr = array();
  while ($row = mysqli_fetch_array($result)) {
    $result_arr[] = $row;
  }
  echo json_encode($result_arr);
}

if (isset($_POST['display4'])) {
  $sql = "SELECT * FROM type_tbl WHERE status='1' ORDER BY product_type_name";
  $result = mysqli_query($conn, $sql);
  $result_arr = array();
  while ($row = mysqli_fetch_array($result)) {
    $result_arr[] = $row;
  }
  echo json_encode($result_arr);
}

if (isset($_POST['display5'])) {
  $sql = "SELECT * FROM unit_master WHERE status='1' ORDER BY unit_type";
  $result = mysqli_query($conn, $sql);
  $result_arr = array();
  while ($row = mysqli_fetch_array($result)) {
    $result_arr[] = $row;
  }
  echo json_encode($result_arr);
}

?>