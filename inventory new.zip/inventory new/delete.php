<?php include("top_header.php"); ?>
<?php require("connection.php"); ?>
<?php


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;



require 'vendor/autoload.php';

require("connection.php");
$currentDate = date('Y-m-d');
$email='kunalsahwork@gmail.com';
$id = $_POST['id'];
$value = $_POST['value'];
// echo $id;
$sql="UPDATE request_item SET r_accept_status='Rejected', reason_a_r='$value' where `request_serial`=$id";

$sql3="SELECT * FROM request_item where `request_serial`='$id'";
    
$result3=mysqli_query($conn,$sql3);
while ($row3 = mysqli_fetch_assoc($result3)) {
    $mem_id = $row3['req_mem_id'];
    $product_id = $row3['rp_id'];
    $quantity = $row3['r_qty'];
    // $reason1 = $row3['reason_a_r'];
}

$sql1="SELECT * FROM product_list where `p_id`='$product_id'";
$result1=mysqli_query($conn,$sql1);
    while ($row1 = mysqli_fetch_assoc($result1)) {
        $product = $row1['p_name'];     
    }

$sql2="SELECT * FROM member_list where `m_id`='$mem_id'";
$result2=mysqli_query($conn,$sql2);
    while ($row2 = mysqli_fetch_assoc($result2)) {
        $member = $row2['m_name'];     
    }


    sendEmail($email,$member,$product,$quantity,$value);

$result=mysqli_query($conn,$sql);
if($result){
    // header('location:view_requests.php');
    header("Location: ".$_SERVER['HTTP_REFERER']);
    // echo $sql;
}else{
    die(mysqli_error($conn));
}

///////////////////////////////////

// function sendEmail logic
function sendEmail($email,$member,$product,$quantity,$value){
   
    $mail = new PHPMailer(true);
    
    try{
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->Username ='amantasha7@gmail.com';
    $mail->Password = 'nkcdxefahnjzwwbc';
    $mail->SMTPAuth=true;
    $mail->Port = 587;
    $mail->SMTPSecure = 'tls';
    $mail->setFrom('amantasha7@gmail.com', 'Mantasha');
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject="Request Named : '.$member.'";
    $mail->Body = "Your Request Is declined for product : '.$product.' , Quantity : '.$quantity.' , Reason : '.$value.' ";
    $mail->send();
    }catch(Exception $e)
        {echo $e;}
    }



?>