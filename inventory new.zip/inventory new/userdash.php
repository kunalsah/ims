<?php include("top_header.php");
require("connection.php");
include("sidebar_upper.php");
?>
<div class="container card mt-2" style="box-shadow:0 0 5px #a8a8a8;">

</div>
<?php
include("sidebar_lower.php");
?>