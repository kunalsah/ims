<?php include("top_header.php");
include("sidebar_upper.php");
require("connection.php"); ?>

<div class="container card mt-2 search_result" style="box-shadow:0 0 5px #a8a8a8;">
    <h3 class="text-center">Pending Requests</h3>
    <input type="search" class="m-1" placeholder="Search" id="live_search">
    <div id="search_result">
        <table class="table table-bordered table-hover">

            <tr>
                <th class="text-center">S.NO.</th>
                <th class="text-center">Name</th>
                <th class="text-center">Product Name</th>
                <th class="text-center">Request Date</th>
                <th class="text-center">Priority</th>
                <th class="text-center">Operations</th>
            </tr>
            <!-- fetching data of user -->
            <?php
            $i=0;
            $sql = "SELECT * FROM `request_tbl` INNER JOIN member_list on request_tbl.request_user=member_list.m_id INNER JOIN request_item on request_tbl.request_id=request_item.r_id INNER  JOIN product_list on request_item.rp_id=product_list.p_id where  r_accept_status='NO' order by request_date ";
            $result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_array($result)) {
                $i++;
                // Access the data using the column names or indexes
                $request_id = $row['m_name'];
                $request_date = $row['request_date'];
                $request_product_name = $row['p_name'];
                $id = $row['m_id'];
                $priority = $row['priority'];

                if ($priority == 'Normal') {
                    $style = 'style="color:green"';
                } else {
                    $style = 'style="color:red"';

                }

                echo ' 
                    <tr>
                    <td class="text-center">' . $i . '</td>
                    <td class="text-center">' . $request_id . '</td>
                    <td class="text-center">' . $request_product_name . '</td>
                    <td class="text-center">' . $request_date . '</td>
                    <td class="text-center" ' . $style . '>' . $priority . '</td>
                    <td class="text-center"><button type="View" class="btn btn-primary"><a href="view_request.php?m_id=' . $id . '" style="text-decoration: none;color:white;">View</a></button></td>
                    </tr>
                ';
            }
            ?>
        </table>
    </div>
</div>
<?php include("sidebar_lower.php"); ?>

<!-- search box -->
<script type="text/javascript">
    $(document).ready(function () {

        $('#live_search').keyup(function () {
            var input = $(this).val();
            // alert(input); 

            $.ajax({
                url: "livesearch.php",
                method: "POST",
                data: { input: input },

                success: function (data) {
                    $('#search_result').html(data);
                    $('#search_result').css("display", "block");
                }
            });

        });
    });        
</script>