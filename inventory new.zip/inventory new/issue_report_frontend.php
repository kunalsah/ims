<?php
include('top_header.php');
include('sidebar_upper.php');
?>


<div class="tables">
    <div>
        <h2 class="title1 text-center">Issue Report Table</h2>
    </div>
    <div class="row" style="margin-bottom: 2%;">
        <input type="search" id="live_search_bar" placeholder="Type To Search" class="form-control border-end-4 border rounded-pill m-4 col-3">
        
        <label style="margin-top: 2%; padding:0%;" class="col-1">Total Stock:</label><input disabled id="total_product" placeholder="" class="form-control border-end-4 border rounded-pill m-4 col-1">

        <label style="margin-top: 2%; padding:0%;" class="col-1">Issued Stock:</label><input disabled id="issued_product" placeholder="" class="form-control border-end-4 border rounded-pill m-4 col-1">

        <label style="margin-top: 2%; padding:0%;" class="col-1">Balance Stock:</label><input disabled id="balance_product" placeholder="" class="form-control border-end-4 border rounded-pill m-4 col-1">
    </div>

    <div class="table-responsive">
        <table class="table table-hover" border="3" id="myTable">
            <thead id="table_head">

            </thead>
            <tbody id="table_body" class="Data">

            </tbody>

        </table>

    </div>
</div>

<script>
    $(document).ready(function() {
        displaydata();
    });

    ////stock details
    function stock_details(search_item_id,Issued_Product_Id){
        var item_id=search_item_id;
        var item_name=Issued_Product_Id;
        var Total_Product=0;
        var Issued_Product=0;
        var Balance_Product=0;
        $.ajax({
            url: "issue_report_backend.php",
            method: "POST",
            dataType: 'JSON',
            data: {
                item_id: item_id,
            },

            success: function(response) {
                if($('#live_search_bar').val()!=''){

                    if (response.length > 0) {
                        
                        Total_Product = response[0].Total_Product;
                        Issued_Product = response[0].Issued_Product;
                        Balance_Product= Total_Product - Issued_Product;
                        
                        
                        $('#total_product').val(Total_Product);
                        $('#issued_product').val(Issued_Product);
                        $('#balance_product').val(Balance_Product);
                    }
                }else{
                    $('#total_product').val('');
                        $('#issued_product').val('');
                        $('#balance_product').val('');
                }


                
            }
        });
        
    }


    function displaydata() {
        var display_issue_report = 'display_issue_report';
        $.ajax({
            url: 'issue_report_backend.php',
            type: 'post',
            dataType: 'json',
            data: {
                display_issue_report: display_issue_report
            },
            success: function(response) {
                //  console.log(JSON.parse(response[0][4]));
                if (response.length > 0) {
                    var S_No = 0;
                    var t_body = "";
                    var t_head = "";
                    var t_data = "";
                    for (var a = 0; a < response.length; a++) {
                        S_No++;
                        var Issued_to = response[a].m_name;
                        var Issued_by = response[a].issued_by_id;
                        var Date = response[a].date;
                        var Order_received = response[a].order_taken_by;
                        var Department = response[a].department_name;
                        var Order_Type = response[a].type_of_order;
                        var Approved_By = response[a].issued_product_approved_by;






                        // splitting the item names string into array and storing it
                        var Issued_Product_Id = response[a].concatenated_item_names;
                        var Item_arr = Issued_Product_Id.split(",");
                        var Item_arr_length = Item_arr.length;

                        // splitting the item quantity string into array and storing it
                        var Issued_Product_Qty = response[a].issued_product_quantity;
                        var Item_qty_arr = Issued_Product_Qty.split(",");






                        var item_no = 0;

                        // head for each response to display
                        t_head = '<tr style="background-color: rgb(184,218,255);"><th>S.No.</th><th>Date</th><th>Issued To</th><th>Issued By</th><th>Approved By</th><th>Department</th></tr><tr><td>' + S_No + '</td><td>' + Date + '</td><td>' + Issued_to + '</td><td>' + Issued_by + '</td><td>' + Approved_By + '</td><td>' + Department + '</td></tr><tr style="background-color: rgb(184,218,255);"><th colspan="2">Item No.</th><th colspan="2">Item Name</th><th colspan="2">Item Quantity</th></tr>';

                        // creating list of items and quantity to display according to the response string which was later converted into arrya
                        for (var i = 0; i < Item_arr_length; i++) {
                            item_no++;
                            var Issued_product_name = Item_arr[i];
                            Issued_product_qty = Item_qty_arr[i];

                            t_body += '<tr><td colspan="2">' + item_no + '</td><td colspan="2">' + Issued_product_name + '</td><td colspan="2">' + Issued_product_qty + '</td></tr>';
                        }

                        // t_foot for adding space after every single persons data
                        t_foot = '<tr style="height:55px;"></tr>';

                        t_data += t_head + t_body + t_foot;
                        t_body = '';
                    }
                    // console.log(t_data);


                    $("#table_body").html(t_data);
                    // $(document).ready(function() {
                    //     $('#myTable').DataTable({
                    //         dom: 'lBfrtip',
                    //         buttons: [
                    //             'copy', 'csv', 'excel', 'pdf', 'print'
                    //         ]
                    //     });
                    // });

                }
            }
        });
    }



    // live search
    $('#live_search_bar').keyup(function() {
        var live_search = "live_search";
        var input = $(this).val();
        // alert(input); 

        $.ajax({
            url: "issue_report_backend.php",
            method: "POST",
            dataType: 'JSON',
            data: {
                input: input,
                live_search: live_search
            },

            success: function(response) {

                if (response.length > 0) {
                    var S_No = 0;
                    var t_body = "";
                    var t_head = "";
                    var t_data = "";
                    for (var a = 0; a < response.length; a++) {
                        S_No++;
                        var Issued_to = response[a].m_name;
                        var Issued_by = response[a].issued_by_id;
                        var Date = response[a].date;
                        var Order_received = response[a].order_taken_by;
                        var Department = response[a].department_name;
                        var Order_Type = response[a].type_of_order;
                        var Approved_By = response[a].issued_product_approved_by;


                        // splitting the item quantity string into array and storing it
                        var Issued_Product_id_array = response[a].issued_product_id;
                        var Item_id_arr = Issued_Product_id_array.split(",");

                        // getting the item id for searching to get exact quantity of that item 
                        var search_item_id = 0;
                        search_item_id = response[a].concatenated_product_id;
                        var search_Item_arr = search_item_id.split(",");
                        var search_Item_arr_length = search_Item_arr.length;
                       


                        // splitting the item names string into array and storing it
                        var Issued_Product_Id = response[a].concatenated_item_names;
                        var Item_arr = Issued_Product_Id.split(",");
                        var Item_arr_length = Item_arr.length;

                        // splitting the item quantity string into array and storing it
                        var Issued_Product_Qty = response[a].issued_product_quantity;
                        var Item_qty_arr = Issued_Product_Qty.split(",");




                        // for serial numbering
                        var item_no = 0;

                        // head for each response to display
                        t_head = '<tr style="background-color: rgb(184,218,255);"><th>S.No.</th><th>Date</th><th>Issued To</th><th>Issued By</th><th>Approved By</th><th>Department</th></tr><tr><td>' + S_No + '</td><td>' + Date + '</td><td>' + Issued_to + '</td><td>' + Issued_by + '</td><td>' + Approved_By + '</td><td>' + Department + '</td></tr><tr style="background-color: rgb(184,218,255);"><th colspan="2">Item No.</th><th colspan="2">Item Name</th><th colspan="2">Item Quantity</th></tr>';

                        
                        // if user is searching for product then in that case this code will be executed to show exact quantity of that product
                        if (search_Item_arr_length == 1) {
                          // alert(search_item_id);
                          var search_id = search_Item_arr[0];
                          const index = Item_id_arr.indexOf(search_id);
                          var Issued_product_qty1 = Item_qty_arr[index];
                          stock_details(search_item_id,Issued_Product_Id);
                           
                            
                            t_body += '<tr><td colspan="2"> 1 </td><td colspan="2">' + Issued_Product_Id + '</td><td colspan="2">' + Issued_product_qty1 + '</td></tr>';
                            
                        } else {
                            // creating list of items and quantity to display according to the response string which was later converted into arrya

                            for (var i = 0; i < Item_arr_length; i++) {
                                item_no++;
                                var Issued_product_name = Item_arr[i];
                                var Issued_product_qty1 = Item_qty_arr[i];



                                t_body += '<tr><td colspan="2">' + item_no + '</td><td colspan="2">' + Issued_product_name + '</td><td colspan="2">' + Issued_product_qty1 + '</td></tr>';
                                
                            }
                        }


                        // t_foot for adding space after every single persons data
                        t_foot = '<tr style="height:55px;"></tr>';
                       

                        t_data += t_head + t_body + t_foot;
                        t_body = '';
                    }



                    $("#table_body").html(t_data);

                } else {
                    $("#table_body").html('no data found');

                }
            }
        });

    });
</script>


<?php
include('sidebar_lower.php');
?>