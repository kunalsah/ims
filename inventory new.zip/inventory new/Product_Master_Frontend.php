<?php
include("top_header.php");
include("sidebar_upper.php");
require("connection.php");
?>



<!-- add new product -->
<!-- Button trigger modal -->
<button type="button" class="btn btn-primary mx-2" data-bs-toggle="modal" data-bs-target="#exampleModal">
 <b> Add Product +</b>
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel" style="color:red">Add New Item!</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="row g-3 my-1">


      <div class="col-md-6 my-1">
    <label for="inputEmail4" class="form-label"><b>ItemName :</b></label>
    <select name="p_name" class="form-select select2" id="p_name">
        
</select>
  </div>

      <div class="col-md-6 my-1">
    <label for="inputPassword4" class="form-label"><b>Category :</b></label>
    <select name="p_category"  class="form-select select2" id="p_category">
        
</select>
  </div>

 

  <div class="col-md-6 my-1">
    <label for="inputEmail4" class="form-label"><b>Variety :</b></label>
    <select name="p_variety"  class="form-select select2" id="p_variety">
       

</select>
  </div>


  <div class="col-md-6 my-1">
    <label for="inputPassword4" class="form-label"><b>Quantity :</b></label>
    <input type="number" name="p_qtytotal" class="form-control" id="p_qtytotal" placeholder="enter Quantity" require>
  </div>

  <div class="col-md-6 my-1">
    <label for="inputEmail4" class="form-label"><b>Type :</b></label>
    <select name="p_type"  class="form-select select2" id="p_type">
       
</select>
  </div>
  <div class="col-md-6 my-1">
    <label for="inputEmail4" class="form-label"><b>Unit :</b></label>
    <select name="p_unit"  class="form-select select2" id="p_unit">
        
</select>
  </div>
  

  
  <div class="col-12 my-1">
    <label for="inputAddress" class="form-label"><b>Image :</b></label>
    <input type="file" name="p_image" class="form-control" id="p_image" placeholder="enter address" require>
  </div>

      </div>
      <div class="modal-footer">
      <button type="submit" name="submit" onclick="additem()" class="btn btn-danger">Add New</button>
      </div>
        </div>
    </div>
  </div>
</div>

<div class="tables">
					<h2 class="title1">Product Master</h2>
                    <div class="table-responsive">
    <table class="table" id="myTable" "border=3>
        <thead >
        <tr>
            <td><b>S No.<b></td>
            <td><b>Product Name<b></td>
            <td><b>Product Category<b></td>
            <td><b>Product Variety<b></td>
            <td><b>Product Unit<b></td> 
			      <td><b>Product Type<b></td>
            <td><b>Product Qty</b></td>
            
            <td><b>Added On</b></td>
           
            <td><b>Operations</b></td>
        </tr>
</thead>
        <tbody id="table_body" class="Data">

</tbody>

    </table>

      <!-- update Modal -->
      <div class="modal fade" id="update_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Update Product Master</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body row g-3 my-1">

                            <div class="col-md-6 my-1">
                                <label for="inputEmail4" class="form-label"><b>ItemName :</b></label>
                                <select name="u_name" class="form-select" id="u_name">
                                <option value="0" disabled selected>--select name--</option></select>
                            </div>

                            <div class="col-md-6 my-1">
                                <label for="inputPassword4" class="form-label"><b>Category :</b></label>
                                <select name="u_category"  class="form-select" id="u_category">
                                <option value="" disabled selected>--select category--</option></select>
                            </div>

                            <div class="col-md-6 my-1">
                                <label for="inputEmail4" class="form-label"><b>Variety :</b></label>
                                <select name="u_variety"  class="form-select" id="u_variety">
                                <option value="" disabled selected>--select variety--</option>
                                </select>
                            </div>

                            <div class="col-md-6 my-1">
                                <label for="inputPassword4" class="form-label"><b>Quantity :</b></label>
                                <input type="number" name="u_qtytotal" class="form-control" id="u_qtytotal" placeholder="enter Quantity" require>
                            </div>

                            <div class="col-md-6 my-1">
                                <label for="inputEmail4" class="form-label"><b>Type :</b></label>
                                <select name="u_type"  class="form-select" id="u_type">
                                <option value="" disabled selected>--select type--</option></select>
                            </div>
  
                            <div class="col-md-6 my-1">
                                <label for="inputEmail4" class="form-label"><b>Unit :</b></label>
                                <select name="u_unit"  class="form-select" id="u_unit">
                                <option value="" disabled selected>--select unit--</option></select>
                            </div>
  
                            <div class="col-12 my-1">
                                <label for="inputAddress" class="form-label"><b>Image :</b></label>
                                <input type="file" name="u_image" class="form-control" id="u_image" placeholder="enter address" require>
                            </div>
                            <input type="hidden" name="id" id="serno"></br></br>

                        </div>
      <div class="modal-footer">
      <button type="submit" name="submit"  onclick="updateitem()" class="btn btn-danger">Update</button>
      </div>
     
                    </div>

                </div>
            </div>
        </div>
                <!-- update Modal -->

                <!-- edit Modal -->
    <div class="modal fade" id="edit_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">

                    <input type="text" id="val" name="value" required style="width: 50%;"><br><br>
                    <input type="hidden" name="id" id="serno">
                    <input type="hidden" name="id" id="table_name">
                    <input type="hidden" name="id" id="column1_name">
                    <input type="hidden" name="id" id="column2_name">
                    <button type="submit" onclick="update_edited_item()" class="btn btn-primary">Update</button>
                </div>

            </div>
        </div>
    </div>
    <!-- edit Modal -->

                        <!-- reject Modal -->
                        <div class="modal fade" id="rejectModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Reason for Delete Category</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <form action="delete_cat.php" method="post">
                                            <input class="m-1" type="text" id="value" name="value" required style="width: 100%;">
                                            <input type="hidden" name="id" id="r_serno">
                                            <button type="submit" class="btn btn-primary">submit</button>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!-- reject Modal -->

    </div>
    </div>      
  <?php
include("sidebar_lower.php");
?>
<!-- end add product -->

<!-- start add product ajax.................................................................................... -->
<script>
    // In your Javascript (external .js resource or <script> tag)
    $(document).ready(function() {
        $(".select2").select2({
            dropdownParent: $("#exampleModal"),
            tags: true
        });

    });
</script>

<!-- category add ...................................................... -->
<script>
    $(document).ready(function() {
        load_values();
    });

    function load_values() {
        var display1 = 'display1';
        $.ajax({
            url: 'Product_Master_Backend.php',
            type: 'POST',
            dataType: 'JSON',
            data: {
                display1: display1
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = '<option disabled selected>--select category--</option>';
                    for (var a = 0; a < response.length; a++) {
                        var value = response[a].category_name;
                        var category_id = response[a].ca_id;

                        // alert(value);
                        optn_body = optn_body + '<option value="' + category_id + '">' + value + '</option>';
                    }
                    // $("#select").html(optn_body);
                    document.getElementById('p_category').innerHTML = optn_body;
                }
            }
        });
    }
</script>

<!-- name add ...................................................... -->
<script>
    $(document).ready(function() {
        load_values2();
    });

    function load_values2() {
        var display2 = 'display2';
        $.ajax({
            url: 'Product_Master_Backend.php',
            type: 'POST',
            dataType: 'JSON',
            data: {
                display2: display2
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = '<option disabled selected>--select name--</option>';
                    for (var a = 0; a < response.length; a++) {
                        var value = response[a].item_name;
                        var item_id = response[a].item_id;

                        // alert(value);
                        optn_body = optn_body + '<option value="' + item_id + '">' + value + '</option>';
                    }
                    // $("#select").html(optn_body);
                    document.getElementById('p_name').innerHTML = optn_body;
                }
            }
        });
    }
</script>

<!-- name add ...................................................... -->
<script>
    $(document).ready(function() {
        load_values3();
    });

    function load_values3() {
        var display3 = 'display3';
        $.ajax({
            url: 'Product_Master_Backend.php',
            type: 'POST',
            dataType: 'JSON',
            data: {
                display3: display3
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = '<option disabled selected>--select variety--</option>';
                    for (var a = 0; a < response.length; a++) {
                        var value = response[a].var_name;
                        var variety_id = response[a].var_id;

                        // alert(value);
                        optn_body = optn_body + '<option value="' + variety_id + '">' + value + '</option>';
                    }
                    // $("#select").html(optn_body);
                    document.getElementById('p_variety').innerHTML = optn_body;
                }
            }
        });
    }
</script>

<!-- type add ...................................................... -->
<script>
    $(document).ready(function() {
        load_values4();
    });

    function load_values4() {
        var display4 = 'display4';
        $.ajax({
            url: 'Product_Master_Backend.php',
            type: 'POST',
            dataType: 'JSON',
            data: {
                display4: display4
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = '<option disabled selected>--select type--</option>';
                    for (var a = 0; a < response.length; a++) {
                        var value = response[a].product_type_name;
                        var product_type_id = response[a].t_id;

                        // alert(value);
                        optn_body = optn_body + '<option value="' + product_type_id + '">' + value + '</option>';
                    }
                    // $("#select").html(optn_body);
                    document.getElementById('p_type').innerHTML = optn_body;
                }
            }
        });
    }
</script>

<!-- unit add .......................................................... -->
<script>
    $(document).ready(function() {
        load_values5();
    });

    function load_values5() {
        var display5 = 'display5';
        $.ajax({
            url: 'Product_Master_Backend.php',
            type: 'POST',
            dataType: 'JSON',
            data: {
                display5: display5
            },
            success: function(response) {
                if (response.length > 0) {
                    var optn_body = '<option disabled selected>--select unit--</option>';
                    for (var a = 0; a < response.length; a++) {
                        var value = response[a].unit_type;
                        var product_unit_id = response[a].unit_id;

                        // alert(value);
                        optn_body = optn_body + '<option value="' + product_unit_id + '">' + value + '</option>';
                    }
                    // $("#select").html(optn_body);
                    document.getElementById('p_unit').innerHTML = optn_body;
                }
            }
        });
    }
</script>
<!-- end add product ajax.................................................................................... -->

<script>
    $(document).ready(function() {
      //alert("hello");
        displayData();
        loadData();
        loadData1();
        loadData2();
        loadData3();
       loadData4();
       load_values();
       load_values2();
       load_values3();
       load_values5();
       loadData4();
    });

    function displayData() {

        var display='display';
        
       // $('#table_body').html("");

        $.ajax({
            url: 'Product_Master_Backend.php',
            type: 'GET',
            data:{display:display},
            dataType: "json",
            success: function(response) {
                if (response.length > 0) {
                    var Serial_no = 0;
                    var s_body = "";
                    for (var a = 0; a < response.length; a++) {
                        Serial_no++;
                        var item_name = response[a].item_name;
                        var g = response[a].product_id;
                        var type_ids = response[a].type_ids;
                        var products_ids=response[a].products_ids;
                        var categories_ids=response[a].categories_ids;
                        var varietys_ids=response[a].varietys_ids;
                        var units_ids=response[a].units_ids;
                        var item_category = response[a].category_name;
                        var item_unit = response[a].unit_type;
                        var item_variety = response[a].var_name;
                        var item_type = response[a].product_type_name;
                        var item_qty = response[a].product_qty;
                        var added_by = response[a].added_by;
                        var added_on = response[a].added_on;
                        var updated_by = response[a].updated_by;
                        var updated_on = response[a].updated_on;

                        var item_master_table_name = "item_master";
                        var item_master_column1_name = "item_id";
                        var item_master_column2_name = "item_name";
                        item_master_table_name = "'" + item_master_table_name + "'";
                        item_master_column1_name = "'" + item_master_column1_name + "'";
                        item_master_column2_name = "'" + item_master_column2_name + "'";

                        var category_master_table_name = "category_master";
                        var category_master_column1_name = "ca_id";
                        var category_master_column2_name = "category_name";
                        category_master_table_name = "'" + category_master_table_name + "'";
                        category_master_column1_name = "'" + category_master_column1_name + "'";
                        category_master_column2_name = "'" + category_master_column2_name + "'";

                        var variety_master_table_name = "variety_master";
                        var variety_master_column1_name = "var_id";
                        var variety_master_column2_name = "var_name";
                        variety_master_table_name = "'" + variety_master_table_name + "'";
                        variety_master_column1_name = "'" + variety_master_column1_name + "'";
                        variety_master_column2_name = "'" + variety_master_column2_name + "'";


                        var unit_master_table_name = "unit_master";
                        var unit_master_column1_name = "unit_id";
                        var unit_master_column2_name = "unit_type";
                        unit_master_table_name = "'" + unit_master_table_name + "'";
                        unit_master_column1_name = "'" + unit_master_column1_name + "'";
                        unit_master_column2_name = "'" + unit_master_column2_name + "'";

                        var type_tbl_table_name = "type_tbl";
                        var type_tbl_column1_name = "t_id";
                        var type_tbl_column2_name = "product_type_name";
                        type_tbl_table_name = "'" + type_tbl_table_name + "'";
                        type_tbl_column1_name = "'" + type_tbl_column1_name + "'";
                        type_tbl_column2_name = "'" + type_tbl_column2_name + "'";

                       

                        s_body = s_body + '<tr>' +
                            '<td>' + Serial_no + '</td>\
                            <td><a class="custom-link m-1" href="#" onclick="open_edit_modal(' + products_ids + ',' + item_master_table_name + ',' + item_master_column1_name + ',' + item_master_column2_name + ')">' + item_name + '</a></td>\
                    <td><a class="custom-link m-1" href="#" onclick="open_edit_modal(' + categories_ids + ',' + category_master_table_name + ',' + category_master_column1_name + ',' + category_master_column2_name + ')">' + item_category + '</a></td>\
                    <td><a class="custom-link m-1" href="#" onclick="open_edit_modal(' + varietys_ids + ',' + variety_master_table_name + ',' + variety_master_column1_name + ',' + variety_master_column2_name + ')">' + item_variety + '</a></td>\
                    <td><a class="custom-link m-1" href="#" onclick="open_edit_modal(' + units_ids + ',' + unit_master_table_name + ',' + unit_master_column1_name + ',' + unit_master_column2_name + ')">' + item_unit + '</a></td>\
                    <td><a class="custom-link m-1" href="#" onclick="open_edit_modal(' + type_ids + ',' + type_tbl_table_name + ',' + type_tbl_column1_name + ',' + type_tbl_column2_name + ')">' + item_type + '</a></td>\
                    <td>' + item_qty + '</td>\
                    <td>' + added_on + '</td>\
                    <td>\
                    <a class="btn btn-success"  onclick="showitem('+g+','+products_ids+','+categories_ids+','+varietys_ids+','+units_ids+','+type_ids+','+item_qty+')">Edit</a>\
                    <a href="" class="btn btn-danger" onclick="deleteitem(' + g + ')">Delete</a>\
                    </td>\
                </tr>';
                    }
                    $('#table_body').html(s_body);
                    
                    //let table = new DataTable('#myTable');
                    
    $('#myTable').DataTable( {
        dom: 'lBfrtip',
        retrieve : true,
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );

                }

            }


        });
    }

    

    // open edit modal
    function open_edit_modal(id, table, column1, column2) {

$('#serno').val(id);
$('#table_name').val(table);
$('#column1_name').val(column1);
$('#column2_name').val(column2);
$.ajax({
    url: "Product_Master_Backend.php",
    type: 'post',
    dataType: 'JSON',
    data: {
        edit_id: id,
        table: table,
        column1: column1,
        column2: column2
    },
    success: function(response) {

        if (response.length > 0) {

            var data = response[0][column2];

            $('#val').val(data);
        }
    }
});

$('#edit_modal').modal("show");

}
// update edited values
function update_edited_item() {
var id1 = $('#serno').val();
var table = $('#table_name').val();
var column1 = $('#column1_name').val();
var column2 = $('#column2_name').val();
if ($('#val').val() == '') {

    Swal.fire.fire("Enter something!");
} else {
    var name1 = $('#val').val();
    $.post("Product_Master_Backend.php", {
        update_edited_id: id1,
        name1: name1,
        update_table: table,
        update_column1: column1,
        update_column2: column2,
    }, function(data) {
        $('#update_modal').modal("hide");
        if (data == 1) {

            Swal.fire.fire("item updated successfully!");
            displayData();
            loadData();
        loadData1();
        loadData2();
        loadData3();
       loadData4();

        } else {
            Swal.fire.fire("item didn't updated!");

        }
        $('input').each(function() {
            $(this).val('');
        });
        $('#edit_modal').modal("hide");
        displayData();
        $('select').each(function(){
                     $(this).val(0);
               });
        //$('#u_name').val(response[a].item_name);
        
       

    });
}
}



    
    function deleteitem(deletedid) {
        var conf = confirm("Are you sure");
        if (conf == true) {
            $.ajax({
                url: 'Product_Master_Backend.php',
                type: 'POST',
                data: {
                    deletedid: deletedid
                },
                success: function(msg) {
                    alert(msg);
                    displayData();
                    
                }

            });
        }

    }

    function updateitem(){
        var id1=$('#serno').val();
        var name1=$('#u_name').val();
        var category=$('#u_category').val();
        var variety=$('#u_variety').val();
        var unit=$('#u_unit').val();
        var type=$('#u_type').val();
        var qty=$('#u_qtytotal').val();
        var image='';

        //alert(unit);
        $.post("Product_Master_Backend.php",{
            id1:id1,name1:name1,category:category,variety:variety,unit:unit,type:type,qty:qty,image:image
        },function(data){
            $('#update_modal').modal("hide");
           
            loadData();
                loadData1();
                loadData2();
                loadData3();
                loadData4();          
                load_values();
                load_values2();
                load_values3();
                load_values4();
                load_values5();
                displayData();
             $('select').each(function(){
                    $(this).val('');
                });
            
        });    
    }

    ///showing data in update model

    function showitem(id,products_ids,categories_ids,varietys_ids,units_ids,type,product_qty){
        // $('#update_modal').html("");
      //alert(products_ids);
      displayData();
        $('#serno').val(id);
        $('#u_name').val(products_ids);
        $('#u_category').val(categories_ids);
        $('#u_variety').val(varietys_ids);
        $('#u_unit').val(units_ids);
        $('#u_type').val(type);
        $('#u_qtytotal').val(product_qty);
        //    loadData();
        $('#update_modal').modal("show");

    }

    ////show product item 

    function loadData(){
        var u_name="u_name";
        $.ajax({
            url:'Product_Master_Backend.php',
            type:'post',
            data: {u_name: u_name},
            dataType: "json",
            success: function(response){
                if (response.length > 0) {
                    var s1_body = "";
                    for (var a = 0; a < response.length; a++) {
                        var c=response[a].item_id;
                        var b=response[a].item_name;

                        s1_body += '<option value='+c+'>'+b+'</option>';
                    }      
                    $('#u_name').html(s1_body);
                    displayData();
                }
            } 
        });

    }

    ///show product category
    function loadData1(){
        var u_category="u_category";
        $.ajax({
            url:'Product_Master_Backend.php',
            type:'post',
            data: {u_category: u_category},
            dataType: "json",
            success: function(response){
                if (response.length > 0) {
                    var s1_body = "";
                    for (var a = 0; a < response.length; a++) {
                        var c=response[a].ca_id;
                        var b=response[a].category_name;

                        s1_body += '<option value='+c+'>'+b+'</option>';
                    } 
                    $('#u_category').html(s1_body);
                }
            } 
        });

    }

    ///show product variety
    function loadData2(){
        var u_variety="u_variety";
        $.ajax({
            url:'Product_Master_Backend.php',
            type:'post',
            data: {u_variety: u_variety},
            dataType: "json",
            success: function(response){
                if (response.length > 0) {
                    var s1_body = "";
                    for (var a = 0; a < response.length; a++) {
                        var c=response[a].var_id;
                        var b=response[a].var_name;

                        s1_body += '<option value='+c+'>'+b+'</option>';
                    } 
                    $('#u_variety').html(s1_body);
                }
            } 
        });

    }

    ///show product type
    function loadData3(){
        var u_type="u_type";
        $.ajax({
            url:'Product_Master_Backend.php',
            type:'post',
            data: {u_type: u_type},
            dataType: "json",
            success: function(response){
                if (response.length > 0) {
                    var s1_body = "";
                    for (var a = 0; a < response.length; a++) {
                        var c=response[a].t_id;
                        var b=response[a].product_type_name;

                        s1_body += '<option value='+c+'>'+b+'</option>';
                    } 
                    $('#u_type').html(s1_body);
                }
            } 
        });

    }

    ///show product unit
    function loadData4(){
        var u_unit="u_unit";
        $.ajax({
            url:'Product_Master_Backend.php',
            type:'post',
            data: {u_unit: u_unit},
            dataType: "json",
            success: function(response){
                if (response.length > 0) {
                    var s1_body = "";
                    for (var a = 0; a < response.length; a++) {
                        var c=response[a].unit_id;
                        var b=response[a].unit_type;

                        s1_body += '<option value='+c+'>'+b+'</option>';
                    } 
                    $('#u_unit').html(s1_body);
                }
            } 
        });

    }

    function additem() {
      // alert("hello");
      if (($('#p_name').val() == 0) || ($('#p_name option:selected').text() == "--select name--") || ($('#p_qtytotal').val() == 0) || ($('#p_category option:selected').text() == "--select category--") || ($('#p_category').val()==0) || ($('#p_variety').val() == 0) || ($('#p_variety option:selected').text() == "--select variety--") || ($('#p_type').val() == 0) || ($('#p_type option:selected').text() == "--select type--") || ($('#p_unit').val() == 0) || ($('#p_unit option:selected').text() == "--select unit--")) {
            Swal.fire("No Empty Field!!");
            $('#exampleModal').modal('hide');
        }else{
        var name = $('#p_name').val();
        var name_text=$('#p_name option:selected').text();
        var qtytotal=$('#p_qtytotal').val();
        var category=$('#p_category').val();
        var category_text=$('#p_category option:selected').text();
        var variety=$('#p_variety').val();
        var variety_text=$('#p_variety option:selected').text();
        var type=$('#p_type').val();
        var type_text=$('#p_type option:selected').text();
        var unit=$('#p_unit').val();
        var unit_text=$('#p_unit option:selected').text();
        var image='';
        $.ajax({
            url: 'Product_Master_Backend.php',
            type: 'POST',
            dataType:'json',
            data: {
                name:name,
                qtytotal:qtytotal,
                category:category,
                variety:variety,
                type:type,
                unit:unit,
                image:image,
                name_text:name_text,
                category_text:category_text,
                variety_text:variety_text,
                type_text:type_text,
                unit_text: unit_text
            },
            success: function(response){
              if(response == 1){ 
                loadData();
                loadData1();
                loadData2();
                loadData3();
                loadData4();          
                load_values();
                load_values2();
                load_values3();
                load_values4();
                load_values5();
                displayData();
                $('#exampleModal').modal('hide');
                $('select').each(function(){
                    $(this).val('');
                });
                Swal.fire.fire('Product added successfully!');
                
            }  
            else if(response == 0){
                $('#exampleModal').modal('hide');
                    Swal.fire.fire('duplicate data found');
                   
                }
                $('#p_qtytotal').val('');
                displayData();
            }

        });
    }
    }
</script>