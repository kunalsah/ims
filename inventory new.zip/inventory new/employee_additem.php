<!-- start report section -->
<?php
if (isset($_POST["submit"])) {
    $item = $_POST["n_item"];
    $descrip = $_POST["n_descrip"];
    date_default_timezone_set("Asia/Kolkata");
    $current_date=date("Y-m-d H:i:s");

    $sql = "INSERT INTO employee_item_order (user_id,product_name,product_desc,`status`,req_date) VALUES ('1','$item','$descrip','unseen','$current_date')";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        echo "<script>alert('Data inserted')</script>";
    } else {
        echo "<script>alert('Data not inserted')</script>";
    }
}
?>

<style>

</style>
<div class="card" style="box-shadow:0 0 5px #a8a8a8;">
    <div class="text" style="color:blue;font-size:18px">
        If product is not available in Inventory let us know!
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary float-end " data-bs-toggle="modal" data-bs-target="#exampleModal">
            Add product
        </button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel" style="color:red">Order Product!</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="row g-3 my-1" method="POST">
                            <div class="col-md-12 my-1">
                                <label for="inputEmail4" class="form-label">Item Name :</label>
                                <input type="text" name="n_item" class="form-control" id="inputEmail4"
                                    placeholder="enter item name" required>
                            </div>

                            <div class="col-md-12 my-1">
                                <label for="inputPassword4" class="form-label">Description :</label>
                                <textarea name="n_descrip" class="form-control" id="inputPassword4"
                                    placeholder="enter discription" require></textarea>
                            </div>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="submit" class="btn btn-success">Place Order</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end report section -->