<?php
$conn = mysqli_connect('localhost', 'root', '', 'inventory_db');
$userData = array();

//if (!empty($_POST["term"])) {
    $search = $_POST["term"];
    $notin = $_POST["variable2"];

    $sql =  "SELECT * FROM product_list WHERE p_name LIKE '%$search%'";
    if(!empty($notin)){
        $sql .=" and p_id NOT IN(".$notin.") ";
    }
    $sql .=" ORDER BY p_name LIMIT 0,6";
    $result = mysqli_query($conn, $sql); 
    if (!empty($result)) {
       
        while($row = mysqli_fetch_assoc($result)) {
            $data['id'] = $row['p_id']; 
            $data['value'] = $row['p_name']; 
            array_push($userData, $data); 
        } // end for
       
    } // end if not empty
    echo json_encode($userData);
//}
?>