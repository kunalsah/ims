<?php
require("connection.php");
$currentDate = date('Y-m-d');

    $id=$_POST['id'];
    $receivers_name=$_POST['receivers_name'];
    $sql="UPDATE request_item SET `r_received_status`='Delivered', `r_received_on`=DATE('$currentDate'), r_accept_by='$receivers_name' where `request_serial`=$id";
    $result=mysqli_query($conn,$sql);
    if($result){
        header("Location: ".$_SERVER['HTTP_REFERER']);
        // header('location:person_request_table.php');
    }else{
        die(mysqli_error($conn));
    }


?>