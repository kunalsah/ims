<?php include("top_header.php"); ?>
<?php require("connection.php"); ?>


<?php
$user_type="by admin";
$id = $_POST['id'];
date_default_timezone_set("Asia/Kolkata");
$currentDate = date('Y-m-d h:i:sa');

//$id='1';
$sql1="SELECT r_qty FROM  request_item WHERE  request_serial=$id";
$q1 = mysqli_query($conn, $sql1);

while ($rows = $q1->fetch_assoc()) {
  $i_prd = $rows['r_qty'];
}
$value = $_POST['value'];

$sql2="INSERT INTO `update_history`(`u_id`, `request_id`, `initial_qty`, `updated_qty`, `updated_by`, `updated_on`, `status`) VALUES ('','$id','$i_prd','$value','$user_type','$currentDate','1')";
$q2 = mysqli_query($conn, $sql2);
if($q2){
    echo "Success";
  }else{
      die(mysqli_error($conn)); 
  }


$sql = "UPDATE request_item SET r_qty='$value',updated_by='$user_type' WHERE request_serial=$id";
$result = mysqli_query($conn,$sql);
if($result){
    header("Location: ".$_SERVER['HTTP_REFERER']);
}else{
    die(mysqli_error($conn)); 
}

?>