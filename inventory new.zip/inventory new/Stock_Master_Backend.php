<?php 
include("connection.php"); 

///display the data
if(isset($_REQUEST['display'])){
    $item = $_REQUEST["display"];
    
$query="SELECT stock_master.Stock_id,item_master.item_name,stock_master.Stock_Product_Name,stock_master.Total_Product,stock_master.Issued_Product, stock_master.Balance_Product,stock_master.created_on,stock_master.created_by,stock_master.updated_by,stock_master.updated_on FROM stock_master INNER JOIN product_master ON product_master.product_id=stock_master.Stock_Product_Name INNER JOIN item_master ON product_master.product_name=item_master.item_id WHERE stock_master.status=1;";
$result=mysqli_query($conn,$query);
$result_array=array();

while($row=mysqli_fetch_array($result)){
    $result_array[] = $row;
}
echo json_encode($result_array);
}

////show product name
if(isset($_REQUEST['u_name'])){
    $item = $_REQUEST["u_name"];
  $query="SELECT product_master.product_id,item_master.item_name FROM product_master INNER JOIN item_master ON product_master.product_name=item_master.item_id WHERE product_master.status=1;";
  $result=mysqli_query($conn,$query);
  $result_array=array();
  
  while($row=mysqli_fetch_array($result)){
    $result_array[] = $row;
  }
  echo json_encode($result_array);
  }
  
/// insert the data
if(isset($_POST['name'])){
    $name = $_POST["name"];
    $total_quantity = $_POST["total_quantity"];
    $issued_quantity = $_POST["issued_quantity"];
    $balance_quantity = $_POST["balance_quantity"];
    date_default_timezone_set("Asia/Kolkata");
    $creatername = "Admin";
    $current_date=date("Y-m-d H:i:s");
    $status='1';

    $sql1 = "INSERT INTO stock_master (Stock_Product_Name,Total_Product,Issued_Product,Balance_Product,created_on,created_by,status) SELECT * FROM (SELECT '$name','$total_quantity', '$issued_quantity','$balance_quantity', '$current_date','$creatername','$status') AS tmp WHERE NOT EXISTS (SELECT Stock_Product_Name FROM stock_master WHERE Stock_Product_Name = '$name' AND status='1') LIMIT 1;";
    $result = mysqli_query($conn, $sql1);
    if (mysqli_affected_rows($conn) == 0) {
      // echo $sql;
      echo $return="already Found";
    } else {
      echo $return="New Unit added!";
}
}

////delete the data
if(isset($_POST["deletedid"])){
    $id=$_POST["deletedid"];
    
    $sql= $sql1 = "UPDATE stock_master SET `status`='0' WHERE Stock_id = '$id'";

    $result = mysqli_query($conn, $sql);
    if ($result) {
      // echo $sql;
      echo $msg="Deleted Successfully!!";
    } else {
      echo $msg="Deleted Unsuccessful!!";
    }

    echo json_encode($msg);

}

////////show one data
if(isset($_POST["id"]) && isset($_POST["id"])!=""){
  $id=$_POST["id"];
  $query="SELECT stock_master.Stock_id,item_master.item_name,stock_master.Stock_Product_Name,stock_master.Total_Product,stock_master.Issued_Product, stock_master.Balance_Product FROM stock_master INNER JOIN product_master ON product_master.product_id=stock_master.Stock_Product_Name INNER JOIN item_master ON product_master.product_name=item_master.item_id WHERE stock_master.Stock_id='$id';";  

  if(!$result=mysqli_query($conn,$query)){
      exit();
  }
  $response=array();

  if(mysqli_num_rows($result)>0){
      while($row=mysqli_fetch_assoc($result)){
          $response = $row;
      }
  }else{
      $response['message']="Data Not found";
  }

echo json_encode($response);

}

///update data
if(isset($_POST["id1"])){
  date_default_timezone_set("Asia/Kolkata");
  $current_date=date("Y-m-d H:i:s");
  $creatername = "Admin";
    $id=$_POST["id1"];
    $name=$_POST["name1"];
    $Total_Product=$_POST["Total_Product"];
    $Issued_Product=$_POST["Issued_Product"];
    $Balance_Product=$_POST["Balance_Product"];
    $sql= $sql1 = "UPDATE `stock_master` SET `Total_Product`='$Total_Product',`Issued_Product`='$Issued_Product',`Balance_Product`='$Balance_Product',`updated_on`='$current_date',`updated_by`='$creatername' WHERE `Stock_Id`='$id'";

    $result = mysqli_query($conn, $sql);
    if ($result) {
      // echo $sql;
      echo $msg="Updated Successfully!!";
    } else {
      echo $msg="Updated Unsuccessful!!";
    }

    echo json_encode($msg);

}




?>