<?php

// sleep(2);
include("connection.php");
// display data

// if(isset($_POST['date1']) && isset($_POST['date2'])){
//     $min = $_POST['date1'];
//     $max = $_POST['date2'];

//     $sql = "SELECT * FROM stock_entry_table WHERE stock_purchased_date BETWEEN '{$min} AND '{$mix}' " ;
// }else{

// }
if (isset($_POST['displaydata'])) {
    $sql = "SELECT *,item_master.item_name FROM `stock_entry_table` 
    INNER JOIN product_master ON stock_entry_table.stock_name=product_master.product_id
    INNER JOIN item_master ON product_master.product_name=item_master.item_id";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $result_array = array();
        while ($row = mysqli_fetch_array($result)) {
            $result_array[] = $row;
        }
        echo json_encode($result_array);
    }
}


///searching

if (isset($_POST['search'])) {
    $input = $_POST['input'];
    // $query="select * from tb_data where name LIKE '{$input}%' OR rollnumber LIKE '{$input}%' OR branch LIKE '{$input}%' OR semester LIKE '{$input}%' OR city LIKE '{$input}%' OR id LIKE '{$input}%'";

    $sql = "SELECT *,item_master.item_name FROM `stock_entry_table` 
    INNER JOIN product_master ON stock_entry_table.stock_name=product_master.product_id
    INNER JOIN item_master ON product_master.product_name=item_master.item_id WHERE `item_name` like '%$input%' OR `stock_qty` like '%$input%' OR `rate_per_unit` like '%$input%' OR `total_rate` like '%$input%' OR `vendor_name` like '%$input%';";
    // print_r($sql);

    $result = mysqli_query($conn, $sql);
    $result_arr = array();
    while ($row = mysqli_fetch_array($result)) {
        $result_arr[] = $row;
    }
    echo json_encode($result_arr);
}

?>


