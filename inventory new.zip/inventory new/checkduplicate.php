<?php
$conn = mysqli_connect('localhost', 'root', '', 'inventory_db');
//$userData = array();
$output = '';  
//if (!empty($_POST["term"])) {
    $search = $_POST["value"];
    $notin = $_POST["variable2"];
   
   

    $sql = "SELECT * FROM product_list WHERE p_name LIKE '%$search%' ";
   
    if(!empty($notin)){
        $sql .=" and p_id NOT IN(".$notin.") ";
    }
    $sql .=" ORDER BY p_name LIMIT 0,6";
    $query = mysqli_query($conn, $sql); 
    $output = '<ul class="list-unstyled" style="margin-left:5px">';
    if(mysqli_num_rows($query)>0) {
        //$userData = mysqli_fetch_assoc($query);
        while($row = mysqli_fetch_array($query))  
        {  
            $output .= '<li data-man='.$row["p_id"].'>'.$row["p_name"].'</li>';   
        }  
       // $response[] = $userData;
      //  $response['status'] = true;            
    }
    else  
    {  
         $output .= '<li>Product Not Found</li>';  
    }  
    $output .= '</ul>';  
    echo $output;  

   
?>