-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 08, 2023 at 07:54 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_master`
--

CREATE TABLE `category_master` (
  `ca_id` bigint(11) NOT NULL,
  `category_name` varchar(60) NOT NULL,
  `created_by` varchar(30) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(30) NOT NULL,
  `updated_date` datetime NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category_master`
--

INSERT INTO `category_master` (`ca_id`, `category_name`, `created_by`, `created_date`, `updated_by`, `updated_date`, `status`) VALUES
(2, 'Electronics', '', '2023-04-04 18:43:20', 'Admin', '2023-07-26 12:17:06', '1'),
(3, 'Table Fan', '', '2023-04-05 10:56:17', 'Admin', '2023-04-10 15:11:39', '1'),
(4, 'Automotives', '', '2023-04-05 11:06:22', '', '2023-04-05 11:06:22', '1'),
(5, 'sports and outdoors', '', '2023-04-05 11:07:59', '', '2023-04-05 11:07:59', '1'),
(6, 'toys and games', '', '2023-04-05 11:08:44', '', '2023-04-05 11:08:44', '1'),
(8, 'book', '', '2023-04-05 12:35:39', 'Admin', '2023-04-10 15:23:18', '1'),
(28, 'Electron', 'Admin', '2023-07-26 15:16:34', '', '0000-00-00 00:00:00', '1'),
(30, 'mmmmm', 'Admin', '2023-07-28 10:32:52', '', '0000-00-00 00:00:00', '1'),
(34, 'stationary', 'Admin', '2023-07-28 11:48:29', '', '0000-00-00 00:00:00', '1'),
(35, 'larki', 'Admin', '2023-08-04 10:57:54', '', '0000-00-00 00:00:00', '1');

-- --------------------------------------------------------

--
-- Table structure for table `department_list`
--

CREATE TABLE `department_list` (
  `department_id` bigint(50) NOT NULL,
  `department_name` varchar(50) NOT NULL,
  `added_on` datetime NOT NULL,
  `added_by` varchar(20) NOT NULL,
  `updated_on` datetime NOT NULL,
  `updated_by` varchar(20) NOT NULL,
  `status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department_list`
--

INSERT INTO `department_list` (`department_id`, `department_name`, `added_on`, `added_by`, `updated_on`, `updated_by`, `status`) VALUES
(1, 'CSE', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 1),
(2, 'Electrical', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 1),
(3, 'Civil', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 1),
(4, 'EE', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 1),
(5, 'Mechanical', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee_item_order`
--

CREATE TABLE `employee_item_order` (
  `ser_no` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `Qty` int(11) NOT NULL,
  `product_desc` text NOT NULL,
  `accept_status` varchar(20) NOT NULL,
  `reject_status` varchar(20) NOT NULL,
  `reject_reason` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `req_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_item_order`
--

INSERT INTO `employee_item_order` (`ser_no`, `user_id`, `product_name`, `Qty`, `product_desc`, `accept_status`, `reject_status`, `reject_reason`, `status`, `req_date`) VALUES
(1, 1, 'chocolate', 0, 'aksdf', '', '', '', 'unseen', '2023-04-03 15:20:32'),
(2, 1, 'phone', 0, 'zasf', '', '', '', 'unseen', '2023-04-03 15:24:41'),
(3, 1, 'chocolate', 0, 'asdf', '', '', '', 'unseen', '2023-04-03 16:27:26'),
(0, 1, 'fff', 0, 'fff\r\n', '', '', '', 'unseen', '2023-04-04 15:43:08'),
(0, 1, 'Misting fan', 0, 'grmi lg raha hai', '', '', '', 'unseen', '2023-07-22 10:49:50');

-- --------------------------------------------------------

--
-- Table structure for table `issue_table`
--

CREATE TABLE `issue_table` (
  `issue_id` int(11) NOT NULL,
  `issue_member_id` int(11) NOT NULL,
  `issued_by_id` int(11) NOT NULL,
  `order_taken_by` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `issued_product_id` varchar(255) NOT NULL,
  `issued_product_quantity` varchar(255) NOT NULL,
  `issue_for_department` varchar(50) NOT NULL,
  `issued_product_approved_by` varchar(50) NOT NULL,
  `type_of_order` varchar(50) NOT NULL,
  `issue_slip_image` varchar(100) NOT NULL,
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issue_table`
--

INSERT INTO `issue_table` (`issue_id`, `issue_member_id`, `issued_by_id`, `order_taken_by`, `date`, `issued_product_id`, `issued_product_quantity`, `issue_for_department`, `issued_product_approved_by`, `type_of_order`, `issue_slip_image`, `remarks`) VALUES
(5, 1, 1, 'ff', '2023-08-13 00:00:00', '1,40,39', '5,4,3', '1', 'Principal', 'emergency', '', ''),
(6, 2, 1, 'rr', '2023-08-13 00:00:00', '48,41,39', '2,5,8', '2', 'Director', 'emergency', '', ''),
(7, 3, 1, 'fgf', '2023-08-13 00:00:00', '39,40,47', '2,1,21', '4', 'Assistant Director', 'emergency', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `item_master`
--

CREATE TABLE `item_master` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(50) NOT NULL,
  `updated_date` datetime NOT NULL,
  `deleted_by` varchar(50) NOT NULL,
  `d_reason` varchar(50) NOT NULL,
  `deleted_date` datetime NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `item_master`
--

INSERT INTO `item_master` (`item_id`, `item_name`, `created_by`, `created_date`, `updated_by`, `updated_date`, `deleted_by`, `d_reason`, `deleted_date`, `status`) VALUES
(1, 'Fans', 'admin', '2023-04-06 11:20:50', 'Admin', '2023-07-26 12:18:18', 'Admin', 'asf', '2023-04-06 15:36:16', 1),
(2, 'clock', 'admin', '2023-04-06 11:21:43', 'Admin', '2023-07-24 12:55:46', '', '', '0000-00-00 00:00:00', 1),
(3, 'Fans', 'admin', '2023-04-06 12:06:23', 'Admin', '2023-04-06 15:36:39', '', '', '0000-00-00 00:00:00', 0),
(4, 'colourfull chalks', 'Admin', '2023-04-10 15:06:33', 'Admin', '2023-04-10 15:18:26', '', '', '0000-00-00 00:00:00', 0),
(5, 'clack', 'Admin', '2023-04-10 15:06:46', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1),
(6, 'fair copy', 'Admin', '2023-04-10 15:17:59', 'Admin', '2023-04-10 15:18:15', '', '', '0000-00-00 00:00:00', 1),
(7, 'boards', 'Admin', '2023-07-20 10:46:38', 'Admin', '2023-07-25 11:20:43', '', '', '0000-00-00 00:00:00', 1),
(8, 'chalks', 'Admin', '2023-07-22 10:58:48', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1),
(9, 'Light', 'Admin', '2023-07-25 10:24:25', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 0),
(10, 'Pencil', 'Admin', '2023-07-26 15:11:39', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1),
(13, 'mmmmm', 'Admin', '2023-07-28 10:32:52', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1),
(19, 'copy', 'Admin', '2023-07-28 11:48:29', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1),
(20, 'mmmm', 'Admin', '2023-07-28 11:56:09', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1),
(22, 'megha', 'Admin', '2023-08-01 14:45:16', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1),
(23, 'khalkho', 'Admin', '2023-08-01 15:51:26', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1),
(24, 'kanhaiya kumar', 'Admin', '2023-08-01 15:55:16', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1),
(25, 'singh', 'Admin', '2023-08-01 15:57:34', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1),
(26, 'neha', 'Admin', '2023-08-04 10:57:54', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1),
(27, 'hamid', 'Admin', '2023-08-05 10:18:11', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1),
(28, 'kunal', 'Admin', '2023-09-07 22:52:57', '', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `member_list`
--

CREATE TABLE `member_list` (
  `m_id` bigint(20) NOT NULL,
  `m_name` varchar(60) NOT NULL,
  `m_email` varchar(60) NOT NULL,
  `m_designation` varchar(40) NOT NULL,
  `m_clg` varchar(60) NOT NULL,
  `m_department` varchar(60) NOT NULL,
  `m_contact` varchar(20) NOT NULL,
  `m_gender` varchar(30) NOT NULL,
  `m_image` varchar(80) NOT NULL,
  `m_status` varchar(10) NOT NULL,
  `m_created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member_list`
--

INSERT INTO `member_list` (`m_id`, `m_name`, `m_email`, `m_designation`, `m_clg`, `m_department`, `m_contact`, `m_gender`, `m_image`, `m_status`, `m_created_on`) VALUES
(1, 'Mantasha Sarfaraj', 'mantasha@gmail.com', 'Student', 'RSR RCET', 'CSE', '6265301893', 'Female', 'mantasha.jpg', '1', '2023-03-17 15:57:02'),
(2, 'kunal sah', 'kunalsahu.6841@gmail.com', 'student', 'RSR', 'CSE', '9399537951', 'Male', 'kunal.jpg', '1', '2023-03-19 00:00:00'),
(3, 'ajay bhardwaj', 'ajay@gmail.com', 'teacher', 'RSR', 'Electrical', '1322001722', 'Male', 'ajay.jpg', '1', '2023-03-19 18:34:18');

-- --------------------------------------------------------

--
-- Table structure for table `product_list`
--

CREATE TABLE `product_list` (
  `p_id` bigint(20) NOT NULL,
  `p_name` varchar(50) NOT NULL,
  `p_category` varchar(50) NOT NULL,
  `p_type` varchar(50) NOT NULL,
  `p_unit` varchar(30) NOT NULL,
  `p_qtytotal` int(225) NOT NULL,
  `p_qtyissue` int(225) NOT NULL,
  `p_image` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `p_created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_list`
--

INSERT INTO `product_list` (`p_id`, `p_name`, `p_category`, `p_type`, `p_unit`, `p_qtytotal`, `p_qtyissue`, `p_image`, `status`, `p_created_on`) VALUES
(1, 'Chalk', 'stationary', 'Consumable', 'pcs', 9, 3, './images/products/chalk.jpeg', 1, '2023-03-17 16:24:36'),
(2, 'pen', 'stationary', 'consumable', 'pcs', 100, 10, '', 1, '2023-03-19 13:10:43'),
(3, 'pages', 'stationary', 'consumable', 'bundle', 100, 10, '', 1, '2023-03-19 13:10:43'),
(4, 'candy', 'canteen', 'consumable', 'pcs', 100, 0, '', 1, '2023-03-25 11:06:54'),
(5, 'monitor', 'electronics', 'non-consumable', 'pcs', 100, 12, '', 1, '2023-03-25 12:16:16'),
(6, 'keyboard', 'electronics', 'non-consumable', 'pcs', 100, 2, '', 1, '2023-03-25 12:16:16'),
(7, 'Fan', 'electronics', 'non-consumable', 'pcs', 63, 0, '', 1, '2023-03-30 13:15:13'),
(8, 'Camera', 'electronics', 'non-consumable', 'pcs', 50, 0, '', 1, '2023-03-30 13:16:11'),
(9, 'Black Board', 'stationary', 'non-consumable', 'pcs', 40, 0, '', 1, '2023-03-30 13:18:05');

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

CREATE TABLE `product_master` (
  `product_id` bigint(20) NOT NULL,
  `product_name` bigint(20) NOT NULL,
  `product_category` bigint(20) NOT NULL,
  `product_variety` bigint(20) NOT NULL,
  `product_unit` bigint(20) NOT NULL,
  `product_type` bigint(20) NOT NULL,
  `product_qty` bigint(20) NOT NULL,
  `product_img` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `added_by` varchar(30) NOT NULL,
  `added_on` datetime NOT NULL,
  `updated_by` varchar(30) NOT NULL,
  `updated_on` datetime NOT NULL,
  `deleted_by` varchar(30) NOT NULL,
  `deleted_on` datetime NOT NULL,
  `dlt_reason` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`product_id`, `product_name`, `product_category`, `product_variety`, `product_unit`, `product_type`, `product_qty`, `product_img`, `status`, `added_by`, `added_on`, `updated_by`, `updated_on`, `deleted_by`, `deleted_on`, `dlt_reason`) VALUES
(1, 8, 28, 18, 13, 2, 20, '', 1, 'Admin', '2023-07-28 11:39:27', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(39, 1, 34, 27, 14, 1, 100, '', 1, 'Admin', '2023-07-28 11:48:29', 'Admin', '2023-07-31 01:20:30', '', '0000-00-00 00:00:00', ''),
(40, 7, 8, 19, 14, 1, 10, '', 1, 'Admin', '2023-07-28 11:56:09', 'Admin', '2023-07-31 01:20:21', '', '0000-00-00 00:00:00', ''),
(41, 19, 34, 12, 21, 1, 50, '', 1, 'Admin', '2023-07-31 11:00:27', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(42, 21, 4, 16, 11, 1, 5, '', 1, 'Admin', '2023-08-01 14:38:00', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(43, 0, 4, 16, 11, 1, 5, '', 1, 'Admin', '2023-08-01 14:38:07', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(44, 0, 4, 16, 27, 2, 3, '', 1, 'Admin', '2023-08-01 14:41:39', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(45, 22, 4, 16, 13, 2, 5, '', 1, 'Admin', '2023-08-01 14:45:16', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(46, 23, 4, 16, 13, 1, 5, '', 1, 'Admin', '2023-08-01 15:51:26', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(47, 24, 4, 16, 11, 1, 5, '', 0, 'Admin', '2023-08-01 15:55:16', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(48, 25, 4, 16, 11, 1, 5, '', 1, 'Admin', '2023-08-01 15:57:34', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(49, 0, 4, 16, 11, 1, 5, '', 1, 'Admin', '2023-08-01 16:02:42', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(51, 0, 4, 16, 11, 1, 4, '', 1, 'Admin', '2023-08-01 16:10:28', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(52, 26, 35, 28, 28, 2, 1, '', 1, 'Admin', '2023-08-04 10:57:54', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(53, 27, 4, 16, 11, 1, 55, '', 1, 'Admin', '2023-08-05 10:18:11', 'Admin', '2023-09-07 22:41:18', '', '0000-00-00 00:00:00', ''),
(54, 28, 4, 16, 11, 1, 5, '', 1, 'Admin', '2023-09-07 22:52:57', '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `request_item`
--

CREATE TABLE `request_item` (
  `request_serial` int(11) NOT NULL,
  `rp_id` bigint(20) NOT NULL,
  `req_mem_id` int(11) NOT NULL,
  `r_id` bigint(20) NOT NULL,
  `r_qty` int(255) NOT NULL,
  `updated_by` varchar(50) NOT NULL,
  `priority` varchar(30) NOT NULL,
  `req_dep` varchar(50) NOT NULL,
  `reason` varchar(30) DEFAULT NULL,
  `r_fd` date NOT NULL,
  `r_td` date NOT NULL,
  `r_days` int(80) NOT NULL,
  `request_to` varchar(100) NOT NULL,
  `r_accept_status` varchar(20) NOT NULL,
  `reason_a_r` varchar(400) NOT NULL,
  `r_accept_by` bigint(20) NOT NULL,
  `r_accept_on` date NOT NULL,
  `r_received_status` varchar(20) NOT NULL,
  `r_received_by` bigint(20) NOT NULL,
  `r_received_on` date NOT NULL,
  `r_return_status` varchar(20) NOT NULL,
  `r_return_by` bigint(20) NOT NULL,
  `r_return_on` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request_item`
--

INSERT INTO `request_item` (`request_serial`, `rp_id`, `req_mem_id`, `r_id`, `r_qty`, `updated_by`, `priority`, `req_dep`, `reason`, `r_fd`, `r_td`, `r_days`, `request_to`, `r_accept_status`, `reason_a_r`, `r_accept_by`, `r_accept_on`, `r_received_status`, `r_received_by`, `r_received_on`, `r_return_status`, `r_return_by`, `r_return_on`) VALUES
(1, 1, 1, 1, 0, 'by admin', 'Normal', '', 'writing', '2023-03-31', '0000-00-00', 0, '', 'Accepted', '', 0, '2023-04-03', 'NO', 0, '0000-00-00', 'NO', 0, '0000-00-00'),
(2, 8, 1, 1, 0, 'by admin', 'Normal', '', 'i want', '2023-03-31', '0000-00-00', 0, '', 'Accepted', '', 0, '2023-07-20', 'Delivered', 0, '2023-07-20', 'NO', 0, '0000-00-00'),
(4, 8, 1, 3, 5, 'NIL', 'Normal', 'CSE', 'jnjknkj', '2023-04-03', '0000-00-00', 0, '', 'NO', '', 0, '0000-00-00', 'NO', 0, '0000-00-00', 'NO', 0, '0000-00-00'),
(5, 7, 1, 4, 2, 'by admin', 'Normal', 'CSE', 'jnjknkj', '2023-04-03', '0000-00-00', 0, 'Assistant Director', 'Accepted', '', 0, '2023-04-03', 'NO', 0, '0000-00-00', 'NO', 0, '0000-00-00'),
(6, 8, 1, 5, 9, 'by admin', 'Urgent', 'CSE', 'kyuki class me bahoot gandi ga', '2023-04-04', '0000-00-00', 0, 'Chairman', 'NO', '', 0, '0000-00-00', 'NO', 0, '0000-00-00', 'NO', 0, '0000-00-00'),
(7, 0, 1, 6, 3, 'NIL', 'Urgent', 'CSE', 'abc', '2023-04-04', '0000-00-00', 0, 'Principal', 'NO', '', 0, '0000-00-00', 'NO', 0, '0000-00-00', 'NO', 0, '0000-00-00'),
(8, 0, 1, 7, 3, 'NIL', 'Urgent', 'CSE', 'abc', '2023-04-04', '0000-00-00', 0, 'Principal', 'NO', '', 0, '0000-00-00', 'NO', 0, '0000-00-00', 'NO', 0, '0000-00-00'),
(9, 0, 1, 8, 3, 'NIL', 'Urgent', 'CSE', 'abc', '2023-04-04', '0000-00-00', 0, 'Principal', 'NO', '', 0, '0000-00-00', 'NO', 0, '0000-00-00', 'NO', 0, '0000-00-00'),
(10, 0, 1, 9, 3, 'NIL', 'Urgent', 'CSE', 'abc', '2023-04-04', '0000-00-00', 0, 'Principal', 'NO', '', 0, '0000-00-00', 'NO', 0, '0000-00-00', 'NO', 0, '0000-00-00'),
(11, 3, 1, 10, 4, 'NIL', 'Urgent', 'CSE', 'setrdytfuyiuoipop[', '2023-07-20', '0000-00-00', 0, 'Principal', 'NO', '', 0, '0000-00-00', 'NO', 0, '0000-00-00', 'NO', 0, '0000-00-00'),
(12, 1, 1, 11, 5, 'by admin', 'Urgent', 'CSE', 'hj', '2023-07-22', '0000-00-00', 0, 'Principal', 'Accepted', '', 0, '2023-07-22', 'Delivered', 0, '2023-07-22', 'NO', 0, '0000-00-00'),
(13, 9, 1, 12, 2, 'NIL', 'Normal', 'Electrical', 'fff', '2023-08-08', '0000-00-00', 0, 'Principal', 'NO', '', 0, '0000-00-00', 'NO', 0, '0000-00-00', 'NO', 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `request_tbl`
--

CREATE TABLE `request_tbl` (
  `request_id` bigint(20) NOT NULL,
  `request_date` date NOT NULL,
  `request_user` bigint(20) NOT NULL,
  `request_status` varchar(20) NOT NULL,
  `deliever_status` varchar(20) NOT NULL,
  `received_status` varchar(20) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request_tbl`
--

INSERT INTO `request_tbl` (`request_id`, `request_date`, `request_user`, `request_status`, `deliever_status`, `received_status`, `status`) VALUES
(1, '2023-03-31', 1, 'request', 'request', 'request', 1),
(2, '2023-04-03', 1, 'request', 'request', 'request', 1),
(3, '2023-04-03', 1, 'request', 'request', 'request', 1),
(4, '2023-04-03', 1, 'request', 'request', 'request', 1),
(5, '2023-04-04', 1, 'request', 'request', 'request', 1),
(6, '2023-04-04', 1, 'request', 'request', 'request', 1),
(7, '2023-04-04', 1, 'request', 'request', 'request', 1),
(8, '2023-04-04', 1, 'request', 'request', 'request', 1),
(9, '2023-04-04', 1, 'request', 'request', 'request', 1),
(10, '2023-07-20', 1, 'request', 'request', 'request', 1),
(11, '2023-07-22', 1, 'request', 'request', 'request', 1),
(12, '2023-08-08', 1, 'request', 'request', 'request', 1);

-- --------------------------------------------------------

--
-- Table structure for table `stock_entry_table`
--

CREATE TABLE `stock_entry_table` (
  `stock_id` int(11) NOT NULL,
  `stock_name` int(11) NOT NULL,
  `stock_qty` int(11) NOT NULL,
  `stock_purchased_date` date DEFAULT NULL,
  `rate_per_unit` decimal(10,2) DEFAULT NULL,
  `total_rate` decimal(10,2) DEFAULT NULL,
  `vendor_name` varchar(255) DEFAULT NULL,
  `vendor_contact` varchar(20) DEFAULT NULL,
  `vendor_address` varchar(255) DEFAULT NULL,
  `vendor_state` varchar(100) DEFAULT NULL,
  `vendor_district` varchar(100) DEFAULT NULL,
  `stock_remarks` text DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `updated_date` datetime NOT NULL,
  `updated_by` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock_entry_table`
--

INSERT INTO `stock_entry_table` (`stock_id`, `stock_name`, `stock_qty`, `stock_purchased_date`, `rate_per_unit`, `total_rate`, `vendor_name`, `vendor_contact`, `vendor_address`, `vendor_state`, `vendor_district`, `stock_remarks`, `status`, `created_date`, `created_by`, `updated_date`, `updated_by`) VALUES
(14, 1, 5, '2023-08-04', '15.00', '75.00', 'ajay', '1322001722', 'purena', 'cg', 'durg', 'bakwas product', '1', '2023-08-01 11:06:55', 'admin', '0000-00-00 00:00:00', ''),
(15, 52, 1, '2023-08-20', '10.00', '10.00', 'ajay', '1322001722', 'GB Road', 'cg', 'durg', 'bakwas product', '1', '2023-08-04 10:58:57', 'admin', '0000-00-00 00:00:00', ''),
(16, 1, 55, '2023-08-12', '10.00', '550.00', 'ajay', '1322001722', 'GB Road', 'cg', 'durg', 'sdfghjk', '1', '2023-08-05 10:14:02', 'admin', '0000-00-00 00:00:00', ''),
(17, 52, 50, '2023-08-19', '22.00', '1100.00', 'ajay', '1322001722', 'GB Road', 'cg', 'durg', 'ss', '1', '2023-08-05 15:03:39', 'admin', '0000-00-00 00:00:00', ''),
(38, 52, 5, '2023-08-05', '5.00', '25.00', 'ajay', '1322001722', 'GB Road', 'cg', 'durg', '', '1', '2023-08-05 15:39:35', 'admin', '0000-00-00 00:00:00', ''),
(39, 52, 5, '2023-08-05', '5.00', '25.00', 'ajay', '1322001722', 'GB Road', 'cg', 'durg', '', '1', '2023-08-05 15:40:25', 'admin', '0000-00-00 00:00:00', ''),
(40, 52, 2, '2023-08-05', '2.00', '4.00', 'ajay', '1322001722', 'GB Road', 'cg', 'durg', '', '1', '2023-08-05 15:41:24', 'admin', '0000-00-00 00:00:00', ''),
(41, 39, 55, '2023-08-17', '45.00', '2475.00', 'ajay', '1322001722', 'GB Road', 'cg', 'durg', '', '1', '2023-08-07 10:22:14', 'admin', '0000-00-00 00:00:00', ''),
(42, 39, 100, '2023-08-12', '1350.00', '135000.00', 'ajay', '1322001722', 'GB Road', 'cg', 'durg', 'kamjor pankhaa', '1', '2023-08-07 15:45:25', 'admin', '0000-00-00 00:00:00', ''),
(43, 39, 100, '2023-08-12', '1350.00', '135000.00', 'ajay', '1322001722', 'GB Road', 'cg', 'durg', 'kamjor pankhaa', '1', '2023-08-07 15:45:27', 'admin', '0000-00-00 00:00:00', ''),
(44, 1, 50, '2023-09-08', '123.00', '6150.00', 'ajay', '1322001722', 'purena', 'cg', 'durg', '', '1', '2023-09-07 22:44:08', 'admin', '0000-00-00 00:00:00', ''),
(45, 39, 8, '2023-09-09', '880.00', '7040.00', 'ajay', '1322001722', 'purena', 'cg', 'durg', '', '1', '2023-09-07 22:45:11', 'admin', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `stock_master`
--

CREATE TABLE `stock_master` (
  `Stock_Id` bigint(20) NOT NULL,
  `Stock_Product_Name` bigint(20) NOT NULL,
  `Total_Product` bigint(200) NOT NULL,
  `Issued_Product` bigint(200) NOT NULL,
  `Balance_Product` bigint(200) NOT NULL,
  `created_on` datetime NOT NULL,
  `created_by` varchar(100) NOT NULL,
  `updated_on` datetime NOT NULL,
  `updated_by` varchar(100) NOT NULL,
  `deleted_on` datetime NOT NULL,
  `deleted_by` varchar(100) NOT NULL,
  `status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock_master`
--

INSERT INTO `stock_master` (`Stock_Id`, `Stock_Product_Name`, `Total_Product`, `Issued_Product`, `Balance_Product`, `created_on`, `created_by`, `updated_on`, `updated_by`, `deleted_on`, `deleted_by`, `status`) VALUES
(1, 38, 30, 3, 27, '2023-07-30 18:52:46', 'Admin', '2023-07-31 14:58:18', 'Admin', '0000-00-00 00:00:00', '', 1),
(2, 39, 313, 28, 46, '2023-07-31 00:38:51', 'Admin', '0000-00-00 00:00:00', 'Admin', '0000-00-00 00:00:00', '', 1),
(3, 41, 500, 68, 445, '2023-08-05 10:08:49', 'Admin', '2023-08-13 10:31:00', 'Admin', '0000-00-00 00:00:00', '', 1),
(4, 52, 17, 5, 50, '2023-08-05 10:11:02', 'Admin', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 1),
(5, 48, 550, 102, 450, '2023-08-05 15:47:07', 'Admin', '2023-08-13 10:30:54', 'Admin', '0000-00-00 00:00:00', '', 1),
(6, 53, 100, 7, 100, '2023-08-13 10:30:34', 'Admin', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 1),
(7, 1, 80, 12, 30, '2023-08-13 10:31:36', 'Admin', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 1),
(8, 40, 55, 13, 55, '2023-08-13 10:31:50', 'Admin', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 1),
(9, 50, 555, 0, 555, '2023-08-13 10:32:10', 'Admin', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `type_tbl`
--

CREATE TABLE `type_tbl` (
  `t_id` bigint(20) NOT NULL,
  `product_type_name` varchar(50) NOT NULL,
  `status` int(10) NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(200) NOT NULL,
  `updated_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `type_tbl`
--

INSERT INTO `type_tbl` (`t_id`, `product_type_name`, `status`, `created_by`, `created_date`, `updated_by`, `updated_date`) VALUES
(1, 'Consumable', 1, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00'),
(2, 'Non-Consumable', 1, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `unit_master`
--

CREATE TABLE `unit_master` (
  `unit_id` int(11) NOT NULL,
  `unit_type` varchar(20) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `deleted_on` datetime NOT NULL,
  `updated_by` varchar(50) NOT NULL,
  `updated_date` datetime NOT NULL,
  `d_reason` varchar(50) NOT NULL,
  `delete_by` int(11) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `unit_master`
--

INSERT INTO `unit_master` (`unit_id`, `unit_type`, `created_by`, `created_date`, `deleted_on`, `updated_by`, `updated_date`, `d_reason`, `delete_by`, `status`) VALUES
(1, 'kgg', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Admin', '2023-04-05 16:59:19', 'mjhe nhi chahiye', 0, '0'),
(5, 'Dozennnn', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Admin', '2023-07-20 10:48:02', '', 0, '0'),
(7, 'Liters', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Admin', '2023-07-25 11:48:37', '', 0, '1'),
(8, 'Milliliter', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 0, '1'),
(9, 'Sqft', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 0, '1'),
(10, 'Packets', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 0, '0'),
(11, 'Boxess', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 0, '1'),
(13, 'cm', 'Admin', '2023-04-10 15:03:50', '0000-00-00 00:00:00', 'Admin', '2023-07-25 11:49:47', '', 0, '1'),
(14, 'pieces', 'Admin', '2023-04-10 15:20:34', '0000-00-00 00:00:00', 'Admin', '2023-07-25 11:49:41', '', 0, '1'),
(15, 'mm', 'Admin', '2023-04-10 15:20:41', '0000-00-00 00:00:00', 'Admin', '2023-07-25 11:49:18', '', 0, '1'),
(16, '435dr6yftuygiuhoijpk', 'Admin', '2023-07-20 10:48:23', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 0, '0'),
(17, 'kgg', 'Admin', '2023-07-20 10:48:31', '0000-00-00 00:00:00', 'Admin', '2023-07-25 11:49:09', '', 0, '1'),
(18, 'boxex', 'Admin', '2023-07-22 10:59:16', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 0, '0'),
(19, 'number', 'Admin', '2023-07-25 11:51:45', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 0, '1'),
(21, 'Liter', 'Admin', '2023-07-26 15:17:52', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 0, '1'),
(24, 'kgg', 'Admin', '2023-07-28 10:58:00', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 0, '1'),
(27, 'kgg', 'Admin', '2023-08-01 14:41:39', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 0, '1'),
(28, 'kgg', 'Admin', '2023-08-04 10:57:54', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '', 0, '1');

-- --------------------------------------------------------

--
-- Table structure for table `update_history`
--

CREATE TABLE `update_history` (
  `u_id` bigint(20) NOT NULL,
  `request_id` bigint(20) NOT NULL,
  `initial_qty` bigint(20) NOT NULL,
  `updated_qty` bigint(20) NOT NULL,
  `updated_by` varchar(100) NOT NULL,
  `updated_on` datetime NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `update_history`
--

INSERT INTO `update_history` (`u_id`, `request_id`, `initial_qty`, `updated_qty`, `updated_by`, `updated_on`, `status`) VALUES
(1, 1, 5, 100, 'by admin', '2023-04-01 11:30:20', 1),
(2, 1, 100, 5, 'by admin', '2023-04-01 11:31:13', 1),
(3, 1, 5, 6, 'by admin', '2023-04-03 02:41:52', 1),
(4, 2, 10, 12, 'by admin', '2023-04-03 02:42:04', 1),
(5, 1, 6, 20, 'by admin', '2023-04-03 10:13:24', 1),
(6, 5, 2, 50, 'by admin', '2023-04-03 11:44:00', 1),
(7, 5, 50, 2, 'by admin', '2023-04-03 11:44:10', 1),
(8, 6, 10, 20, 'by admin', '2023-04-04 10:50:00', 1),
(9, 6, 20, 9846, 'by admin', '2023-04-04 10:50:18', 1),
(10, 6, 9846, 9, 'by admin', '2023-04-04 10:50:37', 1),
(11, 2, 12, 120000, 'by admin', '2023-04-04 02:45:32', 1),
(12, 2, 120000, 2, 'by admin', '2023-04-04 02:45:40', 1),
(13, 3, 0, 0, 'by admin', '2023-04-05 03:00:37', 1),
(14, 3, 0, 0, 'by admin', '2023-04-05 03:01:22', 1),
(15, 3, 0, 0, 'by admin', '2023-04-05 03:05:02', 1),
(16, 2, 2, 0, 'by admin', '2023-04-05 03:08:21', 1),
(17, 2, 0, 0, 'by admin', '2023-04-05 03:12:09', 1),
(18, 2, 0, 0, 'by admin', '2023-04-05 03:12:51', 1),
(19, 1, 20, 0, 'by admin', '2023-04-05 03:13:23', 1),
(20, 1, 0, 0, 'by admin', '2023-04-05 03:15:18', 1),
(21, 12, 6, 5, 'by admin', '2023-07-22 11:01:37', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `user_id` bigint(20) NOT NULL,
  `user_email` varchar(80) NOT NULL,
  `user_password` varchar(20) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `user_status` varchar(10) NOT NULL,
  `user_created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`user_id`, `user_email`, `user_password`, `user_type`, `user_status`, `user_created_on`) VALUES
(2, 'kunalsahu.6841@gmail.com', 'kunal', 'user', 'active', '2023-03-19 13:40:11');

-- --------------------------------------------------------

--
-- Table structure for table `variety_master`
--

CREATE TABLE `variety_master` (
  `var_id` bigint(20) NOT NULL,
  `var_name` varchar(50) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_by` varchar(50) NOT NULL,
  `updated_on` datetime NOT NULL,
  `d_reason` int(11) NOT NULL,
  `delete_by` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `variety_master`
--

INSERT INTO `variety_master` (`var_id`, `var_name`, `created_by`, `created_on`, `updated_by`, `updated_on`, `d_reason`, `delete_by`, `status`) VALUES
(1, 'Fans', 'Admin', '2023-04-04 20:14:16', 'Admin', '2023-07-25 11:37:39', 0, 0, 1),
(2, 'Est Fan', 'Admin', '2023-04-04 20:15:00', 'Admin', '2023-04-05 15:16:24', 0, 0, 0),
(3, 'Table Fans', 'Admin', '2023-04-04 20:16:28', 'Admin', '2023-04-10 15:12:24', 0, 0, 1),
(4, 'Tower fans', 'Admin', '2023-04-04 20:17:34', '', '0000-00-00 00:00:00', 0, 0, 1),
(5, 'Pedestal fans', 'Admin', '2023-04-04 20:19:06', '', '0000-00-00 00:00:00', 0, 0, 0),
(6, 'Misting fan', 'Admin', '2023-04-05 14:46:09', '', '0000-00-00 00:00:00', 0, 0, 0),
(7, 'dining table', 'Admin', '2023-04-05 15:24:01', '', '0000-00-00 00:00:00', 0, 0, 0),
(8, 'light', 'Admin', '2023-04-07 17:02:04', '', '0000-00-00 00:00:00', 0, 0, 0),
(9, 'asdf', 'Admin', '2023-04-07 17:07:50', '', '0000-00-00 00:00:00', 0, 0, 0),
(10, 'table', 'Admin', '2023-04-07 23:09:29', '', '0000-00-00 00:00:00', 0, 0, 0),
(11, 'abcd', 'Admin', '2023-04-08 14:11:01', '', '0000-00-00 00:00:00', 0, 0, 0),
(12, 'Exaust Fan', 'Admin', '2023-04-08 15:21:08', 'Admin', '2023-07-25 11:34:03', 0, 0, 1),
(13, 'hhhjjj', 'Admin', '2023-04-08 17:17:57', '', '0000-00-00 00:00:00', 0, 0, 0),
(14, 'abcd', 'Admin', '2023-04-08 17:18:30', '', '0000-00-00 00:00:00', 0, 0, 0),
(15, 'white board', 'Admin', '2023-04-08 17:23:56', 'Admin', '2023-07-26 12:15:49', 0, 0, 1),
(16, 'black boards', 'Admin', '2023-04-08 17:24:36', 'Admin', '2023-07-26 12:16:03', 0, 0, 1),
(17, 'tt', 'Admin', '2023-04-08 17:26:19', '', '0000-00-00 00:00:00', 0, 0, 0),
(18, 'bulb', 'Admin', '2023-04-10 15:19:37', 'Admin', '2023-07-26 12:16:28', 0, 0, 1),
(19, 'tube light', 'Admin', '2023-04-10 15:20:20', 'Admin', '2023-07-26 12:16:38', 0, 0, 1),
(20, 'led', 'Admin', '2023-07-20 10:47:06', 'Admin', '2023-07-26 12:16:48', 0, 0, 1),
(22, 'Shower', 'Admin', '2023-07-26 15:14:15', '', '0000-00-00 00:00:00', 0, 0, 1),
(23, 'mmmmm', 'Admin', '2023-07-28 10:35:39', '', '0000-00-00 00:00:00', 0, 0, 1),
(24, 'tdrfyghj', 'Admin', '2023-07-28 10:37:40', '', '0000-00-00 00:00:00', 0, 0, 1),
(27, 'Rough copy', 'Admin', '2023-07-28 11:48:29', '', '0000-00-00 00:00:00', 0, 0, 1),
(28, 'sundar', 'Admin', '2023-08-04 10:57:54', '', '0000-00-00 00:00:00', 0, 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category_master`
--
ALTER TABLE `category_master`
  ADD PRIMARY KEY (`ca_id`);

--
-- Indexes for table `department_list`
--
ALTER TABLE `department_list`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `issue_table`
--
ALTER TABLE `issue_table`
  ADD PRIMARY KEY (`issue_id`);

--
-- Indexes for table `item_master`
--
ALTER TABLE `item_master`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `member_list`
--
ALTER TABLE `member_list`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `product_list`
--
ALTER TABLE `product_list`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `product_master`
--
ALTER TABLE `product_master`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `request_item`
--
ALTER TABLE `request_item`
  ADD PRIMARY KEY (`request_serial`);

--
-- Indexes for table `request_tbl`
--
ALTER TABLE `request_tbl`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `stock_entry_table`
--
ALTER TABLE `stock_entry_table`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `stock_master`
--
ALTER TABLE `stock_master`
  ADD PRIMARY KEY (`Stock_Id`);

--
-- Indexes for table `type_tbl`
--
ALTER TABLE `type_tbl`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `unit_master`
--
ALTER TABLE `unit_master`
  ADD PRIMARY KEY (`unit_id`);

--
-- Indexes for table `update_history`
--
ALTER TABLE `update_history`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `variety_master`
--
ALTER TABLE `variety_master`
  ADD PRIMARY KEY (`var_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category_master`
--
ALTER TABLE `category_master`
  MODIFY `ca_id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `department_list`
--
ALTER TABLE `department_list`
  MODIFY `department_id` bigint(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `issue_table`
--
ALTER TABLE `issue_table`
  MODIFY `issue_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `item_master`
--
ALTER TABLE `item_master`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `member_list`
--
ALTER TABLE `member_list`
  MODIFY `m_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product_list`
--
ALTER TABLE `product_list`
  MODIFY `p_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product_master`
--
ALTER TABLE `product_master`
  MODIFY `product_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `request_item`
--
ALTER TABLE `request_item`
  MODIFY `request_serial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `request_tbl`
--
ALTER TABLE `request_tbl`
  MODIFY `request_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `stock_entry_table`
--
ALTER TABLE `stock_entry_table`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `stock_master`
--
ALTER TABLE `stock_master`
  MODIFY `Stock_Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `type_tbl`
--
ALTER TABLE `type_tbl`
  MODIFY `t_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `unit_master`
--
ALTER TABLE `unit_master`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `update_history`
--
ALTER TABLE `update_history`
  MODIFY `u_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `variety_master`
--
ALTER TABLE `variety_master`
  MODIFY `var_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
